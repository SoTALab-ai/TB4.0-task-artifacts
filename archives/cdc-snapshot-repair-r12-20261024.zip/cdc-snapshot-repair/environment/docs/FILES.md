# Files and replay usage

The runtime working directory is `/app`.

| Path | Role |
| --- | --- |
| `/app/app/__init__.py` | Protected public export of `SnapshotService` |
| `/app/app/service.py` | Public service interface and orchestration |
| `/app/app/catalog.py` | Source-to-finance table catalog |
| `/app/app/batches.py` | Canonical contribution storage and connected batch views |
| `/app/app/observations.py` | Capture checkpoint records |
| `/app/app/progress.py` | Capture certification progress |
| `/app/app/ledger.py` | Finance outbound message journal |
| `/app/app/publication.py` | Finance publication |
| `/app/app/retention.py` | Certified-position storage sweep |
| `/app/app/idle.py` | Maintenance-age storage sweep |
| `/app/app/normalization.py` | Producer capture catalog resolution |
| `/app/docs/OPERATIONS.md` | Business contract and exact public formats |
| `/app/docs/FILES.md` | This inventory and replay usage |
| `/app/materials/tables.csv` | Valid source-to-finance catalog |
| `/app/materials/capture-shift.jsonl` | Operational replay input |
| `/app/materials/weekend-maintenance.jsonl` | Operational replay input |
| `/app/replay.py` | JSON Lines replay runner |

You may modify or add modules under `/app/app`, except
`/app/app/__init__.py`. The documentation, materials, and replay runner stay
unchanged. Only the Python standard library is available.

The replay inputs contain no expected-output columns and no blank lines. The
first line is one JSON object with the sole key `config`; its value contains the
service constructor's keyword arguments other than `materials_dir`. The runner
uses the log's parent directory as `materials_dir`.

Every subsequent line is one JSON object with an `op` field and any keyword
argument fields alongside it. The runner calls only `register_shard`, `capture`, `change`,
`checkpoint`, `tick`, `publish`, `compact`, and `status`. After each operation it
prints one JSON object containing the input `line` number, `op`, `returned` value,
and resulting `status`.

From `/app`, run either replay with:

```bash
python replay.py materials/capture-shift.jsonl
python replay.py materials/weekend-maintenance.jsonl
```

Raw producer input also uses `capture(row)`. The installed capture-clocks.csv and capture-routing.csv catalogs and capture-envelopes.jsonl are described in OPERATIONS.md. Run `python replay.py materials/capture-envelopes.jsonl` to inspect actual observations.

The reconciliation-queue.jsonl input records an additional operating shift. Run `python replay.py materials/reconciliation-queue.jsonl` to inspect actual observations.
