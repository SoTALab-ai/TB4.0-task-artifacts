from .observations import CaptureObservations


class Progress:
    # A reporter that has not sent traffic for more than two maintenance passes
    # is paused. If all reporters pause, the greatest received certification is
    # sufficient for eventual readiness; the boundary remains monotone.
    QUIET_AFTER = 2

    def __init__(self, shards):
        self.observations = CaptureObservations(shards)
        self.position = 0

    @property
    def positions(self):
        return {s: self.observations.certified(s) for s in self.observations.records}

    def register(self, shard, current_pass):
        if shard not in self.observations.records:
            self.observations.register(shard, current_pass)
            self.settle(current_pass)

    def settle(self, current_pass):
        active = [self.observations.certified(s)
                  for s in self.observations.records
                  if current_pass - self.observations.progress_pass(s) <= self.QUIET_AFTER]
        positions = self.positions
        candidate = min(active) if active else max(positions.values())
        self.position = max(self.position, candidate)
