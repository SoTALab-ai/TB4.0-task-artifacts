from copy import deepcopy


class OutboundJournal:
    def __init__(self):
        self.journal = []
        self.latest = {}
        self.closures = []

    def last_posted(self, batch_id):
        previous = self.latest.get(batch_id)
        if previous is None:
            return None
        for page in reversed(self.journal):
            if page["batch_id"] != batch_id:
                continue
            if page["snapshot"] is not None:
                return deepcopy(page["snapshot"])
            if previous in page["withdrawn"]:
                return None
        return None

    def deliver(self, batch, withdrawn, snapshot):
        page = {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": deepcopy(withdrawn), "snapshot": deepcopy(snapshot)}
        self.journal.append(deepcopy(page))
        if snapshot is not None:
            self.latest[batch.batch_id] = deepcopy(snapshot)
        return page

    def archive(self, batch):
        self.closures.append({"batch": batch.record(),
                              "last_sent": deepcopy(self.latest.get(batch.batch_id))})
        self.latest.pop(batch.batch_id, None)
