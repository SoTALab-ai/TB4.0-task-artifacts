class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def publish(self, batches, boundary, gap, journal):
        pages = []
        for batch in batches.ordered():
            current = batch.contents()
            previous = journal.last_posted(batch.batch_id)
            if previous is not None:
                if previous != current:
                    pages.append(journal.deliver(batch, [previous], None))
            elif batch.stop + gap <= boundary:
                pages.append(journal.deliver(batch, [], current))
        return pages
