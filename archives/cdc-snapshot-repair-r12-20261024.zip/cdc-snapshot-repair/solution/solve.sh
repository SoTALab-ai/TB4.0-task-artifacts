#!/bin/sh
set -eu
mkdir -p /app/app
cp /solution/app/*.py /app/app/
