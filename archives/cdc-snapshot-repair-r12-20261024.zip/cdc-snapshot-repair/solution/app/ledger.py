from copy import deepcopy


class OutboundJournal:
    def __init__(self):
        self.journal = []
        self.latest = {}
        self.closures = []
        self._posted = {}
        self._next_instance = 1

    def posted(self, batch):
        return [deepcopy(instance) for instance in self._posted.values()
                if instance["members"] <= batch.members]

    def complete(self, batch):
        posted = self.posted(batch)
        return len(posted) == 1 and posted[0]["value"] == batch.contents()

    def deliver(self, batch, withdrawn_ids, snapshot):
        selected = set(withdrawn_ids)
        assert len(selected) == len(withdrawn_ids)
        owned = self.posted(batch)
        withdrawn = [deepcopy(instance["value"]) for instance in owned
                     if instance["instance_id"] in selected]
        assert len(withdrawn) == len(selected)
        for instance_id in selected:
            del self._posted[instance_id]
        if snapshot is not None:
            instance_id = self._next_instance
            self._next_instance += 1
            self._posted[instance_id] = {"instance_id": instance_id,
                "value": deepcopy(snapshot), "members": frozenset(batch.members)}
            self.latest[batch.batch_id] = deepcopy(snapshot)
        page = {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": withdrawn, "snapshot": deepcopy(snapshot)}
        self.journal.append(deepcopy(page))
        return page

    def archive(self, batch):
        posted = self.posted(batch)
        self.closures.append({"batch": batch.record(), "members": frozenset(batch.members),
                              "posted": deepcopy(posted)})
        for instance in posted:
            del self._posted[instance["instance_id"]]
        self.latest.pop(batch.batch_id, None)
