from dataclasses import dataclass, replace


@dataclass(frozen=True)
class Contribution:
    token: int
    table: str
    start: int
    stop: int
    delta: int
    owner_id: str
    created_pass: int


@dataclass(frozen=True)
class BatchView:
    batch_id: str
    table: str
    start: int
    stop: int
    net: int
    changes: int
    created_pass: int
    members: frozenset

    def record(self):
        return {key: getattr(self, key) for key in
                ("batch_id", "table", "start", "stop", "net", "changes")}

    def contents(self):
        return {"net": self.net, "changes": self.changes}


class Batches:
    def __init__(self, gap):
        self.gap = gap
        self._entries = {}
        self._accepted_at = {}
        self.accepted = set()
        self.next_id = 1
        self._next_token = 1

    @staticmethod
    def _project(entries):
        return BatchView(
            min((entry.owner_id for entry in entries), key=lambda key: int(key[1:])),
            entries[0].table, min(entry.start for entry in entries),
            max(entry.stop for entry in entries), sum(entry.delta for entry in entries),
            len(entries), min(entry.created_pass for entry in entries),
            frozenset(entry.token for entry in entries)
        )

    def ordered(self):
        groups, current = [], []
        right = 0
        for entry in sorted(self._entries.values(), key=lambda item: (item.table, item.start, item.token)):
            if current and (entry.table != current[0].table or entry.start > right + self.gap):
                groups.append(self._project(current))
                current = []
            right = max(right, entry.stop) if current else entry.stop
            current.append(entry)
        if current:
            groups.append(self._project(current))
        return sorted(groups, key=lambda batch: (batch.table, batch.start, batch.batch_id))

    def select(self, batch_id):
        for batch in self.ordered():
            if batch.batch_id == batch_id:
                return batch
        raise KeyError(batch_id)

    def add(self, identity, table, start, stop, delta, current_pass):
        joined = []
        remaining = [batch for batch in self.ordered() if batch.table == table]
        left, right = start, stop
        while True:
            touching = [batch for batch in remaining
                        if batch.start <= right + self.gap and left <= batch.stop + self.gap]
            if not touching:
                break
            joined.extend(touching)
            left = min(left, *(batch.start for batch in touching))
            right = max(right, *(batch.stop for batch in touching))
            ids = {batch.batch_id for batch in touching}
            remaining = [batch for batch in remaining if batch.batch_id not in ids]
        if joined:
            owner = min((batch.batch_id for batch in joined), key=lambda key: int(key[1:]))
            birth = min(batch.created_pass for batch in joined)
            for batch in joined:
                for token in batch.members:
                    self._entries[token] = replace(self._entries[token], owner_id=owner,
                                                   created_pass=birth)
        else:
            owner = f"B{self.next_id:08d}"
            self.next_id += 1
            birth = current_pass
        token = self._next_token
        self._next_token += 1
        self._entries[token] = Contribution(token, table, start, stop, delta, owner, birth)
        self._accepted_at[token] = current_pass
        self.accepted.add(identity)

    def last_work(self, batch):
        return max(self._accepted_at[token] for token in batch.members)

    def remove(self, batch):
        for token in batch.members:
            del self._entries[token]
            del self._accepted_at[token]
