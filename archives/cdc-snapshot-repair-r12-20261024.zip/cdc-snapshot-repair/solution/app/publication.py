class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def publish(self, batches, boundary, gap, journal):
        pages = []
        for batch in batches.ordered():
            current = batch.contents()
            posted = journal.posted(batch)
            keep = next((item for item in posted if item["value"] == current), None)
            obsolete = [item for item in posted if item is not keep]
            if obsolete:
                selected = [item["instance_id"] for item in obsolete[:self.page_size]]
                pages.append(journal.deliver(batch, selected, None))
            elif keep is None and batch.stop + gap <= boundary:
                pages.append(journal.deliver(batch, [], current))
        return pages
