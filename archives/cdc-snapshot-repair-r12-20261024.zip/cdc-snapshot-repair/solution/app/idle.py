class IdleSweep:
    def __init__(self, stale_passes):
        self.stale_passes = stale_passes

    def compact(self, batches, current_pass, ledger):
        removed = []
        for batch in batches.ordered():
            if not ledger.complete(batch):
                continue
            if current_pass - batches.last_work(batch) > self.stale_passes:
                ledger.archive(batch)
                batches.remove(batch)
                removed.append(batch.batch_id)
        return removed
