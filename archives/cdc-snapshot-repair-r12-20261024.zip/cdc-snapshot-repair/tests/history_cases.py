"""Private observed-prefix checks for value-instance history and retirement."""
import base_check as b


def two():
    return [b.ch('a', 'left', 0, 4, 5), b.ch('b', 'right', 20, 24, 5),
            b.cp('a', 100), b.cp('b', 100)]


def late():
    return dict(op='register_shard', shard='late')


@b.check('H9-equal-disconnected-first-postings-are-separate', 'H9.multiplicity')
def _(run):
    setup = two()
    rows = run(setup + [b.pub(), b.pub()], setup_until=len(setup),
               retention=1000, stale_passes=1000)
    assert b.sales_snapshots(rows) == [{'net': 5, 'changes': 1}] * 2
    assert rows[-1]['return'] == []


@b.check('H9-revise-one-equal-history-without-consuming-its-sibling', 'H9.ownership')
def _(run):
    setup = two() + [b.pub(), late()]
    rows = run(setup + [b.ch('late', 'extend-left', 5, 7, 2)] + [b.pub()] * 3,
               setup_until=len(setup), retention=1000, stale_passes=1000)
    posted = b.sales_snapshots(rows)
    withdrawn = [v for p in b.sales_pages(rows) for v in p['withdrawn']]
    assert posted == [{'net': 5, 'changes': 1}] * 2 + [{'net': 7, 'changes': 2}]
    assert withdrawn == [{'net': 5, 'changes': 1}]


@b.check('H9-equal-ancestors-partial-corrections-and-new-work', 'H9.merge')
def _(run):
    setup = [b.ch('a', 'one', 0, 4, 5), b.ch('b', 'two', 20, 24, 5),
             b.ch('a', 'three', 40, 44, 5), b.cp('a', 100), b.cp('b', 100),
             b.pub(), late()]
    action = [b.ch('late', 'bridge', 5, 38, 2), b.pub(),
              b.ch('late', 'interrupted', 10, 12, -1)] + [b.pub()] * 5
    rows = run(setup + action, setup_until=len(setup), page_size=1,
               retention=1000, stale_passes=1000)
    withdrawn = [v for p in b.sales_pages(rows) for v in p['withdrawn']]
    assert withdrawn == [{'net': 5, 'changes': 1}] * 3
    assert b.sales_snapshots(rows)[-1] == {'net': 16, 'changes': 5}


@b.check('H9-fresh-different-value-never-cancels-archived-history', 'H9.retirement')
def _(run):
    setup = [b.ch('a', 'old', 0, 4, 5), b.cp('a', 100), b.cp('b', 100),
             b.pub(), b.gc(), late()]
    rows = run(setup + [b.ch('late', 'fresh', 1, 3, 2), b.pub(), b.pub()],
               setup_until=len(setup), stale_passes=1000)
    assert b.sales_pages(rows)[-1]['withdrawn'] == []
    assert b.sales_snapshots(rows) == [{'net': 5, 'changes': 1}, {'net': 2, 'changes': 1}]


@b.check('H9-fresh-equal-value-is-new-delivery-after-retirement', 'H9.retirement')
def _(run):
    setup = [b.ch('a', 'old', 0, 4, 5), b.cp('a', 100), b.cp('b', 100),
             b.pub(), b.gc(), late()]
    rows = run(setup + [b.ch('late', 'fresh', 1, 3, 5), b.pub(), b.pub()],
               setup_until=len(setup), stale_passes=1000)
    assert b.sales_pages(rows)[-1]['withdrawn'] == []
    assert b.sales_snapshots(rows) == [{'net': 5, 'changes': 1}] * 2


@b.check('H9-archived-equal-posting-cannot-replace-a-live-sibling', 'H9.ownership')
def _(run):
    setup = [b.ch('a', 'old-left', 0, 4, 5), b.ch('b', 'live-right', 40, 44, 5),
             b.cp('a', 60), b.cp('b', 60), b.pub(), b.gc(), late()]
    action = [b.ch('late', 'new-left', 5, 8, 2), b.pub(),
              b.ch('late', 'right-update', 39, 42, 2)] + [b.pub()] * 3
    rows = run(setup + action, setup_until=len(setup), retention=40, stale_passes=1000)
    posted = b.sales_snapshots(rows)
    withdrawn = [v for p in b.sales_pages(rows) for v in p['withdrawn']]
    assert posted == [{'net': 5, 'changes': 1}] * 2 + [{'net': 2, 'changes': 1}, {'net': 7, 'changes': 2}]
    assert withdrawn == [{'net': 5, 'changes': 1}]
