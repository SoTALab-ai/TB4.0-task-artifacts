"""R9 value-instance contract checks; adapted base scope and new history observations."""
import copy
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))
import base_check as b


def both_inputs(fn):
    def execute(run):
        runner = run.__self__
        try:
            for transport in ('capture', 'change'):
                runner.input_transport = transport
                try:
                    fn(run)
                except Exception as exc:
                    exc.args = (f'[{transport} input] {str(exc)}',)
                    raise
        finally:
            runner.input_transport = 'capture'
    return execute


b.CHECKS[:] = [(name, category, both_inputs(fn)) for name, category, fn in b.CHECKS]

CLOCKS = "shard,epoch,offset\na,new,-40\na,old,80\nb,boot,0\n"
ROUTES = "client,actor,from_position,to_position,source_table\nweb,T,100,,ledger.entries\nweb,T,0,100,pos.sales\nmobile,T,0,,pos.refunds\nweb,F,0,,audit.fees\n"


def raw(shard, cid, start, stop, delta=1, epoch=None, client='web', actor='T'):
    return dict(op='capture', row=dict(shard=shard, change_id=cid,
                epoch=epoch or ('new' if shard == 'a' else 'boot'), client=client,
                actor=actor, local_start=start, local_stop=stop, delta=delta))


def raw_run(run, ops, expected, shards=('a', 'b'), gap=3, retention=20,
            stale_passes=50, page_size=2, clocks=CLOCKS, routes=ROUTES, setup_until=0):
    runner = run.__self__
    cfg = dict(shards=list(shards), gap=gap, retention=retention,
               stale_passes=stale_passes, page_size=page_size)
    runner.schedule_validation.append(b.validate_schedule(expected, shards, b.CATALOG))
    result = runner.invoke(dict(config=cfg, operations=ops,
                           __raw_materials__={'capture-clocks.csv': clocks,
                                              'capture-routing.csv': routes}))
    rows = result['observations']
    assert len(rows) == len(ops) == len(expected), 'raw observations'
    oracle = b.FinanceOracle(cfg, b.CATALOG)
    evidence = dict(config=cfg, operations=ops, expected_operations=expected,
                    observations=rows, setup_until=setup_until, validated_prefix_calls=0,
                    first_divergence_call=None)
    runner.receipts.append(evidence)
    for index, (actual_op, canonical, row) in enumerate(zip(ops, expected, rows)):
        try:
            assert row['op'] == actual_op['op'], 'raw worker operation mismatch'
            projected = {**row, 'op': canonical['op']}
            oracle.observe(canonical, projected)
            evidence['validated_prefix_calls'] = index + 1
        except Exception as exc:
            evidence['first_divergence_call'] = index + 1
            evidence['first_divergence'] = str(exc) or type(exc).__name__
            runner.failed_operation = actual_op['op']
            runner.failure_direction = getattr(exc, 'direction', None)
            runner.failure_component = ('maintenance' if isinstance(exc, b.MaintenanceFailure)
                                        else 'coverage' if isinstance(exc, b.CoverageFailure)
                                        else 'finance' if isinstance(exc, b.FinanceFailure)
                                        else 'membership' if isinstance(exc, b.MembershipFailure)
                                        else 'interface_or_normalization')
            message = f"call {index + 1} {actual_op['op']}: {str(exc) or type(exc).__name__}"
            if index < setup_until or (runner.category.startswith('M4.') and
                                       not isinstance(exc, b.MaintenanceFailure)):
                raise b.SetupDependency(message) from exc
            raise AssertionError(message) from exc
    return rows


@b.check('capture-epoch-before-routing-and-row-order-independence', 'normalization')
def _(run):
    ops = [raw('a', 'old-epoch', 45, 48, 7, epoch='old'),
           raw('a', 'new-epoch', 150, 155, -2), b.cp('a', 200), b.cp('b', 200), b.pub()]
    expected = [b.ch('a', 'old-epoch', 125, 128, 7, 'ledger.entries'),
                b.ch('a', 'new-epoch', 110, 115, -2, 'ledger.entries'), *ops[2:]]
    for clocks in (CLOCKS, 'shard,epoch,offset\nb,boot,0\na,old,80\na,new,-40\n'):
        raw_run(run, ops, expected, clocks=clocks)


@b.check('capture-client-namespace-and-cross-source-finance-grouping', 'normalization')
def _(run):
    routes = ROUTES.replace('mobile,T,0,,pos.refunds', 'mobile,T,0,,audit.fees')
    ops = [raw('b', 'mobile-fee', 10, 14, 9, client='mobile'),
           raw('a', 'web-sale', 50, 54, 3), b.cp('a', 50), b.cp('b', 50), b.pub()]
    expected = [b.ch('b', 'mobile-fee', 10, 14, 9, 'audit.fees'),
                b.ch('a', 'web-sale', 10, 14, 3), *ops[2:]]
    raw_run(run, ops, expected, routes=routes)


@b.check('capture-resolution-failure-leaves-identifiers-and-state-unchanged', 'normalization')
def _(run):
    ops = [raw('a', 'bad-clock', 50, 54, epoch='missing'),
           raw('a', 'good-sale', 50, 54, 3), b.cp('a', 50), b.cp('b', 50), b.pub()]
    expected = [b.ch('a', 'bad-clock', 10, 14, 1, 'unknown.table'),
                b.ch('a', 'good-sale', 10, 14, 3), *ops[2:]]
    raw_run(run, ops, expected)


@b.check('M4-capture-recent-merged-work-budget-after-real-publication', 'M4.too_early.idle')
def _(run):
    ops = [raw('a', 'initial', 40, 44, 3), b.cp('a', 7), b.cp('b', 7), b.pub()]
    expected = [b.ch('a', 'initial', 0, 4, 3), *ops[1:]]
    middle = b.heartbeat(45, {'a': 7, 'b': 7})
    ops += middle + [raw('b', 'recent', 5, 12, 8, client='mobile'), b.cp('a', 100), b.cp('b', 100), b.pub(), b.pub()]
    expected += middle + [b.ch('b', 'recent', 5, 12, 8, 'pos.refunds'), b.cp('a', 100), b.cp('b', 100), b.pub(), b.pub()]
    prefix = len(ops)
    suffix = [b.gc()] + b.heartbeat(41, {'a': 100, 'b': 100}) + [b.gc()]
    raw_run(run, ops + suffix, expected + suffix, retention=10000,
            stale_passes=40, setup_until=prefix)


@b.check('M4-capture-ordinary-expiry-before-first-finance-publication', 'M4.too_early.ordinary')
def _(run):
    ops = [raw('a', 'first', 41, 45, 7), b.cp('a', 100), b.cp('b', 100)]
    expected = [b.ch('a', 'first', 1, 5, 7), *ops[1:]]
    middle = b.heartbeat(21, {'a': 100, 'b': 100})
    suffix = [b.gc(), b.pub(), b.gc()]
    raw_run(run, ops + middle + suffix, expected + middle + suffix,
            retention=20, stale_passes=1000, setup_until=len(ops + middle))


import history_cases
b.CHECKS[:] = [(name, category, both_inputs(fn) if category.startswith('H9.') else fn)
               for name, category, fn in b.CHECKS]

if __name__ == '__main__':
    sys.exit(b.main())
