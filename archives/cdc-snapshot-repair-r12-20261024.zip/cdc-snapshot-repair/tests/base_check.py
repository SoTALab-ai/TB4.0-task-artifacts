"""Independent retained-range and external-finance-ledger acceptance checks."""
import argparse
import copy
import csv
import io
import json
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
CATALOG = 'source_table,finance_table\npos.sales,fin_sales\npos.refunds,fin_sales\nledger.entries,fin_ledger\naudit.fees,fin_fees\n'
RECEIPT_KEYS = {'net', 'changes'}
BATCH_KEYS = {'batch_id', 'table', 'start', 'stop', 'net', 'changes'}
PAGE_KEYS = {'batch_id', 'table', 'withdrawn', 'snapshot'}
CHECKS = []


class SetupDependency(AssertionError):
    """The candidate did not establish a required public-contract precondition."""


class CoverageFailure(AssertionError):
    pass


class HistoryFailure(AssertionError):
    pass


class FinanceFailure(HistoryFailure):
    """Actual returned posting/withdrawal violates an established financial obligation."""


class MembershipFailure(HistoryFailure):
    """Current retained membership is wrong before finance is evaluated."""


class InterfaceFailure(AssertionError):
    pass


def finance_assert(condition, message):
    if not condition:
        raise FinanceFailure(message)


class MaintenanceFailure(AssertionError):
    def __init__(self, message, direction='protocol'):
        super().__init__(message)
        self.direction = direction



def check(name, category):
    def register(fn):
        CHECKS.append((name, category, fn))
        return fn
    return register


def ch(shard, cid, start, stop, delta=1, table='pos.sales'):
    return dict(op='change', shard=shard, change_id=cid, source_table=table,
                start=start, stop=stop, delta=delta)


def cp(shard, position):
    return dict(op='checkpoint', shard=shard, position=position)


def tick(passes=1):
    return dict(op='tick', passes=passes)


def pub():
    return dict(op='publish')


def gc():
    return dict(op='compact')


def alloc(value):
    return int(value[1:])


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def name(value):
    return isinstance(value, str) and bool(value)


def validate_schedule(ops, shards, catalog):
    positions = {s: 0 for s in shards}
    tables = {r['source_table'] for r in csv.DictReader(io.StringIO(catalog))}
    seen, count = {}, 0
    for index, op in enumerate(ops):
        if op['op'] == 'register_shard' and name(op['shard']):
            positions.setdefault(op['shard'], 0)
        elif op['op'] == 'checkpoint' and name(op['shard']) and op['shard'] in positions and integer(op['position']):
            positions[op['shard']] = max(positions[op['shard']], op['position'])
        elif op['op'] == 'change':
            valid = (name(op['shard']) and op['shard'] in positions and name(op['change_id'])
                     and name(op['source_table']) and op['source_table'] in tables
                     and integer(op['start']) and integer(op['stop']) and op['start'] < op['stop']
                     and type(op['delta']) is int)
            if not valid:
                continue
            key = op['shard'], op['change_id']
            if key in seen:
                assert op == seen[key], f'fixture redelivery differs at call {index}'
            else:
                assert op['stop'] > positions[op['shard']], f'fixture contradicts shard checkpoint at call {index}'
                seen[key] = op
                count += 1
    return {'calls': len(ops), 'new_envelopes': count, 'checkpoint_promises_valid': True}


def canonical_public_operation(op, materials):
    """Independent catalog resolution of the frozen public raw replay."""
    if op['op'] != 'capture':
        return op
    row = op['row']
    clocks = list(csv.DictReader(io.StringIO(materials['capture-clocks.csv'])))
    selected = [entry for entry in clocks if (entry['shard'], entry['epoch']) == (row['shard'], row['epoch'])]
    assert len(selected) == 1, 'public fixture clock basis must be unique'
    offset = int(selected[0]['offset'])
    start, stop = row['local_start'] + offset, row['local_stop'] + offset
    routes = list(csv.DictReader(io.StringIO(materials['capture-routing.csv'])))
    matches = [entry for entry in routes if (entry['client'], entry['actor']) == (row['client'], row['actor'])
               and int(entry['from_position']) <= start
               and (not entry['to_position'] or start < int(entry['to_position']))]
    assert len(matches) == 1, 'public fixture route must be unique'
    return ch(row['shard'], row['change_id'], start, stop, row['delta'], matches[0]['source_table'])


class FinanceOracle:
    """Rebuild connected components from raw retained envelopes after every accepted change."""
    def __init__(self, config, catalog):
        self.cfg = config
        self.tables = {r['source_table']: r['finance_table'] for r in csv.DictReader(io.StringIO(catalog))}
        self.positions = {s: 0 for s in config['shards']}
        self.reports = {s: None for s in config['shards']}
        self.highest = self.clock = self.frontier = 0
        self.seen, self.records, self.parts, self.posted, self.archived = set(), {}, {}, {}, {}
        self.batch_serial = self.receipt_serial = 0

    def valid(self, op):
        kind = op['op']
        if kind == 'register_shard':
            return name(op.get('shard'))
        if kind in ('checkpoint', 'change'):
            if not name(op.get('shard')) or op['shard'] not in self.positions:
                return False
        if kind == 'checkpoint':
            return integer(op.get('position'))
        if kind == 'change':
            return (name(op.get('change_id')) and name(op.get('source_table')) and op['source_table'] in self.tables
                    and integer(op.get('start')) and integer(op.get('stop')) and op['start'] < op['stop']
                    and type(op.get('delta')) is int)
        if kind == 'tick':
            return integer(op.get('passes', 1))
        if kind in ('publish', 'compact'):
            return set(op) == {'op'}
        return kind == 'status'

    def public(self, part):
        rows = [self.records[k] for k in part['members']]
        return {'batch_id': part['id'], 'table': rows[0]['table'], 'start': min(r['start'] for r in rows),
                'stop': max(r['stop'] for r in rows), 'net': sum(r['delta'] for r in rows), 'changes': len(rows)}

    def contents(self, part):
        return {k: self.public(part)[k] for k in ('net', 'changes')}

    def represented(self, part):
        return len(part['receipts']) == 1 and all(
            self.posted[next(iter(part['receipts']))]['record'][k] == v for k, v in self.contents(part).items())

    def insert(self, op):
        key = op['shard'], op['change_id']
        if key in self.seen:
            return
        self.seen.add(key)
        self.records[key] = {'table': self.tables[op['source_table']], 'start': op['start'],
                             'stop': op['stop'], 'delta': op['delta'], 'clock': self.clock}
        owner = {k: part for part in self.parts.values() for k in part['members']}
        groups, current, right, table = [], [], None, None
        for k, row in sorted(self.records.items(), key=lambda item: (item[1]['table'], item[1]['start'], item[1]['stop'], item[0])):
            if current and (row['table'] != table or row['start'] > right + self.cfg['gap']):
                groups.append(current)
                current = []
            current.append(k)
            right = max(right, row['stop']) if len(current) > 1 else row['stop']
            table = row['table']
        if current:
            groups.append(current)
        rebuilt = {}
        for members in groups:
            ancestors = {owner[k]['id'] for k in members if k in owner}
            if ancestors:
                ident = min(ancestors, key=alloc)
            else:
                self.batch_serial += 1
                ident = f'B{self.batch_serial:08d}'
            refs = set().union(*(self.parts[a]['receipts'] for a in ancestors)) if ancestors else set()
            rebuilt[ident] = {'id': ident, 'members': members, 'receipts': refs}
        self.parts = rebuilt

    def apply_pages(self, pages, cut):
        assert isinstance(pages, list), 'publish must return a list'
        ordered = sorted(self.parts.values(), key=lambda p: (self.public(p)['table'], self.public(p)['start'], p['id']))
        needed = [p for p in ordered if p['receipts'] and not (self.represented(p) and self.public(p)['stop'] + self.cfg['gap'] <= cut)
                  or not p['receipts'] and self.public(p)['stop'] + self.cfg['gap'] <= cut]
        finance_assert(len(pages) == len(needed), 'missing or extra finance page for current retained work')
        for page, part in zip(pages, needed):
            assert isinstance(page, dict) and set(page) == PAGE_KEYS, 'page fields'
            finance_assert(page['batch_id'] == part['id'] and page['table'] == self.public(part)['table'], 'page ordering/lineage')
            old = set(part['receipts'])
            withdrawals = page['withdrawn']
            assert isinstance(withdrawals, list) and len(withdrawals) <= self.cfg['page_size'], 'page capacity'
            if old:
                finance_assert(bool(withdrawals), 'page with old postings must withdraw at least one')
            ids = []
            for record in withdrawals:
                assert isinstance(record, dict) and set(record) == RECEIPT_KEYS, 'withdrawal fields'
                assert type(record['net']) is int and integer(record['changes'], 1), 'withdrawal integer fields'
                matching = [ident for ident in part['receipts'] if self.posted[ident]['record'] == record]
                finance_assert(bool(matching), 'withdrawal is not a real unwithdrawn ancestor occurrence')
                ident = min(matching, key=alloc)
                finance_assert(record == self.posted[ident]['record'], 'withdrawal changed the actual old receipt')
                ids.append(ident)
                part['receipts'].remove(ident)
                del self.posted[ident]
            complete = self.public(part)['stop'] + self.cfg['gap'] <= cut
            snap = page['snapshot']
            if part['receipts'] or not complete:
                finance_assert(snap is None, 'replacement posted before old receipts drained or range complete')
            else:
                if withdrawals and snap is None:
                    continue
                finance_assert(snap is not None, 'ready work with no old posting must return its snapshot')
                assert isinstance(snap, dict) and set(snap) == RECEIPT_KEYS, 'snapshot fields'
                assert type(snap['net']) is int and integer(snap['changes'], 1), 'snapshot integer fields'
                self.receipt_serial += 1
                instance = f'R{self.receipt_serial:08d}'
                finance_assert({k: snap[k] for k in self.contents(part)} == self.contents(part), 'snapshot differs from independently rebuilt retained envelopes')
                self.posted[instance] = {'table': page['table'], 'record': copy.deepcopy(snap)}
                part['receipts'].add(instance)

    def compact(self, returned, cut):
        expected = []
        for ident, part in sorted(self.parts.items(), key=lambda item: alloc(item[0])):
            current = self.public(part)
            touched = max(self.records[k]['clock'] for k in part['members'])
            expired = cut > current['stop'] + self.cfg['gap'] + self.cfg['retention']
            inactive = self.clock - touched > self.cfg['stale_passes']
            if self.represented(part) and (expired or inactive):
                expected.append(ident)
        if returned != expected:
            direction = 'protocol'
            if isinstance(returned, list) and all(isinstance(item, str) for item in returned):
                early, late = set(returned) - set(expected), set(expected) - set(returned)
                direction = 'mixed' if early and late else 'too_early' if early else 'too_late' if late else 'protocol'
            raise MaintenanceFailure('compaction changed owed finance work or did not retire finished expired work', direction)
        for ident in expected:
            part = self.parts.pop(ident)
            for rid in part['receipts']:
                self.archived[rid] = self.posted.pop(rid)
            for key in part['members']:
                del self.records[key]

    def observe(self, op, row):
        assert row['op'] == op['op'], 'worker operation mismatch'
        if not self.valid(op):
            assert row['error'] and row['error']['type'] == 'ValueError', 'invalid call must raise ValueError'
        else:
            assert row['error'] is None, f"{op['op']} raised {row['error']}"
            kind = op['op']
            if kind == 'register_shard':
                if op['shard'] not in self.positions:
                    self.positions[op['shard']] = 0
                    self.reports[op['shard']] = None
            elif kind == 'checkpoint':
                self.positions[op['shard']] = max(self.positions[op['shard']], op['position'])
                self.reports[op['shard']] = self.clock
                self.highest = max(self.highest, op['position'])
            elif kind == 'tick':
                self.clock += op.get('passes', 1)
            elif kind == 'change':
                if (op['shard'], op['change_id']) not in self.seen:
                    self.reports[op['shard']] = self.clock
                self.insert(op)
        status = row['status']
        if not isinstance(status, dict) or set(status) != {'pass', 'checkpoint', 'batches'}:
            raise CoverageFailure('status fields')
        if status['pass'] != self.clock:
            raise CoverageFailure('maintenance counter or invalid-call atomicity')
        checkpoint = status['checkpoint']
        if not integer(checkpoint) or not self.frontier <= checkpoint <= self.highest:
            raise CoverageFailure('coverage regressed or invented capture certification')
        known_running = [position for shard, position in self.positions.items() if self.reports[shard] is not None and self.clock - self.reports[shard] <= 2]
        if known_running:
            if checkpoint > max(self.frontier, min(known_running)):
                raise CoverageFailure('new coverage ignored a continuously reporting low checkpoint')
        self.frontier = checkpoint
        if op['op'] != 'compact':
            expected_before_finance = sorted((self.public(p) for p in self.parts.values()),
                key=lambda p: (p['table'], p['start'], p['batch_id']))
            if status['batches'] != expected_before_finance:
                raise MembershipFailure('retained batch state differs from sort-and-scan envelope oracle')
        if row['error'] is None:
            if op['op'] == 'publish':
                try:
                    self.apply_pages(row['return'], checkpoint)
                except FinanceFailure:
                    raise
                except AssertionError as exc:
                    raise InterfaceFailure(str(exc)) from exc
            elif op['op'] == 'compact':
                self.compact(row['return'], checkpoint)
            elif op['op'] != 'status':
                assert row['return'] is None, 'mutator return value'
        expected = sorted((self.public(p) for p in self.parts.values()), key=lambda p: (p['table'], p['start'], p['batch_id']))
        if status['batches'] != expected:
            message = 'retained batch state differs from sort-and-scan envelope oracle'
            if op['op'] == 'compact':
                actual_ids = {row.get('batch_id') for row in status['batches'] if isinstance(row, dict)} if isinstance(status['batches'], list) else set()
                expected_ids = {row['batch_id'] for row in expected}
                early, late = expected_ids - actual_ids, actual_ids - expected_ids
                direction = 'mixed' if early and late else 'too_early' if early else 'too_late' if late else 'state_corruption'
                raise MaintenanceFailure(message, direction)
            raise MembershipFailure(message)
        if op['op'] == 'status' and row['error'] is None:
            assert row['return'] == status, 'status return differs from observation'


class Runner:
    def __init__(self, candidate, isolate=False):
        if isolate and (not hasattr(os, 'geteuid') or os.geteuid() != 0):
            raise RuntimeError('--isolate requires root')
        self.isolate = isolate
        self.source = Path(candidate) / 'app'
        assert not self.source.is_symlink(), 'candidate app must not be a symlink'
        source = self.source.resolve()
        for path in source.rglob('*'):
            assert not path.is_symlink() or path.resolve().is_relative_to(source), 'candidate symlink escapes app'
        self.root = Path(tempfile.mkdtemp(prefix='cdc-r3-check-'))
        self.root.chmod(0o755)
        shutil.copytree(source, self.root / 'candidate/app', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copyfile(HERE / 'worker.py', self.root / 'worker.py')
        for path in self.root.rglob('*'):
            path.chmod(0o755 if path.is_dir() else 0o644)
        self.receipts, self.schedule_validation = [], []
        self.category = None
        self.failure_component = self.failed_operation = self.failure_direction = None

    def _drop(self):
        if self.isolate:
            os.setgroups([])
            os.setgid(65534)
            os.setuid(65534)

    def process(self, args, cwd, data=None, timeout=30):
        proc = subprocess.Popen(args, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, start_new_session=True, preexec_fn=self._drop,
            env={'PATH': '/usr/local/bin:/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1', 'HOME': str(cwd)})
        try:
            out, err = proc.communicate(data, timeout=timeout)
            return subprocess.CompletedProcess(args, proc.returncode, out, err)
        finally:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if proc.poll() is None:
                proc.communicate()

    def invoke(self, request, catalog=CATALOG):
        material = Path(tempfile.mkdtemp(prefix='catalog-', dir=self.root))
        material.chmod(0o755)
        (material / 'tables.csv').write_text(catalog)
        (material / 'tables.csv').chmod(0o644)
        raw_defaults = {
            'capture-clocks.csv': 'shard,epoch,offset\na,new,-40\na,old,80\nb,boot,0\n',
            'capture-routing.csv': 'client,actor,from_position,to_position,source_table\nweb,T,100,,ledger.entries\nweb,T,0,100,pos.sales\nmobile,T,0,,pos.refunds\nweb,F,0,,audit.fees\n',
        }
        explicit_raw = request.pop('__raw_materials__', None)
        if explicit_raw is None:
            enrolled = {value for value in request['config']['shards'] if isinstance(value, str) and value}
            enrolled.update(op['shard'] for op in request.get('operations', [])
                            if op['op'] == 'register_shard' and isinstance(op.get('shard'), str) and op['shard'])
            prefix = ''.join(f'{shard},normalized,0\n' for shard in sorted(enrolled))
            raw_defaults['capture-clocks.csv'] = 'shard,epoch,offset\n' + prefix + 'shard,epoch,offset\na,new,-40\na,old,80\nb,boot,0\n'.split('\n', 1)[1]
            table_rows = list(csv.DictReader(io.StringIO(catalog)))
            raw_defaults['capture-routing.csv'] += ''.join(
                f'canonical,{row["source_table"]},0,,{row["source_table"]}\n' for row in table_rows)
            transported = []
            for operation in request.get('operations', []):
                if operation['op'] != 'change':
                    transported.append(operation)
                    continue
                transported.append(dict(op='capture', __logical_op__='change', row=dict(
                    shard=operation['shard'], change_id=operation['change_id'], epoch='normalized',
                    client='canonical', actor=operation['source_table'], local_start=operation['start'],
                    local_stop=operation['stop'], delta=operation['delta'])))
            if 'operations' in request and getattr(self, 'input_transport', 'capture') == 'capture':
                request['operations'] = transported
        else:
            raw_defaults.update(explicit_raw)
        for filename, contents in raw_defaults.items():
            assert filename in ('capture-clocks.csv', 'capture-routing.csv')
            (material / filename).write_text(contents)
            (material / filename).chmod(0o644)

        proc = self.process([sys.executable, '-I', '-B', str(self.root / 'worker.py'),
                             str(self.root / 'candidate'), str(material)], self.root, json.dumps(request))
        assert proc.returncode == 0, 'candidate process failed: ' + proc.stderr[-400:]
        return json.loads(proc.stdout)

    def run(self, ops, shards=('a', 'b'), gap=3, retention=20, stale_passes=50, page_size=2, catalog=CATALOG,
            setup_until=0, setup_checkpoint=None, setup_observer=None, raw_materials=None):
        config = dict(shards=list(shards), gap=gap, retention=retention, stale_passes=stale_passes, page_size=page_size)
        expected_ops = [canonical_public_operation(op, raw_materials) for op in ops] if raw_materials else ops
        self.schedule_validation.append(validate_schedule(expected_ops, shards, catalog))
        request = {'config': config, 'operations': ops}
        if raw_materials is not None:
            request['__raw_materials__'] = raw_materials
        data = self.invoke(request, catalog)
        rows = data['observations']
        assert len(rows) == len(ops), 'missing observations'
        oracle = FinanceOracle(config, catalog)
        evidence = {'config': config, 'operations': ops, 'expected_operations': expected_ops,
                    'observations': rows, 'setup_until': setup_until, 'setup_checkpoint': setup_checkpoint,
                    'validated_prefix_calls': 0, 'first_divergence_call': None}
        self.receipts.append(evidence)
        for index, (actual_op, op, row) in enumerate(zip(ops, expected_ops, rows)):
            try:
                oracle.observe(op, {**row, 'op': op['op']})
                if index + 1 == setup_until and setup_checkpoint is not None:
                    assert row['status']['checkpoint'] == setup_checkpoint, 'certified setup work did not become ready within 30 passes'
                if index + 1 == setup_until and setup_observer is not None:
                    setup_observer(rows[:index + 1])
                evidence['validated_prefix_calls'] = index + 1
            except Exception as exc:
                evidence['first_divergence_call'] = index + 1
                evidence['first_divergence'] = str(exc) or type(exc).__name__
                message = f"call {index + 1} {op['op']}: {str(exc) or type(exc).__name__}"
                self.failed_operation = op['op']
                self.failure_direction = getattr(exc, 'direction', None)
                self.failure_component = ('maintenance' if isinstance(exc, MaintenanceFailure) else
                                          'coverage' if isinstance(exc, CoverageFailure) else
                                          'finance' if isinstance(exc, FinanceFailure) else
                                          'membership' if isinstance(exc, MembershipFailure) else 'interface_or_setup')
                if index < setup_until or (self.category and self.category.startswith('M4.') and
                                          not isinstance(exc, MaintenanceFailure)):
                    raise SetupDependency(message) from exc
                if isinstance(exc, AssertionError):
                    raise AssertionError(message) from exc
                raise
        return rows


def pages(rows):
    return [p for row in rows if row['op'] == 'publish' and row['return'] for p in row['return']]


def snapshots(rows):
    return [p['snapshot'] for p in pages(rows) if p['snapshot'] is not None]



def heartbeat(passes, positions):
    ops = []
    for _ in range(passes):
        ops.append(tick())
        ops.extend(cp(shard, value) for shard, value in positions.items())
    return ops


def settle(positions):
    return [cp(shard, value) for shard, value in positions.items()] + heartbeat(30, positions)


def warm(cut=100, gap=3):
    # This existing work requires the target certified position to become ready.
    # A new low-position shard can then deliver legal revisions into settled history.
    return [ch('a', 'coverage-marker', cut-gap-1, cut-gap, 0, 'audit.fees')] + settle({'a': cut}) + [
        pub(), dict(op='register_shard', shard='b'), cp('b', 0), cp('a', cut)]


def sales_pages(rows):
    return [page for page in pages(rows) if page['table'] == 'fin_sales']


def sales_snapshots(rows):
    return [page['snapshot'] for page in sales_pages(rows) if page['snapshot'] is not None]


def sales_batches(row):
    return [batch for batch in row['status']['batches'] if batch['table'] == 'fin_sales']


def controlled(run, setup, action, cut=100, **kwargs):
    return run(setup + action, shards=('a',), setup_until=len(setup), setup_checkpoint=cut, **kwargs)


@check('range-catalog-global-identifiers-and-large-signed-amounts', 'baseline')
def _(run):
    for catalog, tables in [(CATALOG, ('pos.sales', 'pos.refunds', 'ledger.entries')),
        ('finance_table,source_table\nzeta,feed.alpha\nzeta,feed.beta\naudit,other\n', ('feed.alpha', 'feed.beta', 'other'))]:
        ops = [ch('west', 'same', 7, 12, -(1 << 80), tables[0]),
               ch('east', 'same', 14, 18, 3, tables[1]), ch('west', 'b', 30, 34, 9, tables[2])]
        rows = run(ops + settle({'west': 100, 'east': 100}) + [pub(), pub()], shards=('west', 'east'), gap=2, catalog=catalog)
        assert len(snapshots(rows)) == 2 and rows[-1]['return'] == []


@check('transitive-range-reconstruction-in-delivery-permutations', 'baseline')
def _(run):
    rng = random.Random(261023)
    for seed in range(8):
        gap = rng.randrange(6)
        width = gap + 5
        inputs = [(0, width), (width+gap+3, 2*width+gap+3), (2*width+2*gap+6, 3*width+2*gap+6),
                  (width, width+gap+4), (2*width+gap+3, 2*width+2*gap+7)]
        rng.shuffle(inputs)
        ops = [ch('a' if index % 2 else 'b', f'c{index}', start, stop, rng.randrange(-20, 30))
               for index, (start, stop) in enumerate(inputs)]
        rows = run(ops + [dict(ops[1])] + settle({'a': 1000, 'b': 1000}) + [pub(), pub()], gap=gap)
        assert len(rows[-1]['status']['batches']) == 1, f'transitive grouping seed {seed}'


@check('lifetime-shard-identity-and-new-history-after-retirement', 'baseline')
def _(run):
    original = ch('a', 'shared', 1, 5, 4)
    setup = [original, dict(original), ch('b', 'shared', 2, 6, 7)] + settle({'a': 100, 'b': 100}) + [pub()]
    ops = setup + [gc(), dict(original), dict(op='register_shard', shard='late'),
                   ch('late', 'fresh', 1, 5, 3), pub(), pub()]
    rows = run(ops, stale_passes=1000)
    assert snapshots(rows)[0]['net'] == 11 and snapshots(rows)[1]['net'] == 3
    assert rows[len(setup)+1]['status']['batches'] == [], 'retirement reset lifetime identity'
    assert pages(rows)[1]['withdrawn'] == [], 'new history withdrew archived receipt'


@check('invalid-inputs-are-atomic-including-future-identifiers-and-activity', 'baseline')
def _(run):
    bad = [ch('unknown', 'k', 1, 5), ch('a', '', 1, 5), ch('a', 'k', 1, 5, table='unknown'),
           ch('a', 'k', -1, 5), ch('a', 'k', 5, 5), ch('a', 'k', 6, 5), ch('a', 'k', True, 5),
           ch('a', 'k', 1, 5, True), ch('a', 'k', 1, 5, 1.2), cp('a', True), cp('a', -1),
           cp('unknown', 5), tick(-1), tick(1.2), dict(op='register_shard', shard=''),
           dict(op='register_shard', shard=4)]
    pre = [ch('a', 'first', 1, 5)] + settle({'a': 100, 'b': 100}) + [pub()]
    rows = run(pre + bad + [dict(op='register_shard', shard='late'), ch('late', 'k', 20, 25), pub()])
    assert all(row['error'] and row['error']['type'] == 'ValueError' for row in rows[len(pre):len(pre)+len(bad)])
    assert rows[-1]['status']['batches'][-1]['batch_id'] == 'B00000002'
    ops = [ch('a', 'pending', 12, 17), cp('a', 5), cp('b', 5)]
    for index in range(1, 31):
        ops += [tick(), cp('a', 20+index)]
        if index == 29:
            ops += [cp('b', True), ch('b', 'bad', 12, 17, table='unknown')]
    clean = [op for op in ops if not (op['op'] == 'checkpoint' and op.get('position') is True)
             and op.get('source_table') != 'unknown']
    errored, comparison = run(ops + [pub()]), run(clean + [pub()])
    assert errored[-1]['status'] == comparison[-1]['status'], 'failed input changed future capture activity'
    setup = warm(10)
    controlled(run, setup, [ch('b', 'retained', 1, 5), pub()] + heartbeat(8, {'a': 10, 'b': 0}) +
               [ch('b', 'bad', 1, 5, True)] + heartbeat(3, {'a': 10, 'b': 0}) + [gc()],
               cut=10, retention=1000, stale_passes=10)


@check('constructor-rejects-invalid-parameters', 'baseline')
def _(run):
    base = dict(shards=['a'], gap=3, retention=20, stale_passes=50, page_size=2)
    for key, value in [('shards', []), ('shards', ['a', 'a']), ('shards', ['']), ('gap', -1),
                       ('gap', True), ('retention', -1), ('stale_passes', 1.5), ('page_size', 0), ('page_size', True)]:
        result = run.__self__.invoke({'config': {**base, key: value}, 'constructor_probe': True})
        assert result['constructor_error'] and result['constructor_error']['type'] == 'ValueError', key


@check('M3-late-partial-pause-covered-work-ready-by-deadline', 'M3.too_late')
def _(run):
    ops = [ch('a', 'pending', 12, 17, 4), cp('a', 5), cp('b', 5)]
    for index in range(1, 31):
        ops += [tick(), cp('a', 20+index)]
    rows = run(ops + [pub(), pub()], retention=1000, stale_passes=1000)
    assert len(snapshots(rows)) == 1, 'partial pause blocked covered work beyond 30 passes'


@check('M3-late-ordinary-common-reports-first-receipt-on-next-publish', 'M3.too_late')
def _(run):
    for late_enrollment in (False, True):
        ops = [ch('a', 'ordinary', 12, 17, 4)]
        enrolled = ['a', 'b']
        if late_enrollment:
            ops += [dict(op='register_shard', shard='late')]
            enrolled.append('late')
        ops += [cp(shard, 25) for shard in enrolled] + [pub()]
        rows = run(ops, retention=1000, stale_passes=1000, setup_until=len(ops)-1)
        # Every enrolled source's actual current report covers stop + gap.
        # This obligation follows from the input reports, even if the candidate
        # hides its delay by exposing a lower settled checkpoint in status().
        assert len(snapshots(rows[-1:])) == 1, 'ordinary common coverage did not first-publish on the next call'


@check('M3-late-all-paused-received-certification-still-releases-work', 'M3.too_late')
def _(run):
    rows = run([ch('a', 'pending', 20, 25, 2), cp('a', 60), cp('b', 10)] +
               [tick() for _ in range(30)] + [pub(), pub()], retention=1000, stale_passes=1000)
    assert len(snapshots(rows)) == 1, 'silence of every source stalled supported work'


@check('M3-early-time-alone-does-not-certify-new-positions', 'M3.too_early')
def _(run):
    rows = run([ch('a', 'beyond', 59, 65), cp('a', 60), cp('b', 10)] +
               [tick(100), pub()] * 5, retention=1000, stale_passes=1000)
    assert snapshots(rows) == [], 'maintenance time completed uncertified work'


@check('M3-early-unchanged-low-checkpoints-remain-working-reports', 'M3.too_early')
def _(run):
    ops = [ch('a', 'blocked', 20, 25), cp('a', 50), cp('b', 7)]
    for index in range(1, 37):
        ops += [tick(), cp('a', 60+index)]
        if index % 2 == 0:
            ops += [cp('b', 7)]
        ops += [pub()]
    rows = run(ops, retention=1000, stale_passes=1000)
    assert snapshots(rows) == [], 'continuing low certifications were ignored'


@check('M3-early-new-change-traffic-resumes-a-paused-source', 'M3.too_early')
def _(run):
    setup = [ch('a', 'existing', 45, 47), cp('a', 50), cp('b', 5)] + heartbeat(30, {'a': 50}) + [pub()]
    # The first new envelope expresses resumption before a fresh high report
    # from a. The resumed source then honours its two-pass checkpoint promise.
    ops = [ch('b', 'return', 6, 8), cp('a', 60), cp('b', 5)] + heartbeat(12, {'a': 60, 'b': 5})
    rows = run(setup + ops, retention=1000, stale_passes=1000, setup_until=len(setup), setup_checkpoint=50)
    assert rows[-1]['status']['checkpoint'] == 50, 'resumed source did not constrain further settlement'


@check('M3-monotone-late-enrolment-does-not-retreat-settled-history', 'M3.monotonicity')
def _(run):
    setup = warm(100)
    rows = controlled(run, setup, [ch('b', 'late', 12, 18), cp('b', 1), pub(), pub()],
                      retention=1000, stale_passes=1000)
    assert rows[-1]['status']['checkpoint'] == 100 and sales_snapshots(rows)[-1]['net'] == 1


def history_start(count=2, equal=False, cut=100, gap=3):
    setup = warm(cut, gap)
    setup += [ch('b', f'p{index}', index*20, index*20+3, 4 if equal else index+1) for index in range(count)]
    return setup + [pub()]


@check('multiple-real-ancestor-receipts-survive-a-range-bridge', 'history')
def _(run):
    for reverse_creation in (False, True):
        # First-posting order follows range start; creation order can differ.
        # The external ledger consumes actual value occurrences in any
        # allowed order, without identifying numerical equality with identity.
        setup = (warm() + [ch('b', 'p1', 20, 23, 2), ch('b', 'p0', 0, 3, 1), pub()]
                 if reverse_creation else history_start())
        rows = controlled(run, setup, [ch('b', 'bridge', 5, 18, 7)] + [pub()] * 3, page_size=3,
                          retention=1000, stale_passes=1000)
        assert sum(len(page['withdrawn']) for page in sales_pages(rows)) == 2
        assert sales_snapshots(rows)[-1]['net'] == 10 and sales_snapshots(rows)[-1]['changes'] == 3


@check('equal-finance-amounts-do-not-collapse-distinct-receipt-instances', 'history')
def _(run):
    setup = history_start(equal=True)
    rows = controlled(run, setup, [ch('b', 'bridge', 5, 18, 2)] + [pub()] * 3, page_size=1,
                      retention=1000, stale_passes=1000)
    withdrawals = [old for page in sales_pages(rows) for old in page['withdrawn']]
    assert len(withdrawals) == 2 and withdrawals[0] == withdrawals[1]
    assert sales_snapshots(rows)[-1]['net'] == 10


@check('reopened-incomplete-work-withdraws-before-later-readiness', 'history')
def _(run):
    setup = warm(100) + [ch('b', 'first', 0, 4, 3), pub()]
    action = [ch('b', 'extension', 5, 150, 8), pub(), pub()] + settle({'a': 200, 'b': 200}) + [pub(), pub()]
    rows = controlled(run, setup, action, retention=1000, stale_passes=1000)
    correction = sales_pages(rows)[1]
    assert correction['snapshot'] is None and len(correction['withdrawn']) == 1
    assert sales_snapshots(rows)[-1]['net'] == 11


@check('bounded-underfilled-and-delayed-replacement-pages-converge', 'history')
def _(run):
    setup = history_start(5, cut=200, gap=2)
    rows = controlled(run, setup, [ch('b', 'bridge', 4, 79, 7)] + [pub()] * 6 + [pub()],
                      cut=200, gap=2, page_size=3, retention=1000, stale_passes=1000)
    assert rows[-1]['return'] == [] and len(sales_snapshots(rows)) == 6


@check('new-work-between-partial-pages-does-not-resurrect-withdrawn-instances', 'history')
def _(run):
    setup = history_start(4, gap=2)
    action = [ch('b', 'merge', 4, 59, 5), pub(), ch('b', 'extend', 64, 130, 9)] + [pub()] * 5
    action += settle({'a': 200, 'b': 200}) + [pub(), pub()]
    rows = controlled(run, setup, action, gap=2, page_size=1, retention=1000, stale_passes=1000)
    assert sales_snapshots(rows)[-1]['net'] == 24 and rows[-1]['return'] == []


@check('destination-isolation-and-repeated-correction-histories', 'history')
def _(run):
    setup = warm() + [ch('b', 'x', 0, 3, 2), ch('b', 'y', 0, 3, 6, 'ledger.entries'), pub()]
    action = [ch('b', 'extension', 3, 7, 1), pub(), pub(), ch('b', 'again', 7, 9, 4), pub(), pub(), pub()]
    rows = controlled(run, setup, action, retention=1000, stale_passes=1000)
    assert len(sales_snapshots(rows)) == 3 and rows[-1]['return'] == []


@check('M4-ordinary-first-ready-work-survives-maintenance-before-publish', 'M4.too_early.ordinary')
def _(run):
    setup = warm()
    rows = controlled(run, setup, [ch('b', 'first', 1, 5, 7), gc(), pub(), gc()],
                      retention=20, stale_passes=1000)
    assert sales_snapshots(rows)[-1]['net'] == 7 and not sales_batches(rows[-1])


@check('M4-idle-first-ready-work-survives-maintenance-before-publish', 'M4.too_early.idle')
def _(run):
    setup = warm(10)
    rows = controlled(run, setup, [ch('b', 'first', 1, 5, 7)] + heartbeat(11, {'a': 10, 'b': 0}) +
                      [gc(), pub(), gc()], cut=10, retention=1000, stale_passes=10)
    assert sales_snapshots(rows)[-1]['net'] == 7 and not sales_batches(rows[-1])


@check('M4-ordinary-pending-replacement-survives-until-financially-finished', 'M4.too_early.ordinary')
def _(run):
    setup = warm() + [ch('b', 'first', 0, 4, 3), pub()]
    rows = controlled(run, setup, [ch('b', 'correction', 1, 3, 8), gc(), pub(), gc(), pub(), gc()],
                      retention=20, stale_passes=1000)
    assert sales_snapshots(rows)[-1]['net'] == 11 and not sales_batches(rows[-1])


@check('M4-idle-withdrawn-postings-still-owe-the-incomplete-replacement', 'M4.too_early.idle')
def _(run):
    setup = warm() + [ch('b', 'first', 0, 4, 3), pub()]
    action = [ch('b', 'extension', 5, 150, 8), pub()] + heartbeat(11, {'a': 100, 'b': 0}) + [gc()]
    boundary = len(setup) + len(action)
    action += settle({'a': 200, 'b': 200}) + [pub(), gc()]
    rows = controlled(run, setup, action, retention=1000, stale_passes=10)
    assert sales_batches(rows[boundary-1]), 'incomplete replacement vanished after old postings drained'
    assert sales_snapshots(rows)[-1]['net'] == 11 and not sales_batches(rows[-1])


@check('M4-ordinary-partial-pages-retain-all-unpaid-history', 'M4.too_early.ordinary')
def _(run):
    setup = history_start(4, gap=2)
    action = [ch('b', 'bridge', 4, 59, 7), gc()]
    for _ in range(5):
        action += [cp('a', 100), cp('b', 0), pub(), gc()]
    rows = controlled(run, setup, action, gap=2, page_size=1, retention=20, stale_passes=1000)
    assert sum(len(page['withdrawn']) for page in sales_pages(rows)) == 4
    assert sales_snapshots(rows)[-1]['net'] == 17 and not sales_batches(rows[-1])


@check('M4-idle-partial-pages-retain-all-unpaid-history', 'M4.too_early.idle')
def _(run):
    setup = history_start(4, gap=2)
    action = [ch('b', 'bridge', 4, 59, 7)] + heartbeat(11, {'a': 100, 'b': 0}) + [gc()]
    for _ in range(5):
        action += [cp('a', 100), cp('b', 0), pub(), gc()]
    rows = controlled(run, setup, action, gap=2, page_size=1, retention=1000, stale_passes=10)
    assert sales_snapshots(rows)[-1]['net'] == 17 and not sales_batches(rows[-1])


@check('M4-idle-recent-merged-work-receives-its-inactivity-budget', 'M4.too_early.idle')
def _(run):
    setup = warm() + [ch('b', 'old', 0, 3, 2), pub()] + heartbeat(31, {'a': 100, 'b': 0})
    action = [ch('b', 'new', 20, 23, 3), pub(), ch('b', 'bridge', 5, 18, 7), pub(), pub(), pub(), gc()]
    boundary = len(setup) + len(action)
    action += heartbeat(31, {'a': 100, 'b': 0}) + [gc()]
    rows = controlled(run, setup, action, retention=1000, stale_passes=30)
    assert sales_batches(rows[boundary-1]), 'recent merged work was retired using old age'
    assert not sales_batches(rows[-1])


@check('M4-ordinary-finished-expired-work-has-no-extra-idle-gate', 'M4.too_late.ordinary')
def _(run):
    setup = warm(14)
    rows = controlled(run, setup, [ch('b', 'fresh', 1, 5, 2), pub(), gc()], cut=14,
                      retention=5, stale_passes=1000)
    assert not sales_batches(rows[-1]), 'ordinary expiry added an inactivity wait'


@check('M4-ordinary-retention-is-strict-at-the-certified-boundary', 'M4.boundary')
def _(run):
    setup = warm(13) + [ch('b', 'first', 1, 5, 2), pub()]
    rows = controlled(run, setup, [gc()] + settle({'a': 14, 'b': 14}) + [gc()],
                      cut=13, retention=5, stale_passes=1000)
    assert sales_batches(rows[len(setup)]) and not sales_batches(rows[-1])


@check('M4-idle-finished-expired-work-is-actually-retired', 'M4.too_late.idle')
def _(run):
    setup = warm(10) + [ch('b', 'first', 1, 5, 2), pub()]
    original = ch('b', 'first', 1, 5, 2)
    action = heartbeat(10, {'a': 10, 'b': 0}) + [gc(), original, dict(op='status'), pub()]
    boundary = len(setup) + len(action)
    action += heartbeat(1, {'a': 10, 'b': 0}) + [gc()]
    rows = controlled(run, setup, action, cut=10, retention=1000, stale_passes=10)
    assert sales_batches(rows[boundary-1]) and not sales_batches(rows[-1]), 'idle expiry or activity semantics'


@check('protected-public-entry-unchanged', 'integrity')
def _(run):
    expected = HERE / 'frozen/app-init.py'
    assert expected.exists(), 'missing frozen public entry'
    assert (run.__self__.root / 'candidate/app/__init__.py').read_bytes() == expected.read_bytes(), 'protected public entry changed'


@check('public-replay-inputs-and-independent-finance-ledger', 'integration')
def _(run):
    frozen = HERE / 'frozen'
    logs = sorted((frozen / 'materials').glob('*.jsonl'))
    assert logs and (frozen / 'replay.py').exists(), 'missing frozen public replay'
    for log in logs:
        records = [json.loads(line) for line in log.read_text().splitlines() if line.strip()]
        config, ops = records[0]['config'], records[1:]
        raw_materials = {name: (frozen / 'materials' / name).read_text()
                         for name in ('capture-clocks.csv', 'capture-routing.csv')}
        run(ops, catalog=(frozen / 'materials/tables.csv').read_text(), raw_materials=raw_materials, **config)
        runner = run.__self__
        work = Path(tempfile.mkdtemp(prefix='replay-', dir=runner.root))
        shutil.copytree(frozen / 'materials', work / 'materials')
        shutil.copyfile(frozen / 'replay.py', work / 'replay.py')
        shutil.copytree(runner.root / 'candidate/app', work / 'app')
        for path in [work, *work.rglob('*')]:
            path.chmod(0o755 if path.is_dir() else 0o644)
        proc = runner.process([sys.executable, '-B', '-E', '-s', 'replay.py', f'materials/{log.name}'], work, timeout=60)
        assert proc.returncode == 0, 'public replay failed: ' + proc.stderr[-300:]
        assert len([line for line in proc.stdout.splitlines() if line.strip()]) == len(ops), 'public replay row count'


def natural_maintenance_prefix(rows, current, original=None, original_withdrawn=False):
    """Check the observed business prefix before the first maintenance call."""
    assert rows[-1]['op'] == 'status', 'natural maintenance setup must end in an observed status'
    batches = sales_batches(rows[-1])
    assert len(batches) == 1, 'natural maintenance setup did not retain its unique sales batch'
    assert {key: batches[0][key] for key in current} == current, 'natural maintenance setup has wrong current work'
    sent = sales_snapshots(rows)
    withdrawn = [receipt for page in sales_pages(rows) for receipt in page['withdrawn']]
    if original is None:
        assert not sent and not withdrawn, 'first-publication setup already delivered finance work'
    else:
        assert len(sent) == 1 and {key: sent[0][key] for key in ('net', 'changes')} == {key: original[key] for key in ('net', 'changes')}, 'setup did not deliver its real original receipt'
        assert withdrawn == ([sent[0]] if original_withdrawn else []), 'setup original receipt is not in the required finance state'


@check('M4-natural-common-reports-ordinary-first-publication-is-protected', 'M4.too_early.ordinary')
def _(run):
    setup = [ch('a', 'first', 1, 5, 7), cp('a', 100), cp('b', 100)]
    setup += heartbeat(21, {'a': 100, 'b': 100}) + [dict(op='status')]
    rows = run(setup + [gc(), pub(), gc()], retention=20, stale_passes=1000,
               setup_until=len(setup), setup_checkpoint=100,
               setup_observer=lambda prefix: natural_maintenance_prefix(
                   prefix, {'start': 1, 'stop': 5, 'net': 7, 'changes': 1}))
    assert sales_snapshots(rows)[-1]['net'] == 7 and not sales_batches(rows[-1])


@check('M4-natural-common-reports-ordinary-pending-replacement-is-protected', 'M4.too_early.ordinary')
def _(run):
    setup = [ch('a', 'first', 0, 4, 3), cp('a', 7), cp('b', 7), pub(),
             ch('b', 'extension', 5, 12, 8), cp('a', 100), cp('b', 100)]
    setup += heartbeat(21, {'a': 100, 'b': 100}) + [dict(op='status')]
    rows = run(setup + [gc(), pub(), pub(), gc()], retention=20, stale_passes=1000,
               setup_until=len(setup), setup_checkpoint=100,
               setup_observer=lambda prefix: natural_maintenance_prefix(
                   prefix, {'start': 0, 'stop': 12, 'net': 11, 'changes': 2},
                   original={'start': 0, 'stop': 4, 'net': 3, 'changes': 1}))
    assert sales_snapshots(rows)[-1]['net'] == 11 and not sales_batches(rows[-1])


@check('M4-natural-common-reports-idle-withdrawn-work-still-owes-replacement', 'M4.too_early.idle')
def _(run):
    setup = [ch('a', 'first', 0, 4, 3), cp('a', 7), cp('b', 7), pub(),
             ch('b', 'extension', 5, 150, 8), pub()]
    setup += heartbeat(11, {'a': 7, 'b': 7}) + [dict(op='status')]
    rows = run(setup + [gc(), cp('a', 200), cp('b', 200), pub(), gc()],
               retention=1000, stale_passes=10,
               setup_until=len(setup), setup_checkpoint=7,
               setup_observer=lambda prefix: natural_maintenance_prefix(
                   prefix, {'start': 0, 'stop': 150, 'net': 11, 'changes': 2},
                   original={'start': 0, 'stop': 4, 'net': 3, 'changes': 1},
                   original_withdrawn=True))
    assert sales_snapshots(rows)[-1]['net'] == 11 and not sales_batches(rows[-1])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--candidate', required=True)
    parser.add_argument('--report')
    parser.add_argument('--isolate', action='store_true')
    args = parser.parse_args()
    runner = Runner(args.candidate, args.isolate)
    checks = []
    try:
        for name_, category, fn in CHECKS:
            runner.category = category
            runner.failure_component = runner.failed_operation = runner.failure_direction = None
            before = len(runner.receipts)
            try:
                fn(runner.run)
                row = dict(name=name_, category=category, ok=True)
            except Exception as exc:
                message = str(exc) or type(exc).__name__
                dependency = isinstance(exc, SetupDependency) or (category.startswith('M4.') and
                              runner.failure_component != 'maintenance') or (category.startswith('H9.') and runner.failure_component != 'finance')
                row = dict(name=name_, category=category, ok=False,
                           failure_kind='setup_dependency' if dependency else 'independent_behavior',
                           failure_component=runner.failure_component,
                           failed_operation=runner.failed_operation,
                           observed_maintenance_direction=runner.failure_direction,
                           message=message[:800] if isinstance(exc, AssertionError) else (type(exc).__name__ + ': ' + message)[:800])
            row['receipt_indices'] = list(range(before, len(runner.receipts)))
            row['executions'] = len(runner.receipts) - before
            checks.append(row)
            print(('PASS ' if row['ok'] else 'FAIL ') + name_ +
                  ('' if row['ok'] else ' -- ' + row['failure_kind'] + ': ' + row['message']), flush=True)
        passed = sum(row['ok'] for row in checks)
        categories = {}
        for row in checks:
            group = categories.setdefault(row['category'], {'passed': 0, 'total': 0, 'independent_failures': [], 'setup_dependencies': []})
            group['passed'] += int(row['ok'])
            group['total'] += 1
            if not row['ok']:
                key = 'setup_dependencies' if row['failure_kind'] == 'setup_dependency' else 'independent_failures'
                group[key].append(row['name'])
        result = {'passed': passed, 'total': len(checks), 'reward': float(passed == len(checks)),
                  'isolate': runner.isolate, 'checks': checks, 'categories': categories,
                  'schedule_validation': runner.schedule_validation, 'receipts': runner.receipts,
                  'independent_oracles': ['retained-envelope sort-and-scan', 'external actual-returned-value occurrence ledger scoped to retained lineage'],
                  'gc_attribution': 'M4 setup dependencies are separate from independent maintenance-call behavior',
                  'source_activity_contract': 'known-running safety probes use checkpoint reports or previously unseen changes; no retry or registration activity obligation'}
        if args.report:
            Path(args.report).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(f'{passed}/{len(checks)}')
        return 0 if passed == len(checks) else 1
    finally:
        shutil.rmtree(runner.root, ignore_errors=True)


if __name__ == '__main__':
    sys.exit(main())

