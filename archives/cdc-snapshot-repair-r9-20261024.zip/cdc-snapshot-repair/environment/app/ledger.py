from copy import deepcopy
from dataclasses import dataclass, field


@dataclass
class HistoryNode:
    transmissions: list = field(default_factory=list)
    last_sent: dict | None = None


class OutboundJournal:
    def __init__(self):
        self._outbox = []
        self.closures = []

    def allocate(self, contents):
        return deepcopy(contents)

    def stage(self, node, page):
        self._outbox.append((node, deepcopy(page)))

    def drain(self):
        pages = []
        for node, page in self._outbox:
            node.transmissions.append(deepcopy(page))
            if page["snapshot"] is not None:
                node.last_sent = deepcopy(page["snapshot"])
            pages.append(deepcopy(page))
        self._outbox.clear()
        return pages

    def archive(self, batch):
        def record(node):
            return {
                "transmissions": deepcopy(node.transmissions),
                "last_sent": deepcopy(node.last_sent),
            }
        self.closures.append({
            "batch": deepcopy(batch.record()),
            "history": record(batch.history),
        })
