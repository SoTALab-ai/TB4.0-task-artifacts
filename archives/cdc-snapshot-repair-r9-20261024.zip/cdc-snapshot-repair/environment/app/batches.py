from dataclasses import dataclass
from .ledger import HistoryNode


@dataclass
class Batch:
    batch_id: str
    table: str
    start: int
    stop: int
    net: int
    changes: int
    created_pass: int
    history: HistoryNode

    def record_change(self, start, stop, delta):
        self.start = min(self.start, start)
        self.stop = max(self.stop, stop)
        self.net += delta
        self.changes += 1

    def join(self, other, start, stop, delta):
        self.start = min(self.start, other.start, start)
        self.stop = max(self.stop, other.stop, stop)
        self.net += other.net + delta
        self.changes += other.changes + 1
        self.created_pass = min(self.created_pass, other.created_pass)

    def record(self):
        return {
            "batch_id": self.batch_id,
            "table": self.table,
            "start": self.start,
            "stop": self.stop,
            "net": self.net,
            "changes": self.changes,
        }

    def contents(self):
        return {
            "net": self.net,
            "changes": self.changes,
        }


class Batches:
    def __init__(self, gap):
        self.gap = gap
        self.items = {}
        self.accepted = set()
        self.next_id = 1

    def ordered(self):
        return sorted(
            self.items.values(),
            key=lambda batch: (batch.table, batch.start, batch.batch_id),
        )

    def add(self, identity, table, start, stop, delta, current_pass):
        joined = []
        remaining = [batch for batch in self.items.values() if batch.table == table]
        left, right = start, stop
        while True:
            touching = [
                batch for batch in remaining
                if batch.start <= right + self.gap and left <= batch.stop + self.gap
            ]
            if not touching:
                break
            joined.extend(touching)
            left = min(left, *(batch.start for batch in touching))
            right = max(right, *(batch.stop for batch in touching))
            touching_ids = {batch.batch_id for batch in touching}
            remaining = [batch for batch in remaining if batch.batch_id not in touching_ids]

        if not joined:
            batch_id = f"B{self.next_id:08d}"
            self.next_id += 1
            self.items[batch_id] = Batch(
                batch_id, table, start, stop, delta, 1, current_pass,
                HistoryNode()
            )
            self.accepted.add(identity)
            return

        owner = min(joined, key=lambda batch: int(batch.batch_id[1:]))
        owner.record_change(start, stop, delta)
        for batch in joined:
            if batch.batch_id != owner.batch_id:
                owner.join(batch, start, stop, delta)
                del self.items[batch.batch_id]
        self.accepted.add(identity)
