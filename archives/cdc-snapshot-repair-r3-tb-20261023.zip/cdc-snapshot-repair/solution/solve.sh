#!/bin/sh
set -eu
mkdir -p /app/app
cp /solution/app/service.py /app/app/service.py
