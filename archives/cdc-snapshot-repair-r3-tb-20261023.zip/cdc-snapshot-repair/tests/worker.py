"""Execute calls only; the trusted parent judges all observations."""
import contextlib
import importlib
import json
import os
import sys

candidate, materials = sys.argv[1:3]
request = json.load(sys.stdin)
sys.path.insert(0, candidate)
channel = os.dup(sys.stdout.fileno())
os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
payload = {}
with contextlib.redirect_stdout(sys.stderr):
    try:
        service = importlib.import_module("app").SnapshotService(materials, **request["config"])
        constructor_error = None
    except Exception as exc:
        constructor_error = {"type": type(exc).__name__, "message": str(exc)[:200]}
    if request.get("constructor_probe"):
        payload = {"constructor_error": constructor_error}
    else:
        if constructor_error:
            raise RuntimeError("constructor failed: " + str(constructor_error))
        rows = []
        for operation in request["operations"]:
            kwargs = dict(operation)
            name = kwargs.pop("op")
            try:
                returned = getattr(service, name)(**kwargs)
                error = None
            except Exception as exc:
                returned, error = None, {"type": type(exc).__name__, "message": str(exc)[:200]}
            try:
                status = service.status()
            except Exception as exc:
                status = {"error": type(exc).__name__}
            rows.append(json.loads(json.dumps({"op": name, "return": returned, "error": error, "status": status})))
        payload = {"observations": rows}
data = (json.dumps(payload, sort_keys=True) + "\n").encode()
try:
    while data:
        data = data[os.write(channel, data):]
finally:
    os.close(channel)

