import csv
from pathlib import Path


class Catalog:
    def __init__(self, materials_dir):
        with (Path(materials_dir) / "tables.csv").open(newline="", encoding="utf-8") as handle:
            self.tables = {
                row["source_table"]: row["finance_table"]
                for row in csv.DictReader(handle)
            }

    def finance_table(self, source_table):
        if not isinstance(source_table, str) or source_table not in self.tables:
            raise ValueError("unknown source table")
        return self.tables[source_table]
