from .batches import Batches
from .catalog import Catalog
from .progress import Progress
from .publication import Publication
from .retention import Retention


def _name(value, label):
    if not isinstance(value, str) or not value:
        raise ValueError(f"{label} must be a nonempty string")


def _integer(value, label, minimum=0):
    if type(value) is not int or value < minimum:
        raise ValueError(f"{label} must be an integer >= {minimum}")


class SnapshotService:
    def __init__(self, materials_dir, shards, gap, retention, stale_passes, page_size=2):
        if not isinstance(shards, list) or not shards:
            raise ValueError("shards must be a nonempty list")
        for shard in shards:
            _name(shard, "shard")
        if len(set(shards)) != len(shards):
            raise ValueError("shards must be distinct")
        _integer(gap, "gap")
        _integer(retention, "retention")
        _integer(stale_passes, "stale_passes")
        _integer(page_size, "page_size", 1)
        self.catalog = Catalog(materials_dir)
        self.gap = gap
        self.current_pass = 0
        self.progress = Progress(shards)
        self.batches = Batches(gap)
        self.publication = Publication(page_size)
        self.retention = Retention(gap, retention, stale_passes)
        self.seen = set()

    def _shard(self, shard):
        _name(shard, "shard")
        if shard not in self.progress.positions:
            raise ValueError("unknown shard")

    def register_shard(self, shard):
        _name(shard, "shard")
        self.progress.register(shard)

    def change(self, shard, change_id, source_table, start, stop, delta):
        self._shard(shard)
        _name(change_id, "change_id")
        table = self.catalog.finance_table(source_table)
        _integer(start, "start")
        _integer(stop, "stop")
        if start >= stop:
            raise ValueError("start must be less than stop")
        if type(delta) is not int:
            raise ValueError("delta must be an integer")
        identity = (shard, change_id)
        if identity in self.seen:
            return
        self.batches.add(table, start, stop, delta, self.current_pass)
        self.seen.add(identity)

    def checkpoint(self, shard, position):
        self._shard(shard)
        _integer(position, "position")
        self.progress.report(shard, position)

    def tick(self, passes=1):
        _integer(passes, "passes")
        self.current_pass += passes

    def publish(self):
        return self.publication.publish(self.batches, self.progress.position, self.gap)

    def compact(self):
        return self.retention.compact(self.batches, self.progress.position, self.current_pass)

    def status(self):
        return {
            "pass": self.current_pass,
            "checkpoint": self.progress.position,
            "batches": [batch.record() for batch in self.batches.ordered()],
        }
