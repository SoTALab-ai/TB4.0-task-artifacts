class Progress:
    def __init__(self, shards):
        self.positions = {shard: 0 for shard in shards}
        self.position = 0

    def register(self, shard):
        self.positions.setdefault(shard, 0)
        self.position = min(self.positions.values())

    def report(self, shard, position):
        self.positions[shard] = max(self.positions[shard], position)
        self.position = min(self.positions.values())
