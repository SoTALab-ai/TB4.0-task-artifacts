class Retention:
    def __init__(self, gap, retention, stale_passes):
        self.gap = gap
        self.retention = retention
        self.stale_passes = stale_passes

    def compact(self, batches, boundary, current_pass):
        removed = sorted((
            batch.batch_id for batch in batches.items.values()
            if boundary > batch.stop + self.gap + self.retention
            or current_pass - batch.created_pass > self.stale_passes
        ), key=lambda batch_id: int(batch_id[1:]))
        for batch_id in removed:
            del batches.items[batch_id]
        return removed
