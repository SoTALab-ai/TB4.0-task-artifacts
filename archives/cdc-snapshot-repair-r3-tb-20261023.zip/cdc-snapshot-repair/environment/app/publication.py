class Publication:
    def __init__(self, page_size):
        self.page_size = page_size
        self.next_receipt_id = 1

    def publish(self, batches, boundary, gap):
        pages = []
        for batch in batches.ordered():
            if batch.stop + gap > boundary:
                continue
            contents = batch.contents()
            previous = batch.last_receipt
            if previous is not None and all(
                previous[key] == value for key, value in contents.items()
            ):
                continue
            receipt = {
                "receipt_id": f"R{self.next_receipt_id:08d}",
                **contents,
            }
            self.next_receipt_id += 1
            pages.append({
                "batch_id": batch.batch_id,
                "table": batch.table,
                "withdrawn": [] if previous is None else [dict(previous)][:self.page_size],
                "snapshot": dict(receipt),
            })
            batch.last_receipt = receipt
        return pages
