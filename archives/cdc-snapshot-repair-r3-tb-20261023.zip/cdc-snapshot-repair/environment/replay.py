import argparse
import json
from pathlib import Path

from app import SnapshotService


METHODS = {
    "register_shard", "change", "checkpoint", "tick", "publish", "compact", "status"
}


def replay(path):
    with path.open(encoding="utf-8") as handle:
        header = json.loads(next(handle))
        if set(header) != {"config"}:
            raise ValueError("first line must contain config")
        service = SnapshotService(path.parent, **header["config"])
        for line_number, raw in enumerate(handle, 2):
            call = json.loads(raw)
            op = call.pop("op")
            if op not in METHODS:
                raise ValueError(f"unsupported operation: {op}")
            returned = getattr(service, op)(**call)
            print(json.dumps({
                "line": line_number,
                "op": op,
                "returned": returned,
                "status": service.status(),
            }, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Replay capture operations")
    parser.add_argument("log", type=Path)
    replay(parser.parse_args().log)
