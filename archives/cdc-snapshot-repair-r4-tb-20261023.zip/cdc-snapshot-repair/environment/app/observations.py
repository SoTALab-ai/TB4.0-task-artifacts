class CaptureObservations:
    def __init__(self, shards):
        self.records = {shard: [] for shard in shards}

    def register(self, shard):
        self.records.setdefault(shard, [])

    def report(self, shard, position, current_pass):
        self.records[shard].append((current_pass, position))

    def transaction(self, shard, current_pass):
        self.records[shard].append((current_pass, None))

    def certified(self, shard):
        return max((position for _, position in self.records[shard]
                    if position is not None), default=0)

    def progress_pass(self, shard):
        furthest = recorded_pass = 0
        for current_pass, position in self.records[shard]:
            if position is not None and position > furthest:
                furthest, recorded_pass = position, current_pass
        return recorded_pass
