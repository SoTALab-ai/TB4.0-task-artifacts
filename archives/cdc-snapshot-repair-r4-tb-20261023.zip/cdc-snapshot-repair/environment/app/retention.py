class Retention:
    def __init__(self, gap, retention, stale_passes):
        self.gap = gap
        self.retention = retention
        self.stale_passes = stale_passes

    def ordinary_candidates(self, batches, boundary, current_pass, publication, ledger):
        for batch in batches.items.values():
            quiet = current_pass - batches.opened_pass(batch)
            if (boundary > batch.stop + self.gap + self.retention
                    and quiet > self.retention
                    and not publication.pending_for(batch, ledger)):
                yield batch

    def idle_candidates(self, batches, current_pass):
        for batch in batches.items.values():
            if current_pass - batch.created_pass > self.stale_passes:
                yield batch

    def _retire(self, batch, batches, ledger):
        ledger.archive(batch.history_ids)
        del batches.items[batch.batch_id]

    def compact(self, batches, boundary, current_pass, publication, ledger):
        ordinary = self.ordinary_candidates(
            batches, boundary, current_pass, publication, ledger
        )
        candidates = {batch.batch_id: batch for batch in ordinary}
        candidates.update((batch.batch_id, batch)
                          for batch in self.idle_candidates(batches, current_pass))
        removed = sorted(candidates, key=lambda batch_id: int(batch_id[1:]))
        for batch_id in removed:
            self._retire(candidates[batch_id], batches, ledger)
        return removed
