class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def pending_for(self, batch, ledger):
        receipts = ledger.posted(batch.history_ids)
        previous = next((receipt for receipt in receipts
                         if receipt["receipt_id"] == batch.last_receipt_id), None)
        if previous is not None and all(
            previous[key] == value for key, value in batch.contents().items()
        ):
            return []
        return receipts

    def publish_one(self, batch, boundary, gap, ledger):
        if batch.stop + gap > boundary:
            return None
        pending = self.pending_for(batch, ledger)
        if pending:
            withdrawn = ledger.withdraw(pending[:self.page_size])
            if not ledger.posted(batch.history_ids):
                batch.last_receipt_id = None
            return {"batch_id": batch.batch_id, "table": batch.table,
                    "withdrawn": withdrawn, "snapshot": None}
        if batch.last_receipt_id is not None:
            return None
        receipt = ledger.post(batch.batch_id, batch.contents())
        batch.last_receipt_id = receipt["receipt_id"]
        return {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": [], "snapshot": receipt}

    def publish(self, batches, boundary, gap, ledger):
        pages = []
        for batch in batches.ordered():
            page = self.publish_one(batch, boundary, gap, ledger)
            if page is not None:
                pages.append(page)
        return pages
