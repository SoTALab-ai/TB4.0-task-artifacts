class ReceiptLedger:
    def __init__(self):
        self.entries = {}
        self.next_id = 1

    def post(self, history_id, contents):
        receipt = {"receipt_id": f"R{self.next_id:08d}", **contents}
        self.next_id += 1
        self.entries[receipt["receipt_id"]] = {
            "history_id": history_id, "receipt": receipt, "state": "posted"
        }
        return dict(receipt)

    def posted(self, history_ids):
        return [dict(entry["receipt"]) for entry in self.entries.values()
                if entry["history_id"] in history_ids and entry["state"] == "posted"]

    def withdraw(self, receipts):
        withdrawn = []
        for receipt in receipts:
            entry = self.entries[receipt["receipt_id"]]
            if entry["state"] != "posted":
                raise ValueError("receipt is not posted")
            entry["state"] = "withdrawn"
            withdrawn.append(dict(entry["receipt"]))
        return withdrawn

    def archive(self, history_ids):
        for receipt in self.posted(history_ids):
            self.entries[receipt["receipt_id"]]["state"] = "archived"
