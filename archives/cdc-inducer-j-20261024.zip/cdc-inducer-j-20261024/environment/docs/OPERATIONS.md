# Finance reconciliation contract

## Service and inputs

`from app import SnapshotService` exposes this interface:

```text
SnapshotService(materials_dir, shards, gap, retention, stale_passes, page_size=2)
register_shard(shard) -> None
change(shard, change_id, source_table, start, stop, delta) -> None
checkpoint(shard, position) -> None
tick(passes=1) -> None
publish() -> list[page]
compact() -> list[str]
status() -> {pass: int, checkpoint: int, batches: list[batch]}
```

`materials_dir` contains `tables.csv`, whose columns are `source_table` and
`finance_table`. A source name occurs once and maps to one finance destination.
Source and destination names are nonempty strings. Several sources may share a
destination. Callers supply valid catalogs and may use valid names other than
those in the supplied material.

`shards` is a nonempty list of distinct nonempty strings. `register_shard` enrolls
another nonempty shard name and is idempotent for a registered name. Registration
is administrative enrollment. `gap`, `retention`, and `stale_passes` are
nonnegative integers; `page_size` is a positive integer.

A transaction envelope consists of `shard`, `change_id`, `source_table`, `start`,
`stop`, and `delta`. Its commit range is half-open, `[start, stop)`, with integer
positions satisfying `0 <= start < stop`. `delta` is a signed integer. Every
commit position uses the same scale. `change_id` is a nonempty string.

Delivery identity is `(shard, change_id)`. An exact retry carries its original
payload and adds no transaction work, amount, or count. This remains true after
its operational records have been removed. The same `change_id` on another shard
is a distinct delivery.

Unknown shards or sources, invalid or empty names, invalid ranges, invalid
constructor parameters, noninteger amounts, and negative or noninteger positions
or pass counts raise `ValueError`. Booleans are not integers. A failed call leaves
all service state unchanged, including future identifiers and activity. Callers
guarantee valid catalogs, exact retries, and the checkpoint promise below;
detecting violations of these guarantees is outside the task. Calls are
sequential.

## Retained reconciliation histories

For each finance destination, retained envelopes form maximal connected batches.
In order of range start, a next envelope belongs to the same batch when its start
is no greater than the greatest preceding stop plus `gap`. This connectivity is
transitive. Different source tables mapped to the same destination participate in
the same grouping.

A batch describes all its unique envelopes with:

| Field | Meaning |
| --- | --- |
| `batch_id` | Its live operational identifier |
| `table` | Finance destination |
| `start` | Minimum envelope start |
| `stop` | Maximum envelope stop |
| `net` | Sum of envelope deltas |
| `changes` | Number of unique envelopes |

A disconnected insertion receives the next globally allocated batch identifier,
in `B00000001` style. An insertion that touches existing batches retains the oldest
allocated touched identifier. Other joined identifiers cease to be live. The new
envelope contributes exactly once.

A retained history includes the current batch and its earlier retained batches
that were revised or joined to form it. Those earlier stages are its retained
lineage. A retired history has left the operational index; its archived finance
posting belongs to that completed history.

## Capture certification and readiness

`checkpoint(shard, position)` is the shard's cumulative certification that it has
already sent all its envelopes with `stop <= position`. Consequently, a previously
unseen envelope has a stop greater than that shard's prior reported checkpoint.
A lower checkpoint report adds no coverage. A newly enrolled shard starts at
position zero.

The service checkpoint is the settled common certified capture position. It
starts at zero, never retreats, and reflects capture certification. Maintenance
time alone supplies no capture certification. Transaction traffic is not a
checkpoint. A late or newly enrolled agent can deliver revisions to settled
history. Reports from agents that continue working still constrain further
settlement.

A working agent reports a checkpoint within every two maintenance passes. An
unchanged checkpoint is a normal report during a long transaction. Capture
traffic consists of transaction deliveries and checkpoint reports. A paused agent
sends no traffic; later traffic expresses resumption. There is no pause or resume
API.

`tick(passes)` advances only the maintenance clock by the given count. The clock
starts at zero and is exposed as `pass` in `status()`.

A retained batch is ready when `batch.stop + gap <= service checkpoint`. A
checkpoint report covers a batch when its reported position reaches the batch's
stop plus `gap`. During ordinary capture, work covered by every enrolled agent's
current report is available on the next `publish()` call. During a sustained partial pause, reconciliation covered in
common by the working agents' reports must become ready within 30 maintenance
passes. During sustained silence of all agents, reconciliation covered by at
least one checkpoint report already received must also become ready within 30
maintenance passes. These readiness guarantees apply while their conditions and
coverage persist. Sending finance output still requires a `publish()` call.

## Finance receipts and corrections

A receipt has exactly these fields:

```text
{receipt_id, start, stop, net, changes}
```

Its range, amount, and count describe the corresponding batch. Receipt identifiers
are allocated globally in `R00000001` style, only when a new receipt is returned.
Each receipt identifier identifies a distinct financial instance. Equal amounts
or ranges do not collapse distinct instances.

`publish()` returns a list of pages, ordered by the current
`(table, start, batch_id)`. There is at most one page per current batch per call.
A page has exactly this shape:

```text
{batch_id, table, withdrawn: [receipt, ...], snapshot: receipt | null}
```

`snapshot` is the newly posted receipt, when one is returned. Finance applies a
page's withdrawals before its snapshot. A posted receipt is an earlier returned
snapshot that has not been withdrawn or moved into an archived history. Every
withdrawal exactly copies an actual, still-posted receipt from the affected
retained lineage. An instance is withdrawn at most once. Withdrawals within a
page appear in receipt allocation order, and distinct identifiers retain their
multiplicity.

Subject to the correction process below, finance's live postings must describe current ready reconciliation. Delayed
transactions may revise a previously posted batch or combine several posted
histories. Such changes require obsolete financial instances to be withdrawn. A
stale posting must be withdrawn even while its revised batch is not yet ready.
After a ready correction is drained, its current history has one up-to-date
receipt and no obsolete instances. An unchanged valid current receipt is not
reissued.

Corrections may span calls. When old posted instances need correction, the page
withdraws at least one and at most `page_size` of them. Underfilled pages are
legal. Any subset of old instances may be selected across calls, provided each
page orders its withdrawals by allocation. A replacement receipt is returned
only after all affected old instances have been withdrawn and the batch is
ready. It may accompany the last withdrawals or follow them on the next call.
With no new input, repeated `publish()` calls drain a ready correction in at most
the number of affected old instances plus one calls. New input may arrive between
pages.

A ready batch with no earlier receipt history receives its first receipt on that
`publish()` call. Empty pages are omitted. After all available publication work
is drained, repeated calls return `[]`.

## Publication during storage maintenance

Every accepted unique transaction must have a correct financial history. Once its
batch is ready, subsequent publishing must be able to deliver that history.
Storage maintenance cannot change the financial obligations created by accepted
transactions. This applies throughout ordinary operation, including any
interleaving of publishing and storage maintenance.

`compact()` actually removes retired batches from the operational index and
returns their batch identifiers in allocation order. It sends no finance pages.

## Maintenance budgets

Ordinary retention is measured in certified commit positions. It expires strictly
beyond `batch.stop + gap + retention`: the service checkpoint must be greater than
that value. It is independent of the maintenance clock.

`stale_passes` is a separate inactivity budget measured in maintenance passes.
Recently received reconciliation work is entitled to this budget. Finished work
that has received no new unique transaction work for longer than `stale_passes`
is idle. Queries, checkpoint reports, finance reads, and exact retries are not new
transaction work.

On a `compact()` call after finance has received the current up-to-date posting,
ordinary retention expiry requires removal on that call if none of the history's
financial work is missing and no obsolete posting remains. Under the same output
conditions, exceeding the inactivity budget independently requires removal on
that call. Neither applicable budget has an additional waiting period. The durable
financial guarantees above continue to apply to these maintenance calls.

## Finance after operational removal

When finance has received the final up-to-date posting, none of the history's
financial work is missing, and no obsolete posting remains, finance archives that
final posting when the history leaves the operational index. An archived receipt
is immutable. A later transaction can start a new retained history without
withdrawing receipts archived for an earlier history.

## Status

`status()` returns exactly:

```text
{pass: int, checkpoint: int, batches: [batch, ...]}
```

Each batch record has exactly `batch_id`, `table`, `start`, `stop`, `net`, and
`changes`, as defined above. Records are ordered by `(table, start, batch_id)` and
expose no receipt history fields. `status()` is a query.

