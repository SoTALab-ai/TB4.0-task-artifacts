from dataclasses import dataclass, field


@dataclass
class HistoryNode:
    postings: dict = field(default_factory=dict)
    last_sent: str | None = None
    parents: list = field(default_factory=list)


class ReceiptLedger:
    def __init__(self):
        self.next_id = 1

    def post(self, node, contents):
        receipt = {"receipt_id": f"R{self.next_id:08d}", **contents}
        self.next_id += 1
        node.postings[receipt["receipt_id"]] = {
            "receipt": receipt, "state": "posted"
        }
        node.last_sent = receipt["receipt_id"]
        return dict(receipt)

    def withdraw(self, node, receipt_ids):
        withdrawn = []
        for receipt_id in receipt_ids:
            entry = node.postings[receipt_id]
            if entry["state"] != "posted":
                raise ValueError("receipt is not posted")
            entry["state"] = "withdrawn"
            withdrawn.append(dict(entry["receipt"]))
        return withdrawn

    def archive(self, node):
        for parent in node.parents:
            self.archive(parent)
        for entry in node.postings.values():
            if entry["state"] == "posted":
                entry["state"] = "archived"
