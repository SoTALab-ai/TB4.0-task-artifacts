class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def publish_one(self, batch, boundary, gap, ledger):
        node = batch.history
        previous = node.postings.get(node.last_sent)
        if previous is not None and previous["state"] == "posted":
            if all(previous["receipt"][key] == value
                   for key, value in batch.contents().items()):
                return None
            withdrawn = ledger.withdraw(node, [node.last_sent][:self.page_size])
            return {"batch_id": batch.batch_id, "table": batch.table,
                    "withdrawn": withdrawn, "snapshot": None}
        if batch.stop + gap > boundary:
            return None
        receipt = ledger.post(node, batch.contents())
        return {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": [], "snapshot": receipt}

    def publish(self, batches, boundary, gap, ledger):
        pages = []
        for batch in batches.ordered():
            page = self.publish_one(batch, boundary, gap, ledger)
            if page is not None:
                pages.append(page)
        return pages
