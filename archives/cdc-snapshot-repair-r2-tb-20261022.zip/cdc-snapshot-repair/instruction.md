# Restore reliable finance reconciliation

Capture agents send transaction ranges to the finance reconciliation service in `/app/app`. Operators report that finance updates sometimes stop during capture maintenance. After delayed deliveries, earlier postings can remain beside their replacements or disappear from later corrections. Retention maintenance can also remove reconciliation work, including work that recently received traffic, while some state remains after a completed shift should have been reclaimed.

Make the service satisfy the business contract in `/app/docs/OPERATIONS.md`. The file formats and replay command are described in `/app/docs/FILES.md`; operational inputs are available in `/app/materials/`.

Deliver the complete `/app/app` package. Keep `/app/app/__init__.py`, the documents, replay program, and materials unchanged. You may change or add other modules inside `/app/app`. Use only the Python standard library.

You have 28800 seconds to complete this task.
