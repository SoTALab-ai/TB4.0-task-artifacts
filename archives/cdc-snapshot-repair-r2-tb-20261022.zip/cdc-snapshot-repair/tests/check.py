"""Independent retained-range and external-finance-ledger acceptance checks."""
import argparse
import copy
import csv
import io
import json
import os
from pathlib import Path
import random
import shutil
import signal
import subprocess
import sys
import tempfile
import traceback

HERE = Path(__file__).resolve().parent
CATALOG = 'source_table,finance_table\npos.sales,fin_sales\npos.refunds,fin_sales\nledger.entries,fin_ledger\naudit.fees,fin_fees\n'
RECEIPT_KEYS = {'receipt_id', 'start', 'stop', 'net', 'changes'}
BATCH_KEYS = {'batch_id', 'table', 'start', 'stop', 'net', 'changes'}
PAGE_KEYS = {'batch_id', 'table', 'withdrawn', 'snapshot'}
CHECKS = []


def check(name, category):
    def register(fn):
        CHECKS.append((name, category, fn))
        return fn
    return register


def ch(shard, cid, start, stop, delta=1, table='pos.sales'):
    return dict(op='change', shard=shard, change_id=cid, source_table=table,
                start=start, stop=stop, delta=delta)


def cp(shard, position):
    return dict(op='checkpoint', shard=shard, position=position)


def tick(passes=1):
    return dict(op='tick', passes=passes)


def pub(through=None):
    return dict(op='publish') if through is None else dict(op='publish', through=through)


def gc(through=None):
    return dict(op='compact') if through is None else dict(op='compact', through=through)


def alloc(value):
    return int(value[1:])


def integer(value, minimum=0):
    return type(value) is int and value >= minimum


def name(value):
    return isinstance(value, str) and bool(value)


def validate_schedule(ops, shards, catalog):
    positions = {s: 0 for s in shards}
    tables = {r['source_table'] for r in csv.DictReader(io.StringIO(catalog))}
    seen, count = {}, 0
    for index, op in enumerate(ops):
        if op['op'] == 'register_shard' and name(op['shard']):
            positions.setdefault(op['shard'], 0)
        elif op['op'] == 'checkpoint' and name(op['shard']) and op['shard'] in positions and integer(op['position']):
            positions[op['shard']] = max(positions[op['shard']], op['position'])
        elif op['op'] == 'change':
            valid = (name(op['shard']) and op['shard'] in positions and name(op['change_id'])
                     and name(op['source_table']) and op['source_table'] in tables
                     and integer(op['start']) and integer(op['stop']) and op['start'] < op['stop']
                     and type(op['delta']) is int)
            if not valid:
                continue
            key = op['shard'], op['change_id']
            if key in seen:
                assert op == seen[key], f'fixture redelivery differs at call {index}'
            else:
                assert op['stop'] > positions[op['shard']], f'fixture contradicts shard checkpoint at call {index}'
                seen[key] = op
                count += 1
    return {'calls': len(ops), 'new_envelopes': count, 'checkpoint_promises_valid': True}


class FinanceOracle:
    """Rebuild connected components from raw retained envelopes after every accepted change."""
    def __init__(self, config, catalog):
        self.cfg = config
        self.tables = {r['source_table']: r['finance_table'] for r in csv.DictReader(io.StringIO(catalog))}
        self.positions = {s: 0 for s in config['shards']}
        self.reports = {s: 0 for s in config['shards']}
        self.highest = self.clock = self.frontier = 0
        self.seen, self.records, self.parts, self.posted, self.archived = set(), {}, {}, {}, {}
        self.batch_serial = self.receipt_serial = 0

    def valid(self, op):
        kind = op['op']
        if kind == 'register_shard':
            return name(op.get('shard'))
        if kind in ('checkpoint', 'change'):
            if not name(op.get('shard')) or op['shard'] not in self.positions:
                return False
        if kind == 'checkpoint':
            return integer(op.get('position'))
        if kind == 'change':
            return (name(op.get('change_id')) and name(op.get('source_table')) and op['source_table'] in self.tables
                    and integer(op.get('start')) and integer(op.get('stop')) and op['start'] < op['stop']
                    and type(op.get('delta')) is int)
        if kind == 'tick':
            return integer(op.get('passes', 1))
        if kind in ('publish', 'compact'):
            return op.get('through') is None or integer(op['through'])
        return kind == 'status'

    def public(self, part):
        rows = [self.records[k] for k in part['members']]
        return {'batch_id': part['id'], 'table': rows[0]['table'], 'start': min(r['start'] for r in rows),
                'stop': max(r['stop'] for r in rows), 'net': sum(r['delta'] for r in rows), 'changes': len(rows)}

    def contents(self, part):
        return {k: v for k, v in self.public(part).items() if k not in ('batch_id', 'table')}

    def represented(self, part):
        return len(part['receipts']) == 1 and all(
            self.posted[next(iter(part['receipts']))]['record'][k] == v for k, v in self.contents(part).items())

    def insert(self, op):
        key = op['shard'], op['change_id']
        if key in self.seen:
            return
        self.seen.add(key)
        self.records[key] = {'table': self.tables[op['source_table']], 'start': op['start'],
                             'stop': op['stop'], 'delta': op['delta'], 'clock': self.clock}
        owner = {k: part for part in self.parts.values() for k in part['members']}
        groups, current, right, table = [], [], None, None
        for k, row in sorted(self.records.items(), key=lambda item: (item[1]['table'], item[1]['start'], item[1]['stop'], item[0])):
            if current and (row['table'] != table or row['start'] > right + self.cfg['gap']):
                groups.append(current)
                current = []
            current.append(k)
            right = max(right, row['stop']) if len(current) > 1 else row['stop']
            table = row['table']
        if current:
            groups.append(current)
        rebuilt = {}
        for members in groups:
            ancestors = {owner[k]['id'] for k in members if k in owner}
            if ancestors:
                ident = min(ancestors, key=alloc)
            else:
                self.batch_serial += 1
                ident = f'B{self.batch_serial:08d}'
            refs = set().union(*(self.parts[a]['receipts'] for a in ancestors)) if ancestors else set()
            rebuilt[ident] = {'id': ident, 'members': members, 'receipts': refs}
        self.parts = rebuilt

    def apply_pages(self, pages, cut):
        assert isinstance(pages, list), 'publish must return a list'
        ordered = sorted(self.parts.values(), key=lambda p: (self.public(p)['table'], self.public(p)['start'], p['id']))
        needed = [p for p in ordered if p['receipts'] and not (self.represented(p) and self.public(p)['stop'] + self.cfg['gap'] <= cut)
                  or not p['receipts'] and self.public(p)['stop'] + self.cfg['gap'] <= cut]
        assert len(pages) == len(needed), 'missing or extra finance page for current retained work'
        for page, part in zip(pages, needed):
            assert isinstance(page, dict) and set(page) == PAGE_KEYS, 'page fields'
            assert page['batch_id'] == part['id'] and page['table'] == self.public(part)['table'], 'page ordering/lineage'
            old = set(part['receipts'])
            withdrawals = page['withdrawn']
            assert isinstance(withdrawals, list) and len(withdrawals) <= self.cfg['page_size'], 'page capacity'
            if old:
                assert withdrawals, 'page with old postings must withdraw at least one'
            ids = []
            for record in withdrawals:
                assert isinstance(record, dict) and set(record) == RECEIPT_KEYS, 'withdrawal fields'
                ident = record['receipt_id']
                assert ident in part['receipts'] and ident in self.posted, 'withdrawal is not a real unwithdrawn ancestor'
                assert record == self.posted[ident]['record'], 'withdrawal changed the actual old receipt'
                ids.append(ident)
                part['receipts'].remove(ident)
                del self.posted[ident]
            assert ids == sorted(ids, key=alloc), 'withdrawals must be in allocation order'
            complete = self.public(part)['stop'] + self.cfg['gap'] <= cut
            snap = page['snapshot']
            if part['receipts'] or not complete:
                assert snap is None, 'replacement posted before old receipts drained or range complete'
            else:
                assert isinstance(snap, dict) and set(snap) == RECEIPT_KEYS, 'current snapshot required after old postings drain'
                self.receipt_serial += 1
                assert snap['receipt_id'] == f'R{self.receipt_serial:08d}', 'receipt allocation'
                assert {k: snap[k] for k in self.contents(part)} == self.contents(part), 'snapshot differs from independently rebuilt retained envelopes'
                self.posted[snap['receipt_id']] = {'table': page['table'], 'record': copy.deepcopy(snap)}
                part['receipts'].add(snap['receipt_id'])

    def compact(self, returned, cut):
        expected = []
        for ident, part in sorted(self.parts.items(), key=lambda item: alloc(item[0])):
            current = self.public(part)
            touched = max(self.records[k]['clock'] for k in part['members'])
            expired = cut > current['stop'] + self.cfg['gap'] + self.cfg['retention']
            inactive = self.clock - touched > self.cfg['stale_passes']
            if self.represented(part) and (expired or inactive):
                expected.append(ident)
        assert returned == expected, 'compaction lost owed finance transitions or failed to reclaim delivered expired work'
        for ident in expected:
            part = self.parts.pop(ident)
            for rid in part['receipts']:
                self.archived[rid] = self.posted.pop(rid)
            for key in part['members']:
                del self.records[key]

    def observe(self, op, row):
        assert row['op'] == op['op'], 'worker operation mismatch'
        if not self.valid(op):
            assert row['error'] and row['error']['type'] == 'ValueError', 'invalid call must raise ValueError'
        else:
            assert row['error'] is None, f"{op['op']} raised {row['error']}"
            kind = op['op']
            if kind == 'register_shard':
                if op['shard'] not in self.positions:
                    self.positions[op['shard']] = 0
                    self.reports[op['shard']] = self.clock
            elif kind == 'checkpoint':
                self.positions[op['shard']] = max(self.positions[op['shard']], op['position'])
                self.reports[op['shard']] = self.clock
                self.highest = max(self.highest, op['position'])
            elif kind == 'tick':
                self.clock += op.get('passes', 1)
            elif kind == 'change':
                self.reports[op['shard']] = self.clock
                self.insert(op)
        status = row['status']
        assert isinstance(status, dict) and set(status) == {'pass', 'checkpoint', 'batches'}, 'status fields'
        assert status['pass'] == self.clock, 'maintenance counter or invalid-call atomicity'
        checkpoint = status['checkpoint']
        assert integer(checkpoint) and self.frontier <= checkpoint <= self.highest, 'coverage regressed or invented input confirmation'
        known_running = [position for shard, position in self.positions.items() if self.clock - self.reports[shard] <= 2]
        if known_running:
            assert checkpoint <= max(self.frontier, min(known_running)), 'new coverage ignored a continuously reporting low checkpoint'
        self.frontier = checkpoint
        if row['error'] is None:
            if op['op'] == 'publish':
                self.apply_pages(row['return'], checkpoint if op.get('through') is None else op['through'])
            elif op['op'] == 'compact':
                self.compact(row['return'], checkpoint if op.get('through') is None else op['through'])
            elif op['op'] != 'status':
                assert row['return'] is None, 'mutator return value'
        expected = sorted((self.public(p) for p in self.parts.values()), key=lambda p: (p['table'], p['start'], p['batch_id']))
        assert status['batches'] == expected, 'retained batch state differs from sort-and-scan envelope oracle'
        if op['op'] == 'status' and row['error'] is None:
            assert row['return'] == status, 'status return differs from observation'


class Runner:
    def __init__(self, candidate, isolate=False):
        if isolate and (not hasattr(os, 'geteuid') or os.geteuid() != 0):
            raise RuntimeError('--isolate requires root')
        self.isolate = isolate
        self.source = Path(candidate) / 'app'
        assert not self.source.is_symlink(), 'candidate app must not be a symlink'
        source = self.source.resolve()
        for path in source.rglob('*'):
            assert not path.is_symlink() or path.resolve().is_relative_to(source), 'candidate symlink escapes app'
        self.root = Path(tempfile.mkdtemp(prefix='cdc-r2-check-'))
        self.root.chmod(0o755)
        shutil.copytree(source, self.root / 'candidate/app', ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        shutil.copyfile(HERE / 'worker.py', self.root / 'worker.py')
        for path in self.root.rglob('*'):
            path.chmod(0o755 if path.is_dir() else 0o644)
        self.receipts, self.schedule_validation = [], []

    def _drop(self):
        if self.isolate:
            os.setgroups([])
            os.setgid(65534)
            os.setuid(65534)

    def process(self, args, cwd, data=None, timeout=30):
        proc = subprocess.Popen(args, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            text=True, start_new_session=True, preexec_fn=self._drop,
            env={'PATH': '/usr/local/bin:/usr/bin:/bin', 'PYTHONDONTWRITEBYTECODE': '1', 'HOME': str(cwd)})
        try:
            out, err = proc.communicate(data, timeout=timeout)
            return subprocess.CompletedProcess(args, proc.returncode, out, err)
        finally:
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if proc.poll() is None:
                proc.communicate()

    def invoke(self, request, catalog=CATALOG):
        material = Path(tempfile.mkdtemp(prefix='catalog-', dir=self.root))
        material.chmod(0o755)
        (material / 'tables.csv').write_text(catalog)
        (material / 'tables.csv').chmod(0o644)
        proc = self.process([sys.executable, '-I', '-B', str(self.root / 'worker.py'),
                             str(self.root / 'candidate'), str(material)], self.root, json.dumps(request))
        assert proc.returncode == 0, 'candidate process failed: ' + proc.stderr[-400:]
        return json.loads(proc.stdout)

    def run(self, ops, shards=('a', 'b'), gap=3, retention=20, stale_passes=50, page_size=2, catalog=CATALOG):
        config = dict(shards=list(shards), gap=gap, retention=retention, stale_passes=stale_passes, page_size=page_size)
        self.schedule_validation.append(validate_schedule(ops, shards, catalog))
        data = self.invoke({'config': config, 'operations': ops}, catalog)
        rows = data['observations']
        assert len(rows) == len(ops), 'missing observations'
        oracle = FinanceOracle(config, catalog)
        for op, row in zip(ops, rows):
            oracle.observe(op, row)
        self.receipts.append({'config': config, 'operations': ops, 'observations': rows})
        return rows


def pages(rows):
    return [p for row in rows if row['op'] == 'publish' and row['return'] for p in row['return']]


def snapshots(rows):
    return [p['snapshot'] for p in pages(rows) if p['snapshot'] is not None]


@check('basic-range-catalog-and-identifiers', 'range')
def _(run):
    for catalog, tables in [(CATALOG, ('pos.sales', 'pos.refunds', 'ledger.entries')),
        ('source_table,finance_table\nfeed.alpha,zeta\nfeed.beta,zeta\nother,audit\n', ('feed.alpha', 'feed.beta', 'other'))]:
        ops = [ch('west', 'a', 7, 12, -(1 << 80), tables[0]), ch('east', 'a', 14, 18, 3, tables[1]),
               ch('west', 'b', 30, 34, 9, tables[2]), pub(21), pub(50), pub(50)]
        rows = run(ops, shards=('west', 'east'), gap=2, catalog=catalog)
        assert len(snapshots(rows)) == 2 and rows[-1]['return'] == []


@check('transitive-range-bridge-independent-reconstruction', 'range')
def _(run):
    rng = random.Random(221019)
    for seed in range(8):
        gap = rng.randrange(0, 6)
        width = gap + 5
        inputs = [(0, width), (width + gap + 3, 2 * width + gap + 3),
                  (2 * width + 2 * gap + 6, 3 * width + 2 * gap + 6),
                  (width, width + gap + 4), (2 * width + gap + 3, 2 * width + 2 * gap + 7)]
        rng.shuffle(inputs)
        ops = [ch('a' if i % 2 else 'b', f'c{i}', start, stop, rng.randrange(-20, 30))
               for i, (start, stop) in enumerate(inputs)]
        ops += [dict(ops[1]), pub(1000), pub(1000)]
        rows = run(ops, gap=gap)
        assert len(rows[-1]['status']['batches']) == 1, f'transitive grouping seed {seed}'


@check('lifetime-shard-identity-and-fresh-lineage', 'range')
def _(run):
    original = ch('a', 'shared', 1, 5, 4)
    ops = [original, dict(original), ch('b', 'shared', 2, 6, 7), pub(100), gc(1000),
           dict(original), ch('a', 'fresh', 1, 5, 3), pub(100)]
    rows = run(ops)
    assert snapshots(rows)[0]['net'] == 11 and snapshots(rows)[1]['net'] == 3
    assert rows[5]['status']['batches'] == [], 'compaction reset lifetime delivery identity'
    assert pages(rows)[1]['withdrawn'] == [], 'fresh lineage withdrew archived finance receipt'


@check('invalid-inputs-atomic-and-future-identifiers', 'range')
def _(run):
    bad = [ch('unknown', 'k', 1, 5), ch('a', '', 1, 5), ch('a', 'k', 1, 5, table='unknown'),
           ch('a', 'k', -1, 5), ch('a', 'k', 5, 5), ch('a', 'k', 6, 5), ch('a', 'k', True, 5),
           ch('a', 'k', 1, 5, True), ch('a', 'k', 1, 5, 1.2), cp('a', True), cp('a', -1),
           cp('unknown', 5), tick(-1), tick(1.2), pub(-1), pub(True), gc(2.1),
           dict(op='register_shard', shard=''), dict(op='register_shard', shard=4)]
    ops = [ch('a', 'first', 1, 5), pub(100)] + bad + [ch('a', 'k', 20, 25), pub(100)]
    rows = run(ops)
    assert all(r['error'] and r['error']['type'] == 'ValueError' for r in rows[2:2 + len(bad)])
    assert snapshots(rows)[-1]['receipt_id'] == 'R00000002'
    # An error must not silently refresh a paused source's activity. Compare
    # future state with the same candidate's error-free schedule, so this
    # atomicity probe does not prescribe an idle implementation.
    ops = [ch('a', 'pending', 12, 17), cp('a', 5), cp('b', 5)]
    for index in range(1, 31):
        ops += [tick(), cp('a', 20 + index)]
        if index == 29:
            ops += [cp('b', True), ch('b', 'bad', 12, 17, table='unknown')]
    rows = run(ops + [pub()], retention=1000, stale_passes=1000)
    clean = [op for op in ops if not (op['op'] == 'checkpoint' and op.get('position') is True)
             and op.get('source_table') != 'unknown']
    comparison = run(clean + [pub()], retention=1000, stale_passes=1000)
    assert rows[-1]['status'] == comparison[-1]['status'], 'failed input refreshed paused-source activity'
    rows = run([ch('a', 'retained', 1, 5), pub(20), tick(8), ch('a', 'bad', 1, 5, True),
                tick(3), gc(0)], retention=1000, stale_passes=10)
    assert len(rows[-1]['return']) == 1, 'failed input refreshed reconciliation activity'


@check('constructor-parameter-validation', 'range')
def _(run):
    runner = run.__self__
    base = dict(shards=['a'], gap=3, retention=20, stale_passes=50, page_size=2)
    for key, value in [('shards', []), ('shards', ['a', 'a']), ('shards', ['']), ('gap', -1),
                       ('gap', True), ('retention', -1), ('stale_passes', 1.5), ('page_size', 0), ('page_size', True)]:
        result = runner.invoke({'config': {**base, key: value}, 'constructor_probe': True})
        assert result['constructor_error'] and result['constructor_error']['type'] == 'ValueError', key


@check('partial-pause-default-entry-readiness', 'coverage')
def _(run):
    ops = [ch('a', 'x', 12, 17, 4), cp('a', 5), cp('b', 5)]
    for index in range(1, 31):
        ops += [tick(), cp('a', 20 + index), pub()]
    rows = run(ops, gap=3, retention=1000, stale_passes=1000)
    assert len(snapshots(rows)) == 1, 'paused shard blocked genuinely covered work after 30 passes'


@check('continuous-equal-low-reports-constrain-new-coverage', 'coverage')
def _(run):
    ops = [ch('a', 'x', 20, 25, 4), cp('a', 50), cp('b', 7)]
    for index in range(30):
        ops += [tick(), cp('a', 60 + index), cp('b', 7), pub()]
    boundary = len(ops)
    for index in range(30):
        ops += [tick(), cp('a', 90 + index), pub()]
    rows = run(ops)
    assert not snapshots(rows[:boundary]) and len(snapshots(rows[boundary:])) == 1


@check('all-paused-supported-work-without-manufactured-progress', 'coverage')
def _(run):
    ops = [ch('a', 'early', 20, 25, 2), ch('a', 'latest', 59, 65, 1), cp('a', 60), cp('b', 10)]
    ops += [tick(), pub()] * 30
    boundary = len(ops)
    ops += [tick(100), pub()] * 5
    rows = run(ops, gap=3, retention=1000, stale_passes=1000)
    assert len(snapshots(rows[:boundary])) == 1, 'full pause did not release supported earlier batch'
    assert len(snapshots(rows)) == 1, 'elapsed service time released unsupported latest batch'


@check('registration-and-resumption-preserve-settled-coverage', 'coverage')
def _(run):
    ops = [ch('a', 'x', 10, 15), cp('a', 60), pub(), dict(op='register_shard', shard='b'),
           cp('b', 0), ch('b', 'late', 12, 18), pub(), dict(op='register_shard', shard='a'), cp('b', 1), pub()]
    rows = run(ops, shards=('a',))
    assert len(snapshots(rows)) == 2 and snapshots(rows)[-1]['net'] == 2


@check('operator-cuts-do-not-mutate-capture-progress', 'coverage')
def _(run):
    rows = run([ch('a', 'x', 10, 20), cp('a', 1), cp('b', 1), pub(100), gc(2), dict(op='status')])
    assert rows[-1]['status']['checkpoint'] == 1, 'audited call boundary changed source progress'


def two_receipts(equal=False):
    return [ch('a', 'left', 0, 3, 4), ch('a', 'right', 20, 23, 4 if equal else 9),
            pub(100), ch('b', 'bridge', 5, 18, 2)]


@check('multiancestor-actual-receipts-and-bridge-once', 'history')
def _(run):
    rows = run(two_receipts() + [pub(100), pub(100), pub(100)], page_size=3)
    assert sum(len(page['withdrawn']) for page in pages(rows)[2:]) == 2
    assert snapshots(rows)[-1]['net'] == 15 and snapshots(rows)[-1]['changes'] == 3


@check('equal-amounts-are-distinct-finance-receipts', 'history')
def _(run):
    rows = run(two_receipts(True) + [pub(100)] * 4, page_size=1)
    withdrawals = [x for p in pages(rows)[2:] for x in p['withdrawn']]
    assert len(withdrawals) == 2 and len({x['receipt_id'] for x in withdrawals}) == 2
    assert snapshots(rows)[-1]['net'] == 10


@check('reopened-incomplete-range-withdraws-before-replacement', 'history')
def _(run):
    rows = run([ch('a', 'first', 0, 4, 3), pub(10), ch('b', 'extension', 5, 20, 8),
                pub(10), pub(10), pub(30), pub(30)])
    assert rows[3]['return'][0]['snapshot'] is None and len(rows[3]['return'][0]['withdrawn']) == 1
    assert rows[4]['return'] == [] and snapshots(rows)[-1]['net'] == 11


@check('bounded-and-underfilled-pages-converge', 'history')
def _(run):
    ops = [ch('a', f'p{i}', i * 20, i * 20 + 3, i + 1) for i in range(5)] + [pub(200)]
    ops += [ch('b', 'joined', 4, 79, 7)] + [pub(200)] * 6 + [pub(200)]
    rows = run(ops, gap=2, page_size=3)
    assert rows[-1]['return'] == [] and len(snapshots(rows)) == 6


@check('new-input-between-partial-pages-never-revives-withdrawn-receipts', 'history')
def _(run):
    ops = [ch('a', f'p{i}', i * 20, i * 20 + 3, i + 1) for i in range(4)] + [pub(100)]
    ops += [ch('b', 'merge', 4, 59, 5), pub(100), ch('b', 'extend', 64, 130, 9), pub(100),
            gc(1000), pub(100), pub(100), gc(1000), pub(200), gc(1000), pub(200)]
    rows = run(ops, gap=2, page_size=1)
    assert rows[9]['return'] == [] and rows[12]['return'] == [], 'pending replacement reclaimed'
    assert snapshots(rows)[-1]['net'] == 24 and rows[-1]['return'] == []


@check('table-isolation-and-repeated-correction-lineages', 'history')
def _(run):
    ops = [ch('a', 'x', 0, 3, 2), ch('a', 'y', 0, 3, 6, 'ledger.entries'), pub(20),
           ch('b', 'extend', 3, 7, 1), pub(20), pub(20), ch('b', 'again', 7, 9, 4), pub(20), pub(20)]
    rows = run(ops)
    assert len(snapshots(rows)) == 4 and rows[-1]['return'] == []


@check('first-receipt-protected-by-both-expiration-paths', 'retention')
def _(run):
    rows = run([ch('a', 'x', 1, 5, 7), gc(1000), tick(50), gc(1000), pub(100), gc(1000)], stale_passes=10)
    assert rows[1]['return'] == rows[3]['return'] == [] and len(rows[-1]['return']) == 1


@check('empty-posting-set-still-owes-incomplete-replacement', 'retention')
def _(run):
    rows = run([ch('a', 'x', 0, 4, 3), pub(10), ch('b', 'extension', 5, 20, 8), pub(10),
                tick(100), gc(1000), pub(30), gc(1000)], stale_passes=10)
    assert rows[5]['return'] == [] and len(rows[-1]['return']) == 1


@check('multiancestor-pending-pages-survive-retention', 'retention')
def _(run):
    rows = run(two_receipts() + [gc(1000), pub(100), gc(1000), pub(100), gc(1000)], page_size=1)
    assert rows[4]['return'] == rows[6]['return'] == [] and len(rows[-1]['return']) == 1


@check('recent-merge-counts-new-envelope-activity', 'retention')
def _(run):
    rows = run([ch('a', 'old', 0, 3, 2), pub(100), tick(50), ch('b', 'new', 20, 23, 3), pub(100),
                ch('b', 'bridge', 5, 18, 7), pub(100), pub(100), gc(0), tick(31), gc(0)],
               retention=1000, stale_passes=30)
    assert rows[8]['return'] == [] and len(rows[-1]['return']) == 1


@check('ordinary-expiry-does-not-acquire-idle-gate', 'retention')
def _(run):
    rows = run([ch('a', 'x', 1, 5, 2), pub(20), gc(13), gc(14), ch('a', 'fresh', 1, 5, 4), pub(20)],
               gap=3, retention=5, stale_passes=1000)
    assert rows[2]['return'] == [] and len(rows[3]['return']) == 1 and pages(rows)[1]['withdrawn'] == []


@check('stale-expiry-not-refreshed-by-redelivery-or-queries', 'retention')
def _(run):
    original = ch('a', 'x', 1, 5, 2)
    rows = run([original, pub(20), tick(8), dict(original), cp('a', 0), dict(op='status'), pub(20),
                tick(3), gc(0)], retention=1000, stale_passes=10)
    assert len(rows[-1]['return']) == 1


@check('protected-public-entry-unchanged', 'integrity')
def _(run):
    expected = HERE / 'frozen/app-init.py'
    assert expected.exists(), 'missing frozen public entry'
    assert (run.__self__.root / 'candidate/app/__init__.py').read_bytes() == expected.read_bytes(), 'protected public __init__.py changed'


@check('public-replay-independent-ledger-and-inputs', 'integration')
def _(run):
    frozen = HERE / 'frozen'
    logs = sorted((frozen / 'materials').glob('*.jsonl'))
    assert logs and (frozen / 'replay.py').exists(), 'missing frozen public replay'
    for log in logs:
        records = [json.loads(line) for line in log.read_text().splitlines() if line.strip()]
        config, ops = records[0]['config'], records[1:]
        catalog = (frozen / 'materials/tables.csv').read_text()
        run(ops, catalog=catalog, **config)
        runner = run.__self__
        work = Path(tempfile.mkdtemp(prefix='replay-', dir=runner.root))
        shutil.copytree(frozen / 'materials', work / 'materials')
        shutil.copyfile(frozen / 'replay.py', work / 'replay.py')
        shutil.copytree(runner.root / 'candidate/app', work / 'app')
        for path in [work, *work.rglob('*')]:
            path.chmod(0o755 if path.is_dir() else 0o644)
        proc = runner.process([sys.executable, '-B', '-E', '-s', 'replay.py', f'materials/{log.name}'], work, timeout=60)
        assert proc.returncode == 0, 'public replay failed: ' + proc.stderr[-300:]
        rows = [json.loads(line) for line in proc.stdout.splitlines() if line.strip()]
        assert len(rows) == len(ops), 'public replay row count'


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--candidate', required=True)
    ap.add_argument('--report')
    ap.add_argument('--isolate', action='store_true')
    args = ap.parse_args()
    runner = Runner(args.candidate, args.isolate)
    checks = []
    try:
        for name_, category, fn in CHECKS:
            before = len(runner.receipts)
            try:
                fn(runner.run)
                row = dict(name=name_, category=category, ok=True)
            except Exception as exc:
                message = str(exc) or type(exc).__name__
                if not isinstance(exc, AssertionError):
                    message = type(exc).__name__ + ': ' + message
                row = dict(name=name_, category=category, ok=False, message=message[:600])
            row['executions'] = len(runner.receipts) - before
            checks.append(row)
            print(('PASS ' if row['ok'] else 'FAIL ') + name_ + ('' if row['ok'] else ' -- ' + row['message']))
        passed = sum(r['ok'] for r in checks)
        result = {'passed': passed, 'total': len(checks), 'reward': 1.0 if passed == len(checks) else 0.0,
                  'isolate': runner.isolate, 'checks': checks, 'schedule_validation': runner.schedule_validation,
                  'independent_oracles': ['retained-envelope sort-and-scan', 'external actual-receipt finance ledger']}
        if args.report:
            Path(args.report).write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n')
        print(f'{passed}/{len(checks)}')
        return 0 if passed == len(checks) else 1
    finally:
        shutil.rmtree(runner.root, ignore_errors=True)


if __name__ == '__main__':
    sys.exit(main())
