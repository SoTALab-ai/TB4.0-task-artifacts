"""Private reference for CDC retained-range reconciliation."""
from dataclasses import dataclass, field
import csv
from pathlib import Path


QUIET = 8


def _integer(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(name)
    return value


def _name(value, name):
    if not isinstance(value, str) or not value:
        raise ValueError(name)
    return value


def _allocation(identifier):
    return int(identifier[1:])


@dataclass
class _Batch:
    identifier: str
    table: str
    start: int
    stop: int
    net: int
    changes: int
    created: int
    touched: int
    posted: list[dict] = field(default_factory=list)

    def content(self):
        return {'start': self.start, 'stop': self.stop, 'net': self.net, 'changes': self.changes}

    def public(self):
        return {'batch_id': self.identifier, 'table': self.table, **self.content()}

    def represented(self):
        return len(self.posted) == 1 and all(self.posted[0][k] == v for k, v in self.content().items())


class SnapshotService:
    def __init__(self, materials_dir, shards, gap, retention, stale_passes, page_size=2):
        _integer(gap, 'gap')
        _integer(retention, 'retention')
        _integer(stale_passes, 'stale_passes')
        _integer(page_size, 'page_size', 1)
        if not isinstance(shards, list) or not shards:
            raise ValueError('shards')
        for shard in shards:
            _name(shard, 'shard')
        if len(set(shards)) != len(shards):
            raise ValueError('shards')
        tables = {}
        try:
            with (Path(materials_dir) / 'tables.csv').open(newline='', encoding='utf-8') as stream:
                reader = csv.DictReader(stream)
                if not reader.fieldnames or len(reader.fieldnames) != 2 or set(reader.fieldnames) != {'source_table', 'finance_table'}:
                    raise ValueError('catalog header')
                for row in reader:
                    source = _name(row['source_table'], 'source_table')
                    table = _name(row['finance_table'], 'finance_table')
                    if source in tables:
                        raise ValueError('duplicate source_table')
                    tables[source] = table
        except (OSError, TypeError, KeyError, csv.Error) as exc:
            raise ValueError('catalog') from exc
        self.tables = tables
        self.gap, self.retention, self.stale_passes, self.page_size = gap, retention, stale_passes, page_size
        self.pass_ = 0
        self.positions = {shard: 0 for shard in shards}
        self.reports = {shard: 0 for shard in shards}
        self.highest = self.settled = 0
        self.identities = set()
        self._batches = {}
        self._batch_serial = self._receipt_serial = 0

    def _shard(self, shard):
        _name(shard, 'shard')
        if shard not in self.positions:
            raise ValueError('unknown shard')

    def _refresh(self):
        active = [position for shard, position in self.positions.items()
                  if self.pass_ - self.reports[shard] < QUIET]
        candidate = min(active) if active else self.highest
        self.settled = max(self.settled, min(candidate, self.highest))

    def register_shard(self, shard):
        _name(shard, 'shard')
        if shard not in self.positions:
            self.positions[shard] = 0
            self.reports[shard] = self.pass_
            self._refresh()

    def checkpoint(self, shard, position):
        self._shard(shard)
        _integer(position, 'position')
        self.positions[shard] = max(self.positions[shard], position)
        self.reports[shard] = self.pass_
        self.highest = max(self.highest, position)
        self._refresh()

    def tick(self, passes=1):
        _integer(passes, 'passes')
        self.pass_ += passes
        self._refresh()

    def change(self, shard, change_id, source_table, start, stop, delta):
        self._shard(shard)
        _name(change_id, 'change_id')
        _name(source_table, 'source_table')
        if source_table not in self.tables:
            raise ValueError('unknown source_table')
        _integer(start, 'start')
        _integer(stop, 'stop')
        if start >= stop:
            raise ValueError('range')
        if isinstance(delta, bool) or not isinstance(delta, int):
            raise ValueError('delta')
        self.reports[shard] = self.pass_
        self._refresh()
        identity = (shard, change_id)
        if identity in self.identities:
            return
        self.identities.add(identity)
        table = self.tables[source_table]
        left, right = start, stop
        joined = []
        remaining = [batch for batch in self._batches.values() if batch.table == table]
        while True:
            touching = [batch for batch in remaining
                        if batch.start <= right + self.gap and batch.stop + self.gap >= left]
            if not touching:
                break
            joined.extend(touching)
            chosen = {batch.identifier for batch in touching}
            remaining = [batch for batch in remaining if batch.identifier not in chosen]
            left = min(left, *(batch.start for batch in touching))
            right = max(right, *(batch.stop for batch in touching))
        if joined:
            identifier = min(joined, key=lambda batch: _allocation(batch.identifier)).identifier
            created = min(batch.created for batch in joined)
        else:
            self._batch_serial += 1
            identifier, created = f'B{self._batch_serial:08d}', self.pass_
        posted = sorted((dict(receipt) for batch in joined for receipt in batch.posted),
                        key=lambda receipt: _allocation(receipt['receipt_id']))
        batch = _Batch(identifier, table, left, right, delta + sum(b.net for b in joined),
                       1 + sum(b.changes for b in joined), created, self.pass_, posted)
        for old in joined:
            del self._batches[old.identifier]
        self._batches[identifier] = batch

    def publish(self, through=None):
        if through is not None:
            _integer(through, 'through')
        cut = self.settled if through is None else through
        pages = []
        for batch in sorted(self._batches.values(), key=lambda batch: (batch.table, batch.start, batch.identifier)):
            complete = batch.stop + self.gap <= cut
            if complete and batch.represented():
                continue
            capacity = self.page_size
            withdrawn = batch.posted[:capacity]
            batch.posted = batch.posted[len(withdrawn):]
            snapshot = None
            if not batch.posted and complete:
                self._receipt_serial += 1
                snapshot = {'receipt_id': f'R{self._receipt_serial:08d}', **batch.content()}
                batch.posted = [dict(snapshot)]
            if withdrawn or snapshot is not None:
                pages.append({'batch_id': batch.identifier, 'table': batch.table,
                              'withdrawn': [dict(receipt) for receipt in withdrawn],
                              'snapshot': dict(snapshot) if snapshot is not None else None})
        return pages

    def compact(self, through=None):
        if through is not None:
            _integer(through, 'through')
        cut = self.settled if through is None else through
        removed = []
        for batch in sorted(self._batches.values(), key=lambda batch: _allocation(batch.identifier)):
            if not batch.represented():
                continue
            ordinary = cut > batch.stop + self.gap + self.retention
            inactive = self.pass_ - batch.touched > self.stale_passes
            if ordinary or inactive:
                removed.append(batch.identifier)
        for identifier in removed:
            del self._batches[identifier]
        return removed

    def status(self):
        return {'pass': self.pass_, 'checkpoint': self.settled,
                'batches': [batch.public() for batch in sorted(self._batches.values(),
                           key=lambda batch: (batch.table, batch.start, batch.identifier))]}
