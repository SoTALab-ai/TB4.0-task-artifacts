# Finance reconciliation operations

Capture agents deliver signed transaction amounts to a service that reconciles commit-position ranges. Finance receives a receipt for completed reconciliation work and applies later corrections through receipt withdrawals and replacement snapshots. Delayed deliveries are normal, including deliveries from an agent that was paused while other agents continued.

The service must keep finance consistent with retained transaction work, make covered work ready during capture pauses, and reclaim completed retained work when its retention period ends. Operators have seen finance updates stall during maintenance, old postings remain alongside replacements, earlier postings disappear from later corrections, and retention remove work that recently received traffic. They have also seen completed shift state remain after it was due for reclamation.

## Transaction ranges and batches

Positions are non-negative integers on one scale shared by every shard. A transaction envelope covers `[start, stop)`, where `start < stop`. Its `delta` is a signed integer. The catalog assigns every source table to one finance table; several sources can share that destination.

The identity of a delivery is the pair `(shard, change_id)`. Accept an identity once during the entire service lifetime. An exact retry has no further effect, even after the original retained batch has been removed. Identical identifiers from different shards are independent transactions. Callers provide the original payload on retries.

For each finance table, retained ranges form maximal connected batches. In position order, a range joins the preceding connected work when its start is no greater than the greatest preceding stop plus `gap`. Connections are transitive and do not depend on delivery order. A batch spans the minimum start and maximum stop of its envelopes. Its net amount is their sum, and its change count is the number of unique accepted envelopes.

New disconnected work receives the next globally allocated batch identifier, beginning with `B00000001`. A delivery connecting existing batches keeps the identifier allocated earliest among them. The other connected identifiers are no longer live. Count the connecting delivery exactly once.

## Capture coverage and maintenance passes

A checkpoint at position `p` promises that the reporting shard has sent every envelope whose stop is at most `p`. Reports are cumulative; a lower position adds no coverage. A newly registered shard starts at position zero. Receiving a transaction does not report a checkpoint. Callers ensure that each previously unseen delivery has a stop greater than that shard's prior checkpoint.

`tick()` advances elapsed service maintenance passes. It does not establish database coverage. A running agent reports a checkpoint at least once within every two passes, and can report an unchanged position while waiting on a long transaction. Paused agents send no traffic. Resumption is expressed by later traffic, without a separate pause or resume operation.

The service checkpoint starts at zero, represents settled capture coverage, and never decreases. Actual checkpoint reports must support that coverage. Newly registered and returning agents may revise reconciled history without reopening coverage that has already settled. Any extension of coverage must respect every agent that continues to report.

Under sustained partial pauses, work covered by running agents' checkpoints must become ready within 30 passes. Under a sustained pause of every agent, work covered by at least one received checkpoint must become ready within 30 passes. Ready snapshots are returned on the next `publish()` call; other calls do not send finance pages asynchronously.

A retained batch is complete for a publishing call if `batch.stop + gap <= boundary`. Without an explicit operator boundary, use the service checkpoint. A changed batch can extend beyond that boundary even when the settled service checkpoint stays unchanged.

## Finance receipts and publishing

A receipt has exactly these fields:

| Field | Type and meaning |
| --- | --- |
| `receipt_id` | String identifying this posting instance |
| `start` | Integer lower range bound |
| `stop` | Integer upper range bound |
| `net` | Integer signed net amount |
| `changes` | Integer count of unique envelopes |

Finance treats `receipt_id` as the identity of a posting. Equal amounts and bounds do not make different receipt instances interchangeable. Allocate receipt identifiers globally in posting order, starting at `R00000001`. A page that only withdraws receipts consumes no receipt identifier.

`publish()` returns a list of pages in `(table, start, batch_id)` order for the current retained batches. A page has exactly these fields:

| Field | Type and meaning |
| --- | --- |
| `batch_id` | String identifying the current retained batch |
| `table` | String naming its finance table |
| `withdrawn` | List of old receipt records to withdraw |
| `snapshot` | New receipt record, or `null` |

`withdrawn` contains receipt records, and `snapshot` contains a receipt record or `null`. Return at most one page per current batch per call, and omit a page with neither withdrawals nor a snapshot. Once pending work is drained, repeated calls return `[]`.

Finance first withdraws the listed old postings and then posts a non-null snapshot. Every withdrawal must exactly copy a receipt previously returned by this service that is still posted for the affected lineage. Withdraw a receipt at most once. List withdrawals in receipt allocation order.

Finance must not keep a posting that no longer describes a current complete retained batch. After changed work becomes incomplete, the next publishing calls withdraw affected old postings without posting the incomplete replacement. For completed work, repeated publishing must leave exactly one current receipt with the batch's present bounds, amount and count. Do not reissue an unchanged current receipt. Withdraw old postings before, or together with, their replacement.

Each page withdraws no more than `page_size` old receipts. If affected old postings remain after a page, that page's snapshot is `null`. Once none remain, a complete batch posts its current snapshot. A complete batch with no previous posting posts its first snapshot. Whenever affected old postings exist, a returned page withdraws at least one; it may withdraw fewer than its capacity. Repeated calls drain the work, and new deliveries may arrive between calls.

`publish(through=p)` uses an externally audited authoritative coverage boundary for that call. It may exceed the service checkpoint. It does not alter the service checkpoint or any shard report.

## Retention and reclamation

Ordinary expiry occurs strictly beyond `batch.stop + gap + retention`, measured against the service checkpoint or the explicit boundary for that `compact()` call. A retained batch also reaches its inactivity limit after more than `stale_passes` passes without accepting a unique new envelope into it. A new accepted envelope connecting retained work is activity of the resulting batch. Checkpoint reports, queries, publication and duplicate deliveries are not reconciliation activity.

Retention must preserve accepted transaction work and the receipt transitions finance still needs. These requirements take priority over both expiry deadlines. Once finance's current receipt fully represents the retained batch, either expiry deadline requires removal on that compaction call.

`compact()` removes eligible retained batches and returns their identifiers in allocation order. It neither publishes nor withdraws receipts. Finance archives the final receipt of removed work. Later deliveries form new retained lineages and must not withdraw those archived receipts. Removing a batch does not permit an old delivery identity to contribute again.

`compact(through=p)` uses the supplied authoritative operator boundary only for that call. The service checkpoint and shard checkpoints stay unchanged.

## Python interface

Import the service with `from app import SnapshotService`.

```python
SnapshotService(materials_dir, shards, gap, retention, stale_passes, page_size=2)
register_shard(shard) -> None
change(shard, change_id, source_table, start, stop, delta) -> None
checkpoint(shard, position) -> None
tick(passes=1) -> None
publish(through=None) -> list[dict]
compact(through=None) -> list[str]
status() -> dict
```

The constructor reads `tables.csv` from `materials_dir`. `shards` is a nonempty list of distinct nonempty strings. `gap`, `retention` and `stale_passes` are non-negative integers; `page_size` is a positive integer. Shard registration is idempotent.

`status()` returns `{"pass": int, "checkpoint": int, "batches": list}`. Each batch record has exactly `batch_id`, `table`, `start`, `stop`, `net` and `changes`. List batches in `(table, start, batch_id)` order. Receipt bookkeeping is not part of this interface.

Raise `ValueError` for unknown shards or source tables, empty or non-string shard names or change identifiers, invalid ranges, invalid constructor parameters, non-integer deltas, or negative or non-integer positions, pass counts or operator boundaries. Booleans do not count as integers. A failed call leaves all service state unchanged, including allocation of future identifiers and reconciliation activity.

Calls are sequential and use only the Python standard library. Catalogs are valid: every source appears once and both names on every row are nonempty strings. Callers supply exact retries and honor shard checkpoint promises; detecting violations of those promises is outside this service's responsibility. Acceptance uses other valid catalogs, names, amounts, ranges, page sizes and call schedules.
