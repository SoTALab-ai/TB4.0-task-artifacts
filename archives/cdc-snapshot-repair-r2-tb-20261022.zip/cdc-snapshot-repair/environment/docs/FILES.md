# Files and replay

`/app/app` is the Python service package. Its public entry point is `app.SnapshotService`. `/app/docs/OPERATIONS.md` defines the required business behavior.

## Catalog

`/app/materials/tables.csv` is UTF-8 CSV with the header:

```csv
source_table,finance_table
```

Every source occurs exactly once. Source and destination names are nonempty strings. More than one source can map to the same finance table.

## Operational logs

`capture-shift.jsonl` replays a shift with changing capture traffic, delayed deliveries and maintenance. `weekend-maintenance.jsonl` replays routine capture, a period when all capture agents are paused, and resumed work. These operational replay records are inputs with no expected-output column.

Each line is a JSON object; the logs contain no blank lines. The first line contains a single `config` object with `shards`, `gap`, `retention`, `stale_passes` and `page_size`. The replay program supplies the log's containing directory as `materials_dir`.

Every subsequent line has an `op` field naming one of the seven public methods and the method's keyword arguments:

| Operation | Arguments |
| --- | --- |
| `register_shard` | `shard` |
| `change` | `shard`, `change_id`, `source_table`, `start`, `stop`, `delta` |
| `checkpoint` | `shard`, `position` |
| `tick` | optional `passes` |
| `publish` | optional `through` |
| `compact` | optional `through` |
| `status` | none |

Ranges use half-open bounds. Redeliveries reuse their original complete payload. A previously unseen delivery's stop is greater than that shard's previously reported checkpoint. A repeated identifier from another shard is independent. There is no separate event for an agent pausing or resuming.

## Replay command

From `/app`, run:

```text
python3 replay.py materials/capture-shift.jsonl
python3 replay.py materials/weekend-maintenance.jsonl
```

The program constructs the service from the header and executes the calls in file order. For each call it prints one JSON object containing `line` (the one-based input line), `op`, `returned` (the method's return value) and `status` (the resulting public service status). Calls returning `None` appear as `null`. The program executes the installed service without interpreting outputs as expected answers.
