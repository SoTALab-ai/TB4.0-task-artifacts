from .observations import CaptureObservations


class Progress:
    """Maintain the boundary shared by publication and retention.

    This legacy path uses cursor advances as participation evidence. Publication
    compares the resulting boundary with each batch's stop plus gap; Retention
    uses that same boundary for its ordinary position horizon. Keeping one
    monotone value lets both consumers read the same settled capture position.

    When advance evidence ages out for every registered cursor, this path takes
    their minimum again. The previous boundary remains the baseline whenever
    that minimum is lower, so this fallback does not move the boundary backward.
    """

    QUIET_AFTER = 10

    def __init__(self, shards):
        self.observations = CaptureObservations(shards)
        self.position = 0

    @property
    def positions(self):
        return {shard: self.observations.certified(shard)
                for shard in self.observations.records}

    def register(self, shard, current_pass):
        existed = shard in self.observations.records
        self.observations.register(shard, current_pass)
        if not existed:
            self.settle(current_pass)

    def settle(self, current_pass):
        positions = self.positions
        participating = [position for shard, position in positions.items()
                         if current_pass - self.observations.progress_pass(shard)
                         <= self.QUIET_AFTER]
        candidate = min(participating or positions.values())
        self.position = max(self.position, candidate)
