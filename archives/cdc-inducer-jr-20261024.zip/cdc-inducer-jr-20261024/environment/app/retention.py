class Retention:
    def __init__(self, gap, retention, stale_passes):
        self.gap = gap
        self.retention = retention
        self.stale_passes = stale_passes

    def ordinary_candidates(self, batches, boundary, current_pass):
        """Select the ordinary path's position-and-creation-age candidates.

        Publication reads retained batches for finance output, while this path
        reads their stop and creation pass for storage selection. In this legacy
        policy a batch beyond the position horizon also receives a quiet interval
        measured from its retained creation pass. Selection only gathers batch
        objects; _retire archives their outbound records before index removal.
        """
        for batch in batches.items.values():
            quiet = current_pass - batch.created_pass
            if (boundary > batch.stop + self.gap + self.retention
                    and quiet > self.retention):
                yield batch

    def idle_candidates(self, batches, current_pass):
        """Select the separate creation-age path for retained storage units.

        Batches.add keeps the oldest creation pass when it joins index entries.
        This path therefore treats the combined unit as having that same age.
        compact unions these candidates with the ordinary candidates by live
        batch identifier, and invokes the common _retire path once per identifier.
        Neither candidate generator sends finance pages.
        """
        for batch in batches.items.values():
            if current_pass - batch.created_pass > self.stale_passes:
                yield batch

    def _retire(self, batch, batches, ledger):
        ledger.archive(batch)
        del batches.items[batch.batch_id]

    def compact(self, batches, boundary, current_pass, ledger):
        ordinary = self.ordinary_candidates(batches, boundary, current_pass)
        candidates = {batch.batch_id: batch for batch in ordinary}
        candidates.update((batch.batch_id, batch)
                          for batch in self.idle_candidates(batches, current_pass))
        removed = sorted(candidates, key=lambda batch_id: int(batch_id[1:]))
        for batch_id in removed:
            self._retire(candidates[batch_id], batches, ledger)
        return removed
