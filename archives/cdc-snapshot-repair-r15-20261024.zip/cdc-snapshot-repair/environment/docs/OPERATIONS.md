# Finance reconciliation contract

## Service and inputs

`from app import SnapshotService` exposes this interface:

```text
SnapshotService(materials_dir, shards, gap, retention, stale_passes, page_size=2)
register_shard(shard) -> None
change(shard, change_id, source_table, start, stop, delta) -> None
checkpoint(shard, position) -> None
tick(passes=1) -> None
publish() -> list[page]
compact() -> list[str]
status() -> {pass: int, checkpoint: int, batches: list[batch]}
```

`materials_dir` contains `tables.csv`, whose columns are `source_table` and
`finance_table`. A source name occurs once and maps to one finance destination.
Source and destination names are nonempty strings. Several sources may share a
destination. Callers supply valid catalogs and may use valid names other than
those in the supplied material.

`shards` is a nonempty list of distinct nonempty strings. `register_shard` enrolls
another nonempty shard name and is idempotent for a registered name. Registration
is administrative enrollment. `gap`, `retention`, and `stale_passes` are
nonnegative integers; `page_size` is a positive integer.

A transaction envelope consists of `shard`, `change_id`, `source_table`, `start`,
`stop`, and `delta`. Its commit range is half-open, `[start, stop)`, with integer
positions satisfying `0 <= start < stop`. `delta` is a signed integer. Every
commit position uses the same scale. `change_id` is a nonempty string.

Delivery identity is `(shard, change_id)`. An exact retry carries its original
payload and adds no transaction work, amount, or count. This remains true after
its operational records have been removed. The same `change_id` on another shard
is a distinct delivery.

Unknown shards or sources, invalid or empty names, invalid ranges, invalid
constructor parameters, noninteger amounts, and negative or noninteger positions
or pass counts raise `ValueError`. Booleans are not integers. A failed call leaves
all service state unchanged, including future identifiers and activity. Callers
guarantee valid catalogs and exact retries; detecting violations of these
guarantees is outside the task. Calls are sequential.

## Retained reconciliation histories

For each finance destination, retained envelopes form maximal connected batches.
In order of range start, a next envelope belongs to the same batch when its start
is no greater than the greatest preceding stop plus `gap`. This connectivity is
transitive. Different source tables mapped to the same destination participate in
the same grouping.

A batch describes all its unique envelopes with:

| Field | Meaning |
| --- | --- |
| `batch_id` | Its live operational identifier |
| `table` | Finance destination |
| `start` | Minimum envelope start |
| `stop` | Maximum envelope stop |
| `net` | Sum of envelope deltas |
| `changes` | Number of unique envelopes |

A disconnected insertion receives the next globally allocated batch identifier,
in `B00000001` style. An insertion that touches existing batches retains the oldest
allocated touched identifier. Other joined identifiers cease to be live. The new
envelope contributes exactly once.

A retained history includes the current batch and its earlier retained batches
that were revised or joined to form it. Those earlier stages are its retained
lineage. A retired history has left the operational index; its archived finance
posting belongs to that completed history.

## Capture progress and readiness

Each shard supplies observations of normalized commit progress. A successful
`change` delivery observes that shard through its envelope's `stop` position;
`capture` has this effect after catalog resolution. An exact retry is also source
traffic, but adds no transaction work. `checkpoint(shard, position)` supplies a
progress observation without a transaction. A shard's observed position is
cumulative: a lower observation does not reduce it. A newly enrolled shard starts
at position zero.

An observation is a capture progress marker, not a promise that all earlier
transactions have arrived. Delayed envelopes at or below an earlier observed
position remain valid and may revise retained histories. A later envelope for an
already removed history starts fresh operational history as specified below.

The service checkpoint is the settled common observed capture position. It starts
at zero, never retreats, and is supported by received source observations.
Maintenance time alone supplies no capture progress. A late or newly enrolled
agent can deliver revisions to settled history. Reports from agents that continue
working still constrain further settlement.

A working agent sends a transaction delivery or an explicit checkpoint within
every two maintenance passes. An unchanged position is a normal report during a
long transaction. A paused agent sends no traffic; later traffic expresses
resumption. There is no pause or resume API.

`tick(passes)` advances only the maintenance clock by the given count. The clock
starts at zero and is exposed as `pass` in `status()`.

A retained batch is ready when `batch.stop + gap <= service checkpoint`. A source
observation covers a batch when its cumulative observed position reaches the
batch's stop plus `gap`. During ordinary capture, work covered by every enrolled
agent's current observation is available on the next `publish()` call. During a
sustained partial pause, reconciliation covered in common by the working agents'
observations must become ready within 30 maintenance passes. During sustained
silence of all agents, reconciliation covered by at least one source observation
already received must also become ready within 30 maintenance passes. These
readiness guarantees apply while their conditions and coverage persist. Sending
finance output still requires a `publish()` call.

## Finance receipts and corrections

Finance records full amount summaries rather than operational commit ranges.
A posting value has exactly these fields:

```text
{net: int, changes: int}
```

They are the corresponding batch's signed total and number of unique envelopes.
Operational ranges remain available in `status()`. Finance does not assign or
receive a posting identifier. Each snapshot actually returned is a separate
financial posting, even when its value equals another posting. Numerical equality
does not combine two postings or discharge another history's delivery obligation.

`publish()` returns pages ordered by current `(table, start, batch_id)`, with at
most one page per current batch per call. A page has exactly this shape:

```text
{batch_id, table, withdrawn: [value, ...], snapshot: value | null}
```

`batch_id` identifies the current operational batch being reconciled. `snapshot`
is a newly returned full posting, when present. Finance applies withdrawals before
the snapshot. Every withdrawn value copies one actual, still-posted instance
from this batch's retained lineage. It cannot consume an instance from another
retained history or an archived history. Each instance is withdrawn at most once.
Equal former values are repeated as many times as their actual instances require.
Withdrawal order within a page is unrestricted. Internal state representations
are implementation choices.

Subject to the correction process below, finance's live postings must describe current ready reconciliation. Delayed
transactions may revise a previously posted batch or combine several posted
histories. Such changes require obsolete financial instances to be withdrawn. A
stale posting must be withdrawn even while its revised batch is not yet ready.
After a ready correction is drained, its current history has one up-to-date
receipt and no obsolete instances. An unchanged valid current receipt is not
reissued.

Corrections may span calls. When old posted instances need correction, the page
withdraws at least one and at most `page_size` of them. Underfilled pages are
legal. Any subset of old instances may be selected across calls, without prescribing a selection or value order. A replacement receipt is returned
only after all affected old instances have been withdrawn and the batch is
ready. It may accompany the last withdrawals or follow them on the next call.
With no new input, repeated `publish()` calls drain a ready correction in at most
the number of affected old instances plus one calls. New input may arrive between
pages.

A ready batch with no earlier receipt history receives its first receipt on that
`publish()` call. Empty pages are omitted. After all available publication work
is drained, repeated calls return `[]`.

## Publication during storage maintenance

Every accepted unique transaction must have a correct financial history. Once its
batch is ready, subsequent publishing must be able to deliver that history.
Storage maintenance cannot change the financial obligations created by accepted
transactions. This applies throughout ordinary operation, including any
interleaving of publishing and storage maintenance.

`compact()` actually removes retired batches from the operational index and
returns their batch identifiers in allocation order. It sends no finance pages.

## Maintenance budgets

Ordinary retention is measured in settled observed commit positions. It expires strictly
beyond `batch.stop + gap + retention`: the service checkpoint must be greater than
that value. It is independent of the maintenance clock.

`stale_passes` is a separate inactivity budget measured in maintenance passes.
Recently received reconciliation work is entitled to this budget. Finished work
that has received no new unique transaction work for longer than `stale_passes`
is idle. Queries, checkpoint reports, finance reads, and exact retries are not new
transaction work.

On a `compact()` call after finance has received the current up-to-date posting,
ordinary retention expiry requires removal on that call if none of the history's
financial work is missing and no obsolete posting remains. Under the same output
conditions, exceeding the inactivity budget independently requires removal on
that call. Neither applicable budget has an additional waiting period. The durable
financial guarantees above continue to apply to these maintenance calls.

## Finance after operational removal

When finance has received the final up-to-date posting, none of the history's
financial work is missing, and no obsolete posting remains, finance archives that
final posting when the history leaves the operational index. An archived receipt
is immutable. A later transaction can start a new retained history without
withdrawing receipts archived for an earlier history.

## Status

`status()` returns exactly:

```text
{pass: int, checkpoint: int, batches: [batch, ...]}
```

Each batch record has exactly `batch_id`, `table`, `start`, `stop`, `net`, and
`changes`, as defined above. Records are ordered by `(table, start, batch_id)` and
expose no receipt history fields. `status()` is a query.


## Producer capture envelopes

`capture(row) -> None` accepts a raw producer envelope. `row` carries `shard`,
`change_id`, `epoch`, `client`, `actor`, `local_start`, `local_stop`, and `delta`.
The five names are nonempty strings; the three numeric fields are integers,
excluding booleans. Local positions may be signed. The normalized commit range
must satisfy the same range requirements as `change`.

`capture-clocks.csv` has `shard,epoch,offset`. Each producer epoch identifies one
clock basis. The pair selects its offset; normalized start and stop equal the
corresponding local position plus that offset. A producer may resume under a
different epoch. All normalized positions share the commit scale used by
checkpoints. The maintenance pass is independent of producer and commit positions.

`capture-routing.csv` has `client,actor,from_position,to_position,source_table`.
A client-local actor selects its source table at the normalized range start.
The interval includes `from_position` and excludes `to_position`; an empty end is
unbounded. Actor names in different clients have separate namespaces. Several
actors may route to source tables sharing a finance destination. File order is
not revision order. The two catalogs are authoritative. Installed catalogs have
valid column types and intervals. An accepted row must resolve exactly one clock
basis and one route. Unknown or ambiguous matches raise `ValueError` before any
service state changes.

After resolution, capture has the same effects as the corresponding `change`
call, including delivery identity, retries, source progress and validation. Its
progress observation uses the normalized stop, on the same commit scale as the
resolved range. Callers may interleave both input forms; an exact retry preserves
its original payload. Acceptance uses other valid catalogs and raw histories as
well as the supplied examples.
