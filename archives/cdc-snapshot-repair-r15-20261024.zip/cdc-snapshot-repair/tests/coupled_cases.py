"""独立观测同一规范化输入、来源进度、真实交付和两种回收预算。"""
import copy

import base_check as b


CLOCKS = 'shard,epoch,offset\na,new,-40\na,old,80\nb,boot,0\n'
ROUTES = ('client,actor,from_position,to_position,source_table\n'
          'web,T,100,,ledger.entries\nweb,T,0,100,pos.sales\n'
          'mobile,T,0,,pos.refunds\nweb,F,0,,audit.fees\n'
          'web,L,280,,ledger.entries\nweb,L,0,280,pos.sales\n')
MATERIALS = {'capture-clocks.csv': CLOCKS, 'capture-routing.csv': ROUTES}
CONFIG = dict(shards=['a', 'b'], gap=3, retention=200, stale_passes=75, page_size=1)


def envelope(shard, cid, epoch, client, actor, start, stop, delta):
    return dict(op='capture', row=dict(shard=shard, change_id=cid, epoch=epoch,
                client=client, actor=actor, local_start=start, local_stop=stop,
                delta=delta))


# 公开编码由先行冻结的语义样本逆向生成；此表不含预期返回。
RAW = {
    'x4108': envelope('a', 'x4108', 'new', 'web', 'L', 290, 294, 2631),
    'x7293': envelope('b', 'x7293', 'boot', 'mobile', 'T', 270, 274, 2631),
    'x5826': envelope('a', 'x5826', 'old', 'mobile', 'T', 370, 374, -846),
    'x0647': envelope('a', 'x0647', 'old', 'mobile', 'T', 390, 394, 2107),
    'x9152': envelope('a', 'x9152', 'old', 'web', 'T', 414, 417, 731),
    'x2389': envelope('a', 'x2389', 'old', 'mobile', 'T', 427, 430, 0),
    'x3571': envelope('b', 'x3571', 'boot', 'mobile', 'T', 255, 268, -117),
    'x6104': envelope('b', 'x6104', 'boot', 'mobile', 'T', 100, 104, 137),
    'x8460': envelope('b', 'x8460', 'boot', 'mobile', 'T', 256, 269, 89),
    'x1935': envelope('b', 'x1935', 'boot', 'mobile', 'T', 455, 468, 378),
}


def lifecycle():
    ops = [b.ch('a', 'x4108', 250, 254, 2631),
           b.ch('b', 'x7293', 270, 274, 2631, 'pos.refunds'),
           b.ch('a', 'x5826', 450, 454, -846, 'pos.refunds'),
           b.ch('a', 'x9152', 494, 497, 731, 'ledger.entries'),
           b.ch('a', 'x2389', 507, 510, 0, 'pos.refunds')]
    retry = copy.deepcopy(ops[-1])
    # 每两pass真实重送同一条未完成事务，维持来源活动而不续unique工作年龄。
    for _ in range(15):
        ops += [b.tick(2), copy.deepcopy(retry)]
    ops += [b.pub()]
    marks = {'readiness': len(ops)}
    ops += [b.ch('b', 'x3571', 255, 268, -117, 'pos.refunds'),
            b.ch('b', 'x6104', 100, 104, 137, 'pos.refunds')]
    marks['pending'] = len(ops)
    ops += [b.gc(), b.pub()]
    marks['fresh_posted'] = len(ops)
    ops += [b.gc()]
    marks['partial_compact'] = len(ops)
    ops += [
            b.ch('b', 'x8460', 256, 269, 89, 'pos.refunds'),
            b.pub(), b.pub()]
    marks['low_complete'] = len(ops)
    ops += [b.gc()]
    marks['low_retired'] = len(ops)
    for _ in range(13):
        ops += [b.tick(2), copy.deepcopy(retry)]
    ops += [b.ch('a', 'x0647', 470, 474, 2107, 'pos.refunds'), b.pub()]
    marks['new_high_posted'] = len(ops)
    for _ in range(15):
        ops += [b.tick(2), copy.deepcopy(retry)]
    ops += [b.ch('b', 'x1935', 455, 468, 378, 'pos.refunds'),
            b.pub(), b.pub(), b.pub()]
    marks['high_complete'] = len(ops)
    ops += [b.gc()]
    marks['high_recent'] = len(ops)
    for _ in range(25):
        ops += [b.tick(2), copy.deepcopy(retry), b.cp('b', 0)]
    ops += [b.gc()]
    marks['high_middle'] = len(ops)
    for _ in range(13):
        ops += [b.tick(2), copy.deepcopy(retry), b.cp('b', 0)]
    ops += [b.gc()]
    marks['high_retired'] = len(ops)
    return ops, marks


def encode(ops):
    return [copy.deepcopy(RAW[op['change_id']]) if op['op'] == 'change'
            else copy.deepcopy(op) for op in ops]


def marker_and_cut(rows):
    marker = [page['snapshot'] for page in b.pages(rows)
              if page['table'] == 'fin_ledger' and page['snapshot'] is not None]
    assert marker == [{'net': 731, 'changes': 1}], 'actual marker posting did not prove pause-derived readiness'
    assert 500 <= rows[-1]['status']['checkpoint'] <= 510, 'marker did not establish supported cut for maintenance'


def retained(rows, start):
    return [row for row in rows[-1]['status']['batches']
            if row['table'] == 'fin_sales' and row['start'] == start]


def established_pending(rows):
    marker_and_cut(rows)
    current = retained(rows, 250)
    assert len(current) == 1 and {k: current[0][k] for k in ('stop', 'net', 'changes')} == {
        'stop': 274, 'net': 5145, 'changes': 3}, 'joint setup did not merge the correct low work'
    assert b.sales_snapshots(rows).count({'net': 2631, 'changes': 1}) == 2, 'joint setup lacks two actual equal postings'
    assert not [v for p in b.sales_pages(rows) for v in p['withdrawn']], 'pending setup already withdrew old postings'
    fresh = retained(rows, 100)
    assert len(fresh) == 1 and {k: fresh[0][k] for k in ('stop', 'net', 'changes')} == {
        'stop': 104, 'net': 137, 'changes': 1}, 'joint setup lacks distinct first-publication work'
    assert {'net': 137, 'changes': 1} not in b.sales_snapshots(rows), 'first-publication setup already delivered fresh work'


def established_low_complete(rows, fresh_retired=True):
    marker_and_cut(rows)
    current = retained(rows, 250)
    assert len(current) == 1 and {k: current[0][k] for k in ('stop', 'net', 'changes')} == {
        'stop': 274, 'net': 5234, 'changes': 4}, 'joint low correction has wrong current work'
    assert [v for p in b.sales_pages(rows) for v in p['withdrawn']] == [
        {'net': 2631, 'changes': 1}, {'net': 2631, 'changes': 1}], 'actual equal ancestors were not both withdrawn'
    assert {'net': 5234, 'changes': 4} in b.sales_snapshots(rows), 'up-to-date low posting has not really been delivered'
    assert rows[-1]['status']['pass'] == 30, 'joint low work should still be recent'
    assert b.sales_snapshots(rows).count({'net': 137, 'changes': 1}) == 1, 'fresh work was not actually first-published'
    if fresh_retired:
        assert not retained(rows, 100), 'finished expired fresh history remained after its maintenance call'
    else:
        assert retained(rows, 100), 'G3 interleaving has not yet requested retirement of the finished fresh history'


def established_high_complete(rows):
    marker_and_cut(rows)
    assert not retained(rows, 250), 'completed low history did not actually retire in setup'
    current = retained(rows, 450)
    assert len(current) == 1 and {k: current[0][k] for k in ('stop', 'net', 'changes')} == {
        'stop': 474, 'net': 1639, 'changes': 3}, 'joint high correction has wrong current work'
    old = [v for p in b.sales_pages(rows) for v in p['withdrawn']
           if v != {'net': 2631, 'changes': 1}]
    assert sorted((v['net'], v['changes']) for v in old) == [(-846, 1), (2107, 1)], 'high setup did not withdraw both actual old postings'
    assert {'net': 1639, 'changes': 3} in b.sales_snapshots(rows), 'high setup did not deliver current posting'
    assert rows[-1]['status']['pass'] == 86, 'joint high revision should be new work at pass86'


def twins(run, end_mark, setup_mark=None, observer=None, omit_partial_compact=False):
    ops, marks = lifecycle()
    if omit_partial_compact:
        # 合法变体只推迟一次维护调用，隔离排空后新增quiet条件这一回归。
        index = marks['partial_compact'] - 1
        assert ops[index] == b.gc()
        ops = ops[:index] + ops[index+1:]
        marks = {key: value - int(value > index) for key, value in marks.items()}
    prefix = ops[:marks[end_mark]]
    result = []
    for transport in ('capture', 'change'):
        request_ops = encode(prefix) if transport == 'capture' else copy.deepcopy(prefix)
        result.append(run(request_ops, **CONFIG, raw_materials=MATERIALS,
                          setup_until=marks[setup_mark] if setup_mark else 0,
                          setup_observer=observer))
    return result


@b.check('M3-capture-normalized-observation-supports-pause-derived-readiness', 'M3.too_late')
def _(run):
    for rows in twins(run, 'readiness'):
        marker_and_cut(rows)


@b.check('M4-coupled-pause-derived-expiry-preserves-pending-correction', 'M4.too_early.ordinary')
def _(run):
    for rows in twins(run, 'low_retired', 'pending', established_pending):
        assert not retained(rows, 250), 'finished low history did not retire after pending protection'


@b.check('M4-coupled-drained-correction-retires-without-extra-quiet', 'M4.too_late.ordinary')
def _(run):
    for rows in twins(run, 'low_retired', 'low_complete',
                      lambda prefix: established_low_complete(prefix, fresh_retired=False),
                      omit_partial_compact=True):
        assert not retained(rows, 250), 'ordinary expiry was given an extra inactivity wait'
        assert not retained(rows, 100), 'finished fresh posting was given an extra inactivity wait'


@b.check('M4-coupled-raw-revision-refreshes-age-after-real-drain', 'M4.too_early.idle')
def _(run):
    ops, marks = lifecycle()
    for rows in twins(run, 'high_retired', 'high_complete', established_high_complete):
        assert retained(rows[:marks['high_recent']], 450), 'fully posted high history lost its recent-work budget'
        assert retained(rows[:marks['high_middle']], 450), 'bridge work age was replaced by a donor creation age'
        assert not retained(rows, 450), 'fully posted high history never retired after its inactivity budget'
