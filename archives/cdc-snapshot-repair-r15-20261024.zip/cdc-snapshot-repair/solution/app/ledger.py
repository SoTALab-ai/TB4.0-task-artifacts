from copy import deepcopy


class OutboundJournal:
    def __init__(self):
        self.journal = []
        self.latest = {}
        self.closures = []
        self.opened = {}
        self._work = {}
        self._posted = {}
        self._next_instance = 1

    def register(self, owner_id, current_pass):
        self.opened.setdefault(owner_id, current_pass)

    def accept(self, batch, previous_ids, current_pass):
        previous = set(previous_ids)
        birth = min((self.opened[batch_id] for batch_id in previous),
                    default=self.opened[batch.batch_id])
        for instance in self._posted.values():
            if instance["owner_id"] in previous:
                instance["owner_id"] = batch.batch_id
        for batch_id in previous:
            self.opened.pop(batch_id)
            self._work.pop(batch_id)
            if batch_id != batch.batch_id:
                self.latest.pop(batch_id, None)
        self.opened[batch.batch_id] = birth
        self._work[batch.batch_id] = current_pass

    def last_work(self, batch):
        return self._work[batch.batch_id]

    def posted(self, batch):
        return [deepcopy(instance) for instance in self._posted.values()
                if instance["owner_id"] == batch.batch_id]

    def complete(self, batch):
        posted = self.posted(batch)
        return len(posted) == 1 and posted[0]["value"] == batch.contents()

    def deliver(self, batch, withdrawn_ids, snapshot):
        selected = set(withdrawn_ids)
        assert len(selected) == len(withdrawn_ids)
        owned = self.posted(batch)
        withdrawn = [deepcopy(instance["value"]) for instance in owned
                     if instance["instance_id"] in selected]
        assert len(withdrawn) == len(selected)
        for instance_id in selected:
            del self._posted[instance_id]
        if snapshot is not None:
            instance_id = self._next_instance
            self._next_instance += 1
            self._posted[instance_id] = {"instance_id": instance_id,
                "value": deepcopy(snapshot), "owner_id": batch.batch_id}
            self.latest[batch.batch_id] = deepcopy(snapshot)
        page = {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": withdrawn, "snapshot": deepcopy(snapshot)}
        self.journal.append(deepcopy(page))
        return page

    def archive(self, batch):
        posted = self.posted(batch)
        self.closures.append({"batch": batch.record(), "posted": deepcopy(posted)})
        for instance in posted:
            del self._posted[instance["instance_id"]]
        self.latest.pop(batch.batch_id, None)
        self.opened.pop(batch.batch_id)
        self._work.pop(batch.batch_id)
