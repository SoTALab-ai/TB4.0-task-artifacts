from dataclasses import dataclass


@dataclass
class Batch:
    batch_id: str
    table: str
    start: int
    stop: int
    net: int
    changes: int

    def record(self):
        return {key: getattr(self, key) for key in
                ("batch_id", "table", "start", "stop", "net", "changes")}

    def contents(self):
        return {"net": self.net, "changes": self.changes}


class Batches:
    def __init__(self, gap):
        self.gap = gap
        self._batches = {}
        self.accepted = set()
        self.next_id = 1

    def ordered(self):
        return sorted(self._batches.values(),
                      key=lambda batch: (batch.table, batch.start, batch.batch_id))

    def select(self, batch_id):
        return self._batches[batch_id]

    def add(self, identity, table, start, stop, delta):
        joined = []
        remaining = [batch for batch in self.ordered() if batch.table == table]
        left, right = start, stop
        while True:
            touching = [batch for batch in remaining
                        if batch.start <= right + self.gap and left <= batch.stop + self.gap]
            if not touching:
                break
            joined.extend(touching)
            left = min(left, *(batch.start for batch in touching))
            right = max(right, *(batch.stop for batch in touching))
            ids = {batch.batch_id for batch in touching}
            remaining = [batch for batch in remaining if batch.batch_id not in ids]
        previous_ids = tuple(sorted((batch.batch_id for batch in joined),
                                    key=lambda batch_id: int(batch_id[1:])))
        net = delta + sum(batch.net for batch in joined)
        changes = 1 + sum(batch.changes for batch in joined)
        if joined:
            owner = self._batches[previous_ids[0]]
            for batch_id in previous_ids[1:]:
                del self._batches[batch_id]
            owner.start, owner.stop = left, right
            owner.net, owner.changes = net, changes
        else:
            batch_id = f"B{self.next_id:08d}"
            self.next_id += 1
            owner = Batch(batch_id, table, left, right, net, changes)
            self._batches[batch_id] = owner
        self.accepted.add(identity)
        return owner, previous_ids

    def remove(self, batch):
        del self._batches[batch.batch_id]
