"""Acceptance checks for the CDC snapshot service. Reward is 1 only if every check passes.

Every call schedule runs in a separate process (worker.py) against a private copy of the candidate
package. Two invariants are checked on every schedule:
  * a published window never ends beyond the highest checkpoint position received so far;
  * snapshot ids are unique and each snapshot supersedes the previous snapshot of the same window
    (or nothing, for the first snapshot after the window state was created or removed).
"""
import argparse
import csv
import io
import json
import os
import signal
import shutil
import subprocess
import sys
import tempfile
import traceback
from pathlib import Path

HERE = Path(__file__).resolve().parent
CATALOG = "source_table,finance_table,width\npos.sales,fin_sales,10\npos.refunds,fin_sales,10\nledger.entries,fin_ledger,20\n"
SNAPSHOT_KEYS = {"snapshot_id", "table", "window_start", "window_end", "net", "changes", "supersedes"}
CHECKS = []


def check(name):
    def register(fn):
        CHECKS.append((name, fn))
        return fn
    return register


def ch(shard, cid, table, ts, delta):
    return {"op": "change", "shard": shard, "change_id": cid, "source_table": table, "commit_ts": ts, "delta": delta}


def cp(shard, position):
    return {"op": "checkpoint", "shard": shard, "position": position}


def tick(passes=1):
    return {"op": "tick", "passes": passes}


PUB = {"op": "publish"}


def compact(as_of=None):
    return {"op": "compact"} if as_of is None else {"op": "compact", "as_of": as_of}


def validate_schedule(ops, shards, catalog):
    """Check fixture consistency independently of candidate behavior.

    Invalid-call probes remain allowed, but a valid new change cannot contradict its shard's own
    previous promise. Old change IDs can be resent after a checkpoint.
    """
    positions = {s: 0 for s in shards}
    tables = {row["source_table"] for row in csv.DictReader(io.StringIO(catalog))}
    seen = set()
    new_changes = 0
    for index, op in enumerate(ops):
        if op["op"] == "register_shard" and isinstance(op["shard"], str) and op["shard"]:
            positions.setdefault(op["shard"], 0)
        elif op["op"] == "checkpoint" and op["shard"] in positions:
            position = op["position"]
            if type(position) is int and position >= 0:
                positions[op["shard"]] = max(positions[op["shard"]], position)
        elif op["op"] == "change" and op["shard"] in positions and op["source_table"] in tables:
            ts, cid = op["commit_ts"], op["change_id"]
            if type(ts) is not int or ts < 0 or type(op["delta"]) is not int or not isinstance(cid, str) or not cid:
                continue
            key = (op["shard"], cid)
            if key not in seen:
                assert ts >= positions[op["shard"]], (
                    f"invalid verifier fixture at call {index}: new change from {op['shard']} at {ts} "
                    f"contradicts its checkpoint {positions[op['shard']]}")
                new_changes += 1
                seen.add(key)
    return {"calls": len(ops), "new_changes": new_changes, "checkpoint_promises_valid": True}


class Runner:
    def __init__(self, candidate, isolate):
        if isolate and (not hasattr(os, "geteuid") or os.geteuid() != 0):
            raise RuntimeError("--isolate requires root; refusing to run an unisolated substitute")
        self.isolate = isolate
        self.schedule_validation = []
        source_path = Path(candidate) / "app"
        if source_path.is_symlink():
            raise ValueError("candidate app root must be a directory, not a symlink")
        source = source_path.resolve()
        for path in source.rglob("*"):
            if path.is_symlink() and not path.resolve().is_relative_to(source):
                raise ValueError("candidate package symlinks must stay inside app")
        self.root = Path(tempfile.mkdtemp(prefix="cdc-check-"))
        self.root.chmod(0o755)
        shutil.copytree(source, self.root / "candidate" / "app",
                        ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        shutil.copy(HERE / "worker.py", self.root / "worker.py")
        for path in self.root.rglob("*"):
            path.chmod(0o755 if path.is_dir() else 0o644)

    def _preexec(self):
        if self.isolate:
            os.setgroups([])
            os.setgid(65534)
            os.setuid(65534)

    def process(self, argv, cwd, stdin=None, timeout=30):
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1", "HOME": str(cwd)}
        proc = subprocess.Popen(argv, cwd=cwd, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE, text=True, env=env, preexec_fn=self._preexec,
                                start_new_session=True)
        try:
            stdout, stderr = proc.communicate(stdin, timeout=timeout)
            return subprocess.CompletedProcess(argv, proc.returncode, stdout, stderr)
        finally:
            # A timed-out or completed candidate must not leave background children behind.
            try:
                os.killpg(proc.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            if proc.poll() is None:
                proc.communicate()

    def run(self, ops, shards=("a", "b"), retention=30, stale_passes=50, catalog=CATALOG, allow_errors=False):
        self.schedule_validation.append(validate_schedule(ops, shards, catalog))
        materials = Path(tempfile.mkdtemp(prefix="materials-", dir=self.root))
        materials.chmod(0o755)
        (materials / "tables.csv").write_text(catalog)
        (materials / "tables.csv").chmod(0o644)
        request = {"config": {"shards": list(shards), "retention": retention, "stale_passes": stale_passes},
                   "operations": ops}
        proc = self.process([sys.executable, "-I", "-B", str(self.root / "worker.py"), str(self.root / "candidate"),
                             str(materials)], cwd=self.root, stdin=json.dumps(request))
        assert proc.returncode == 0, "candidate process failed: " + proc.stderr[-400:]
        obs = json.loads(proc.stdout)["observations"]
        assert len(obs) == len(ops), "missing observations"
        if not allow_errors:
            for op, row in zip(ops, obs):
                assert row["error"] is None, f"{op['op']} raised {row['error']}"
        invariants(ops, obs)
        return obs


def invariants(ops, obs):
    highest, seen_ids, last = 0, set(), {}
    for op, row in zip(ops, obs):
        if op["op"] == "checkpoint" and row["error"] is None and isinstance(op["position"], int):
            highest = max(highest, op["position"])
        if op["op"] == "publish" and row["error"] is None:
            assert isinstance(row["return"], list), "publish must return a list"
            for snap in row["return"]:
                assert isinstance(snap, dict) and set(snap) == SNAPSHOT_KEYS, f"snapshot fields: {snap!r}"
                assert snap["window_end"] <= highest, f"published {snap['table']} {snap['window_start']} beyond every checkpoint received"
                assert snap["snapshot_id"] not in seen_ids, "snapshot id reused"
                seen_ids.add(snap["snapshot_id"])
                key = (snap["table"], snap["window_start"])
                assert snap["supersedes"] == last.get(key), f"supersedes for {key} should be {last.get(key)!r}"
                last[key] = snap["snapshot_id"]
        if op["op"] == "compact" and row["error"] is None:
            assert isinstance(row["return"], list), "compact must return a list"
            for removed in row["return"]:
                last.pop((removed["table"], removed["window_start"]), None)


def published(obs):
    return [s for row in obs if row["op"] == "publish" and row["return"] for s in row["return"]]


def summary(snap):
    return (snap["table"], snap["window_start"], snap["window_end"], snap["net"], snap["changes"])


def removed(row):
    return [(r["table"], r["window_start"]) for r in row["return"]]


# ---------------------------------------------------------------- basic contract

@check("basic-window-mapping-and-publication")
def _(run):
    ops = [ch("a", "c1", "pos.sales", 3, 5), ch("a", "c2", "pos.refunds", 7, -2), ch("a", "c3", "ledger.entries", 25, 4),
           cp("a", 9), PUB, cp("a", 10), PUB, cp("a", 40), PUB, PUB, {"op": "register_shard", "shard": "a"}, PUB]
    o = run(ops, shards=("a",))
    assert o[4]["return"] == [], "window published before the checkpoint reached its end"
    assert [summary(s) for s in o[6]["return"]] == [("fin_sales", 0, 10, 3, 2)]
    assert o[6]["return"][0]["snapshot_id"] == "S1" and o[6]["return"][0]["supersedes"] is None
    assert [summary(s) for s in o[8]["return"]] == [("fin_ledger", 20, 40, 4, 1)]
    assert o[8]["return"][0]["snapshot_id"] == "S2"
    assert o[9]["return"] == [] and o[11]["return"] == [], "unchanged windows published again"
    windows = {(w["table"], w["window_start"]): w for w in o[-1]["status"]["windows"]}
    assert windows[("fin_sales", 0)]["published"] == "S1" and windows[("fin_ledger", 20)]["published"] == "S2"
    # Check the stated catalog contract on names, widths and large signed deltas absent from the public logs.
    for width, large in [(7, -(1 << 90)), (13, (1 << 90) + 3)]:
        catalog = f"source_table,finance_table,width\nstream.left,z_fin,{width}\nstream.right,z_fin,{width}\nother,a_fin,{2 * width}\n"
        other_ops = [ch("west", "p", "stream.left", width, large), ch("east", "p", "stream.right", width + 1, -3),
                     ch("west", "q", "other", 1, 9), cp("west", 2 * width), cp("east", 2 * width), PUB]
        rows = run(other_ops, shards=("west", "east"), catalog=catalog)
        assert [summary(s) for s in rows[-1]["return"]] == [
            ("a_fin", 0, 2 * width, 9, 1), ("z_fin", width, 2 * width, large - 3, 2)]


@check("dedupe-is-per-shard")
def _(run):
    ops = [ch("a", "c-7", "pos.sales", 1, 5), ch("a", "c-7", "pos.sales", 1, 5), ch("b", "c-7", "pos.sales", 2, 3),
           cp("a", 10), cp("b", 10), PUB, ch("a", "c-7", "pos.sales", 1, 5), PUB]
    o = run(ops)
    assert [summary(s) for s in o[5]["return"]] == [("fin_sales", 0, 10, 8, 2)], "resends must count once, other shards' ids are distinct"
    assert o[7]["return"] == [], "a resent change produced a correction"


@check("correction-supersedes-previous-snapshot")
def _(run):
    ops = [ch("a", "x1", "pos.sales", 2, 4), ch("a", "y1", "pos.sales", 14, 1), cp("a", 20), tick(30), PUB,
           ch("b", "x2", "pos.sales", 5, 1), cp("b", 20), PUB, PUB]
    o = run(ops)
    first = {s["window_start"]: s for s in o[4]["return"]}
    assert set(first) == {0, 10}
    page = o[7]["return"]
    assert [summary(s) for s in page] == [("fin_sales", 0, 10, 5, 2)], "only the changed window is corrected"
    assert page[0]["supersedes"] == first[0]["snapshot_id"]
    assert o[8]["return"] == []


@check("invalid-calls-raise-and-change-nothing")
def _(run):
    invalid = [ch("zz", "k2", "pos.sales", 3, 1), ch("a", "k3", "pos.unknown", 3, 1), ch("a", "k4", "pos.sales", -1, 1),
               ch("a", "k5", "pos.sales", 3, True), ch("a", "", "pos.sales", 3, 1), ch("a", "k6", "pos.sales", "7", 1),
               ch("a", "k7", "pos.sales", True, 1), ch("a", "k8", "pos.sales", 3, 1.5),
               cp("a", -1), cp("zz", 5), cp("a", True), cp("a", 3.5),
               tick(-1), tick(True), tick(1.5), compact(-1), compact(True), compact(2.5)]
    ops = [ch("a", "k1", "pos.sales", 3, 1), cp("a", 2)] + invalid + [ch("a", "k3", "pos.sales", 4, 2), cp("a", 10), PUB]
    o = run(ops, shards=("a",), allow_errors=True)
    before = o[1]["status"]
    for op, row in zip(invalid, o[2:2 + len(invalid)]):
        assert row["error"] and row["error"]["type"] == "ValueError", f"{op} should raise ValueError"
        assert row["status"] == before, f"{op} changed state"
    assert all(row["error"] is None for row in o[:2] + o[-3:])
    assert [summary(s) for s in o[-1]["return"]] == [("fin_sales", 0, 10, 3, 2)], "a rejected change_id was remembered"


# ---------------------------------------------------------------- emit boundary

@check("paused-shard-does-not-block-supported-windows")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 12, 3), ch("b", "b1", "pos.sales", 14, 2), cp("a", 5), cp("b", 5), PUB]
    for i in range(1, 31):
        ops += [tick(), cp("a", 5 + 2 * i)] + ([ch("a", "a2", "pos.sales", 21, 4)] if i == 3 else []) + [PUB]
    o = run(ops, retention=1000, stale_passes=1000)
    got = {(s[0], s[1]): s for s in map(summary, published(o))}
    assert got.get(("fin_sales", 10)) == ("fin_sales", 10, 20, 5, 2), "window covered by the running shard not published within 30 passes"
    assert ("fin_sales", 20) in got, "window covered by the running shard not published within 30 passes"


@check("waiting-does-not-create-confirmation")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 12, 3), ch("a", "a2", "pos.sales", 25, 1), cp("a", 20), cp("b", 20), PUB]
    for _ in range(20):
        ops += [tick(50), PUB]
    o = run(ops, retention=1000, stale_passes=1000)
    assert all(row["status"]["checkpoint"] <= 20 for row in o), "service checkpoint moved beyond every checkpoint received"
    assert [s[1] for s in map(summary, published(o))] == [10]


@check("steady-low-checkpoint-holds-then-recovers")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 22, 4), cp("a", 40), cp("c", 15), PUB]
    for i in range(1, 31):
        ops += [tick(), cp("a", 40 + i), cp("c", 15), PUB]
    hold = len(ops)
    for i in range(1, 31):
        ops += [tick(), cp("a", 70 + i), PUB]
    o = run(ops, shards=("a", "c"), retention=1000, stale_passes=1000)
    assert not published(o[:hold]), "published while a running shard still reported a lower checkpoint"
    assert [summary(s) for s in published(o[hold:])] == [("fin_sales", 20, 30, 4, 1)], "not published within 30 passes after that shard paused"


@check("full-pause-publishes-covered-windows")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 33, 2), ch("b", "b1", "pos.sales", 44, 5), ch("a", "a2", "pos.sales", 52, 1),
           cp("a", 20), cp("b", 20), PUB, tick(), cp("a", 45), cp("b", 41), PUB, tick(), cp("a", 55), cp("b", 41), PUB]
    for _ in range(30):
        ops += [tick(), PUB]
    caught_up = len(ops)
    for _ in range(10):
        ops += [tick(30), PUB]
    o = run(ops, retention=1000, stale_passes=1000)
    starts = [s[1] for s in map(summary, published(o[:caught_up]))]
    assert 30 in starts and 40 in starts, "windows covered by a received checkpoint not published within 30 passes of a full pause"
    assert [s[1] for s in map(summary, published(o))] == [30, 40]


@check("resumed-shard-change-is-corrected")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 12, 3), ch("b", "b1", "pos.sales", 13, 1), cp("a", 10), cp("b", 10), PUB]
    for i in range(1, 31):
        ops += [tick(), cp("a", 10 + 2 * i), PUB]
    resume = len(ops)
    ops += [ch("b", "b2", "pos.sales", 15, 6), cp("b", 30), PUB, tick(), cp("a", 75), cp("b", 40), PUB]
    o = run(ops, retention=1000, stale_passes=1000)
    first = [s for s in published(o[:resume]) if s["window_start"] == 10]
    assert [summary(s) for s in first] == [("fin_sales", 10, 20, 4, 2)], "window not published while the other shard was paused"
    page = o[resume + 2]["return"]
    assert [summary(s) for s in page] == [("fin_sales", 10, 20, 10, 3)] and page[0]["supersedes"] == first[0]["snapshot_id"]
    assert all(s["window_start"] != 10 for s in o[-1]["return"]), "unchanged window published again"


# ---------------------------------------------------------------- collect boundary

@check("unpublished-window-survives-compaction")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 3, 7), cp("a", 30), compact(), compact(1000), tick(20), compact(), PUB, compact()]
    o = run(ops, shards=("a",), retention=5, stale_passes=10)
    assert o[2]["return"] == [] and o[3]["return"] == [] and o[5]["return"] == [], "a window finance never received was compacted"
    assert [summary(s) for s in o[6]["return"]] == [("fin_sales", 0, 10, 7, 1)]
    assert removed(o[7]) == [("fin_sales", 0)], "published expired window not removed"


@check("pending-correction-survives-compaction")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 3, 7), cp("a", 10), tick(30), PUB,
           ch("b", "a2", "pos.sales", 4, 1), cp("b", 10), compact(1000), PUB, compact(1000)]
    o = run(ops, retention=5, stale_passes=1000)
    assert o[6]["return"] == [], "a window with an unpublished change was compacted"
    assert [summary(s) for s in o[7]["return"]] == [("fin_sales", 0, 10, 8, 2)]
    assert removed(o[8]) == [("fin_sales", 0)], "corrected expired window not removed"


@check("idle-age-counts-from-latest-change")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 3, 7), cp("a", 10), tick(30), PUB, tick(40),
           ch("b", "a2", "pos.sales", 5, 1), cp("b", 10), PUB, tick(20), compact(), tick(31), compact()]
    o = run(ops, retention=1000, stale_passes=50)
    assert o[9]["return"] == [], "window that changed 20 passes ago was evicted as idle"
    assert removed(o[11]) == [("fin_sales", 0)], "window idle for more than stale_passes passes not removed"
    resends = run([ch("a", "r1", "pos.sales", 3, 2), cp("a", 10), PUB, tick(8),
                   ch("a", "r1", "pos.sales", 3, 2), cp("a", 10), {"op": "status"}, tick(3), compact()],
                  shards=("a",), retention=1000, stale_passes=10)
    assert removed(resends[-1]) == [("fin_sales", 0)], "a duplicate or non-change call extended the window's idle age"


@check("expired-window-removed-without-extra-wait")
def _(run):
    ops = [ch("a", "a1", "pos.sales", 3, 7), cp("a", 10), tick(30), PUB, compact(15), compact(16),
           ch("b", "a2", "pos.sales", 4, 2), cp("b", 20), PUB, cp("a", 100), PUB, compact()]
    o = run(ops, retention=5, stale_passes=1000)
    assert o[4]["return"] == [], "retention boundary is not expired"
    assert removed(o[5]) == [("fin_sales", 0)], "expired published window kept"
    page = o[8]["return"]
    assert [summary(s) for s in page] == [("fin_sales", 0, 10, 2, 1)] and page[0]["supersedes"] is None, "removed window history leaked into the fresh window"
    assert removed(o[11]) == [("fin_sales", 0)], "window expired by the service checkpoint kept"


# ---------------------------------------------------------------- public replay

@check("replay-runs-public-shift-logs")
def _(run):
    frozen = HERE / "frozen"
    logs = sorted((frozen / "materials").glob("*.jsonl"))
    assert logs, "missing frozen materials"
    work = Path(tempfile.mkdtemp(prefix="replay-", dir=run.__self__.root))
    shutil.copytree(frozen / "materials", work / "materials")
    shutil.copy(frozen / "replay.py", work / "replay.py")
    shutil.copytree(run.__self__.root / "candidate" / "app", work / "app")
    for path in [work, *work.rglob("*")]:
        path.chmod(0o755 if path.is_dir() else 0o644)
    for log in logs:
        lines = [json.loads(x) for x in log.read_text().splitlines() if x.strip()]
        validation = validate_schedule(lines[1:], lines[0]["config"]["shards"], (frozen / "materials" / "tables.csv").read_text())
        validation["public_log"] = log.name
        run.__self__.schedule_validation.append(validation)
        proc = run.__self__.process([sys.executable, "-B", "-E", "-s", "replay.py", f"materials/{log.name}"], cwd=work, timeout=60)
        assert proc.returncode == 0, f"replay of {log.name} failed: {proc.stderr[-300:]}"
        calls = [x for x in log.read_text().splitlines() if x.strip()][1:]
        rows = [json.loads(x) for x in proc.stdout.splitlines() if x.strip()]
        assert len(rows) == len(calls), f"replay of {log.name} printed {len(rows)} rows for {len(calls)} calls"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--candidate", required=True)
    ap.add_argument("--report")
    ap.add_argument("--isolate", action="store_true")
    args = ap.parse_args()
    runner = Runner(args.candidate, args.isolate)
    results = []
    for name, fn in CHECKS:
        try:
            fn(runner.run)
            results.append({"name": name, "ok": True})
        except Exception as exc:
            message = str(exc) or type(exc).__name__
            if not isinstance(exc, AssertionError):
                message = f"{type(exc).__name__}: {message} | " + traceback.format_exc(limit=1).splitlines()[-1]
            results.append({"name": name, "ok": False, "message": message[:500]})
    passed = sum(r["ok"] for r in results)
    report = {"passed": passed, "total": len(results), "reward": 1.0 if passed == len(results) else 0.0,
              "isolate": runner.isolate, "schedule_validation": runner.schedule_validation, "checks": results}
    if args.report:
        Path(args.report).write_text(json.dumps(report, indent=2) + "\n")
    for r in results:
        print(("PASS " if r["ok"] else "FAIL ") + r["name"] + ("" if r["ok"] else "  -- " + r["message"]))
    print(f"{passed}/{len(results)}")
    shutil.rmtree(runner.root, ignore_errors=True)
    return 0 if passed == len(results) else 1


if __name__ == "__main__":
    sys.exit(main())
