#!/bin/sh
set -eu
mkdir -p /logs/verifier
printf '0.0\n' > /logs/verifier/reward.txt
if [ "$(id -u)" != 0 ]; then
  printf '%s\n' 'Verifier isolation requires root.' >&2
  exit 1
fi
chmod 700 /tests
if python3 -I -B /tests/check.py --candidate /app --report /logs/verifier/diagnostics.json --isolate; then
  printf '1.0\n' > /logs/verifier/reward.txt
fi
