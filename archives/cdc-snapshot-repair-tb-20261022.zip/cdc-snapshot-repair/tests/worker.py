"""Run one call schedule against the candidate package and return raw observations.

All judgement lives in check.py; this process only executes calls.
"""
import contextlib
import importlib
import json
import os
import sys

candidate, materials = sys.argv[1:3]
request = json.load(sys.stdin)
sys.path.insert(0, candidate)
protocol_stdout = os.dup(sys.stdout.fileno())
sys.stdout.flush()
os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
rows = []
with contextlib.redirect_stdout(sys.stderr):
    service = importlib.import_module("app").SnapshotService(materials, **request["config"])
    for operation in request["operations"]:
        call = dict(operation)
        op = call.pop("op")
        try:
            returned = getattr(service, op)(**call)
            error = None
        except Exception as exc:  # observations only; check.py decides
            returned, error = None, {"type": type(exc).__name__, "message": str(exc)[:200]}
        try:
            status = service.status()
        except Exception as exc:
            status = {"error": type(exc).__name__}
        # Observe values at call time even if the implementation later reuses a mutable return object.
        rows.append(json.loads(json.dumps({"op": op, "return": returned, "error": error, "status": status})))
payload = (json.dumps({"observations": rows}, sort_keys=True, default=str) + "\n").encode()
try:
    while payload:
        payload = payload[os.write(protocol_stdout, payload):]
finally:
    os.close(protocol_stdout)
