# Finance snapshot service

`SnapshotService` receives row changes and progress checkpoints from database capture agents. It maps source tables to finance tables, accumulates changes in fixed-width commit-time windows, publishes snapshots, and compacts old window state.

Operators have reported three symptoms:

- During a shift when one capture agent was paused, finance stopped receiving snapshots, although the other shards kept streaming changes and checkpoints.
- Some accepted changes never reach finance; they seem to disappear around compaction.
- For some windows, finance totals are lower than the change counts the source databases report.

The working directory is `/app`. Repair the service to satisfy the business contract and Python interface in `/app/docs/OPERATIONS.md`. The catalog and operational logs are in `/app/materials/`; `/app/docs/FILES.md` describes their formats and the replay command.

Deliver the complete `/app/app` package. Keep `/app/app/__init__.py`, the documents, `/app/replay.py`, and the materials unchanged. You may change or add other modules in `/app/app`. Use only the Python standard library. Calls are sequential and single-threaded. Acceptance also exercises other valid catalogs and call schedules.

You have 28800 seconds to complete this task.
