import argparse
import json
from pathlib import Path

from app import SnapshotService


METHODS = frozenset({
    "register_shard", "change", "checkpoint", "tick", "publish", "compact", "status"
})


def replay(log_path):
    log_path = Path(log_path).resolve()
    with log_path.open(encoding="utf-8") as source:
        header = json.loads(next(source))
        service = SnapshotService(materials_dir=log_path.parent, **header["config"])
        for line_number, line in enumerate(source, start=2):
            call = json.loads(line)
            operation = call.pop("op")
            if operation not in METHODS:
                raise ValueError(f"unsupported operation on line {line_number}: {operation}")
            returned = getattr(service, operation)(**call)
            print(json.dumps({
                "line": line_number,
                "op": operation,
                "returned": returned,
                "status": service.status(),
            }, sort_keys=True))


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Replay a finance capture shift log.")
    parser.add_argument("log", help="JSON Lines shift log")
    replay(parser.parse_args().log)
