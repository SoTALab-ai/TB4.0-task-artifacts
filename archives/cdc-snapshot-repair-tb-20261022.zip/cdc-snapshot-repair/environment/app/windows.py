from dataclasses import dataclass


@dataclass
class Window:
    table: str
    window_start: int
    window_end: int
    created_pass: int
    net: int = 0
    changes: int = 0
    published: str | None = None
    published_totals: tuple | None = None

    def totals(self):
        return self.net, self.changes

    def add(self, delta):
        self.net += delta
        self.changes += 1

    def status(self):
        return {
            "table": self.table,
            "window_start": self.window_start,
            "window_end": self.window_end,
            "net": self.net,
            "changes": self.changes,
            "published": self.published,
        }
