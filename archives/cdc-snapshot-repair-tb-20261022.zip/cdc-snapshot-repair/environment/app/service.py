from .catalog import Catalog
from .compaction import compact_windows
from .progress import ShardProgress
from .publication import Publisher
from .windows import Window


def _nonnegative_integer(value, name):
    if not isinstance(value, int) or isinstance(value, bool) or value < 0:
        raise ValueError(f"{name} must be a non-negative integer")


class SnapshotService:
    def __init__(self, materials_dir, shards, retention, stale_passes):
        _nonnegative_integer(retention, "retention")
        _nonnegative_integer(stale_passes, "stale_passes")
        if (
            not isinstance(shards, list)
            or not shards
            or any(not isinstance(shard, str) for shard in shards)
            or len(set(shards)) != len(shards)
        ):
            raise ValueError("shards must be a non-empty list of distinct names")
        self.catalog = Catalog(materials_dir)
        self.progress = ShardProgress(shards)
        self.retention = retention
        self.stale_passes = stale_passes
        self.current_pass = 0
        self.windows = {}
        self.seen_changes = set()
        self.publisher = Publisher()

    def register_shard(self, shard):
        if not isinstance(shard, str):
            raise ValueError("shard must be a name")
        self.progress.register(shard)

    def change(self, shard, change_id, source_table, commit_ts, delta):
        self.progress.require(shard)
        table, width = self.catalog.resolve(source_table)
        _nonnegative_integer(commit_ts, "commit_ts")
        if not isinstance(delta, int) or isinstance(delta, bool):
            raise ValueError("delta must be an integer")
        if not isinstance(change_id, str) or not change_id:
            raise ValueError("change_id must be a non-empty string")
        if change_id in self.seen_changes:
            return
        window_start = commit_ts - commit_ts % width
        key = table, window_start
        if key not in self.windows:
            self.windows[key] = Window(table, window_start, window_start + width, self.current_pass)
        self.windows[key].add(delta)
        self.seen_changes.add(change_id)

    def checkpoint(self, shard, position):
        self.progress.require(shard)
        _nonnegative_integer(position, "position")
        self.progress.advance(shard, position)

    def tick(self, passes=1):
        _nonnegative_integer(passes, "passes")
        self.current_pass += passes

    def publish(self):
        return self.publisher.publish(self.windows, self.progress.checkpoint)

    def compact(self, as_of=None):
        if as_of is not None:
            _nonnegative_integer(as_of, "as_of")
        position = self.progress.checkpoint if as_of is None else as_of
        return compact_windows(
            self.windows, position, self.current_pass, self.retention, self.stale_passes
        )

    def status(self):
        return {
            "pass": self.current_pass,
            "checkpoint": self.progress.checkpoint,
            "windows": [self.windows[key].status() for key in sorted(self.windows)],
        }
