class Publisher:
    def __init__(self):
        self.next_id = 1

    def publish(self, windows, checkpoint):
        snapshots = []
        for key in sorted(windows):
            window = windows[key]
            if checkpoint < window.window_end or window.totals() == window.published_totals:
                continue
            snapshot_id = f"S{self.next_id}"
            self.next_id += 1
            snapshots.append({
                "snapshot_id": snapshot_id,
                "table": window.table,
                "window_start": window.window_start,
                "window_end": window.window_end,
                "net": window.net,
                "changes": window.changes,
                "supersedes": window.published,
            })
            window.published = snapshot_id
            window.published_totals = window.totals()
        return snapshots
