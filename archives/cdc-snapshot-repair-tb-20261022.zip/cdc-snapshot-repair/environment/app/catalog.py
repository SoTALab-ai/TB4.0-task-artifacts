import csv
from pathlib import Path


class Catalog:
    def __init__(self, materials_dir):
        self.tables = {}
        with (Path(materials_dir) / "tables.csv").open(newline="", encoding="utf-8") as source:
            for row in csv.DictReader(source):
                try:
                    width = int(row["width"])
                except (TypeError, ValueError) as exc:
                    raise ValueError("width must be a positive integer") from exc
                if width <= 0:
                    raise ValueError("width must be a positive integer")
                self.tables[row["source_table"]] = (row["finance_table"], width)

    def resolve(self, source_table):
        try:
            return self.tables[source_table]
        except (KeyError, TypeError) as exc:
            raise ValueError("unknown source table") from exc
