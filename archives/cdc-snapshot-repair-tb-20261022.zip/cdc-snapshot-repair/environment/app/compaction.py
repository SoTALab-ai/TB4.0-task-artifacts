def compact_windows(windows, checkpoint, current_pass, retention, stale_passes):
    removed = []
    for key in sorted(windows):
        window = windows[key]
        changed_after_publication = (
            window.published is not None
            and window.totals() != window.published_totals
        )
        expired = checkpoint > window.window_end + retention
        stale = current_pass - window.created_pass > stale_passes
        if (expired and not changed_after_publication) or stale:
            removed.append({"table": window.table, "window_start": window.window_start})
            del windows[key]
    return removed
