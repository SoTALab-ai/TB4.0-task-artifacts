class ShardProgress:
    def __init__(self, shards):
        self.positions = {shard: 0 for shard in shards}
        self.checkpoint = 0

    def require(self, shard):
        try:
            known = shard in self.positions
        except TypeError as exc:
            raise ValueError("unknown shard") from exc
        if not known:
            raise ValueError("unknown shard")

    def register(self, shard):
        self.positions.setdefault(shard, 0)
        self.checkpoint = min(self.positions.values())

    def advance(self, shard, position):
        self.positions[shard] = max(self.positions[shard], position)
        self.checkpoint = min(self.positions.values())
