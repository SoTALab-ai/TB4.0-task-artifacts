# Finance snapshot operations

Each database shard has a capture agent. The finance service receives changes from those agents and combines them into snapshots for finance tables. The table catalog determines the destination table and window width for each source table.

## Input progress and finance delivery

Commit timestamps and checkpoint positions are non-negative integers on one shared commit-position scale. A checkpoint report for a shard promises that the shard has already sent every change with `commit_ts < position`. Checkpoint reports are cumulative: reporting a lower position adds no progress. A newly registered shard starts at position zero. Changes contain data; receiving a change does not provide a checkpoint.

`tick(passes)` advances the maintenance-pass counter, which is the service's measure of elapsed time. It provides no information about database contents. While an agent is running, it sends a checkpoint at least once every two passes. An operator may pause an agent, which then sends nothing until it resumes. A running agent can report the same checkpoint repeatedly, for example during a long database transaction.

The service checkpoint reports confirmed input progress on the shared commit-position scale. It starts at zero, never moves backwards, and must always be supported by checkpoint reports actually received. Elapsed maintenance passes provide no additional input confirmation. A window covers `[window_start, window_end)` and is eligible for publication when the service checkpoint reaches its end: `checkpoint >= window_end`.

The service checkpoint marks commit coverage already settled for routine finance delivery. Newly registered or returning agents do not reopen settled coverage; their changes to that history are delivered using the correction and post-compaction rules below. Extending coverage to later positions must respect every capture agent that continues to report, even when its reported position stays unchanged.

Finance service levels require windows covered by the running agents' checkpoints to become ready for publication within 30 passes, including shifts in which some agents are paused. If all agents are paused, windows already covered by at least one received checkpoint must also become ready within 30 passes. This is a readiness deadline: the next `publish()` call at or after that point must return pending eligible snapshots. Other methods do not deliver snapshots to finance.

Finance retains every published window. While its service state is retained, updates to a published window arrive as corrected snapshots that supersede the earlier snapshot. An agent returning from a pause may deliver changes for a window finance has already received; finance needs a corrected snapshot for those changes. The fresh-history rule below applies when the old service state has already been compacted.

## Changes and window state

Change identifiers are unique within a shard. Delivery is at least once, so the same shard can resend a change with the same identifier. That change contributes once.

For a source table whose catalog width is `width`, the change belongs to the catalog's finance table and to the window starting at `commit_ts - commit_ts % width`. Its end is the start plus `width`. A valid catalog lists each source table once, and all source tables feeding the same finance table use the same width. A window's `net` is the sum of its counted deltas, and `changes` is the number of counted changes.

## Compaction

When the service checkpoint is greater than `window_end + retention`, that window is past its retention deadline. That compaction must reclaim state no longer needed by finance. An explicit `as_of` value is used in place of the service checkpoint for that call. The requirement to preserve changes not yet received by finance takes precedence over both retention and inactivity deadlines. Continued archive growth after shifts have finished is an operational incident.

A window must also be removed by compaction after more than `stale_passes` passes without a newly accepted, non-duplicate change, provided removal does not lose a change finance has not received. This can happen before ordinary retention. Maintenance passes, checkpoint reports, publication, and duplicate deliveries are not window activity.

Compaction must never lose a change that finance has not yet received in a snapshot. If a later change arrives after a window's state was removed, it starts a fresh window. The first snapshot of that fresh window has `supersedes: null`.

## Python interface

Import `SnapshotService` from `app`. Only the Python standard library is available. Calls are sequential and single-threaded.

```python
SnapshotService(materials_dir, shards, retention, stale_passes)
register_shard(shard) -> None
change(shard, change_id, source_table, commit_ts, delta) -> None
checkpoint(shard, position) -> None
tick(passes=1) -> None
publish() -> list[dict]
compact(as_of=None) -> list[dict]
status() -> dict
```

The constructor reads `tables.csv` from `materials_dir`. `shards` is a non-empty list of distinct shard names, all initially registered at position zero. `retention` and `stale_passes` are non-negative integers. `register_shard` is idempotent.

`publish()` returns one snapshot per eligible window whose `(net, changes)` has never been published or differs from its last published snapshot. Results are ordered by `(table, window_start)`. Repeating publication without new input returns an empty list. Each snapshot contains:

| Field | Meaning |
| --- | --- |
| `snapshot_id` | A service-wide identifier `S<n>`; numbering begins at 1. |
| `table` | Finance table name. |
| `window_start`, `window_end` | The half-open window bounds. |
| `net`, `changes` | Counted delta total and change count. |
| `supersedes` | The previous snapshot identifier for this window, or `null`. |

`compact()` returns the removed windows as dictionaries with `table` and `window_start`, ordered by those fields. An explicit `as_of` replaces the service checkpoint only for that compaction call and never alters a shard checkpoint.

`status()` returns a dictionary with `pass`, `checkpoint`, and `windows`. The windows are ordered by `(table, window_start)`. Each window entry contains `table`, `window_start`, `window_end`, `net`, `changes`, and `published`. `published` is its last published snapshot identifier, or `null`.

Invalid calls raise `ValueError` without changing any state. Invalid input includes an unknown shard or source table, an empty `change_id`, negative or non-integer `commit_ts`, `position`, `passes`, or `as_of`, and a non-integer `delta`. Boolean values do not qualify as integers. `as_of=None` selects the service checkpoint.
