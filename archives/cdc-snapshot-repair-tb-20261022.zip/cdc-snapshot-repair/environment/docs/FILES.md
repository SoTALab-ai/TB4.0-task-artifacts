# Catalog and shift records

## Table catalog

`materials/tables.csv` is a UTF-8 CSV file with a header and these columns:

| Column | Meaning |
| --- | --- |
| `source_table` | Table name supplied by a capture agent. |
| `finance_table` | Destination table used in finance snapshots. |
| `width` | Positive integer window width on the shared commit-position scale. |

Each source table occurs once. Multiple source tables can feed one finance table; those sources must use the same width. The supplied catalog maps four source tables to three finance tables.

## Shift logs

`materials/night-shift.jsonl` and `materials/maintenance.jsonl` contain one operational timeline each. They are UTF-8 JSON Lines files. The first line contains a `config` object with `shards`, `retention`, and `stale_passes`. Each remaining line is a call: `op` names a service method, and the other fields are that method's keyword arguments.

The supported operations are `register_shard`, `change`, `checkpoint`, `tick`, `publish`, `compact`, and `status`, with arguments described in `OPERATIONS.md`. Maintenance passes are recorded by `tick` calls. A pause is represented by the absence of traffic from the affected capture agent.

The logs have no expected-output column.

## Replay

From the container's `/app` working directory (the source package's `environment/` directory), run:

```sh
python3 replay.py materials/night-shift.jsonl
python3 replay.py materials/maintenance.jsonl
```

The replay utility constructs the service using the first line and takes `materials_dir` from the log's directory. It executes the remaining calls in file order. For each call it prints a JSON object with `line` (the source line number), `op`, `returned` (including `null` for methods that return `None`), and the current `status`.
