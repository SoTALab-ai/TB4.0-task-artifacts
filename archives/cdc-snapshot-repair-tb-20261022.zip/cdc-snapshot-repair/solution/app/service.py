"""Private development reference used to validate tests/check.py. Not part of the public package."""
import csv
from pathlib import Path

QUIET = 8


def _int(value, name, minimum=0):
    if isinstance(value, bool) or not isinstance(value, int) or value < minimum:
        raise ValueError(name)
    return value


class SnapshotService:
    def __init__(self, materials_dir, shards, retention, stale_passes):
        self.tables = {}
        with open(Path(materials_dir) / "tables.csv", newline="") as f:
            for row in csv.DictReader(f):
                width = int(row["width"])
                if width <= 0:
                    raise ValueError("width")
                self.tables[row["source_table"]] = (row["finance_table"], width)
        if not shards or len(set(shards)) != len(shards):
            raise ValueError("shards")
        self.retention, self.stale = _int(retention, "retention"), _int(stale_passes, "stale_passes")
        self.pass_ = 0
        self.ckpt, self.seen_at = {}, {}
        self.highest = self.committed = 0
        self.seen = set()
        self.windows = {}
        self.serial = 0
        for s in shards:
            self.register_shard(s)

    def register_shard(self, shard):
        if not isinstance(shard, str) or not shard:
            raise ValueError("shard")
        if shard not in self.ckpt:
            self.ckpt[shard] = 0
            self.seen_at[shard] = self.pass_
        self._refresh()

    def _shard(self, shard):
        if shard not in self.ckpt:
            raise ValueError("shard")

    def change(self, shard, change_id, source_table, commit_ts, delta):
        self._shard(shard)
        if not isinstance(change_id, str) or not change_id or source_table not in self.tables:
            raise ValueError("change")
        _int(commit_ts, "commit_ts")
        if isinstance(delta, bool) or not isinstance(delta, int):
            raise ValueError("delta")
        self.seen_at[shard] = self.pass_
        if (shard, change_id) in self.seen:
            return None
        self.seen.add((shard, change_id))
        table, width = self.tables[source_table]
        start = commit_ts - commit_ts % width
        w = self.windows.setdefault((table, start), {"end": start + width, "net": 0, "changes": 0, "last": None, "touched": self.pass_})
        w["net"] += delta
        w["changes"] += 1
        w["touched"] = self.pass_

    def checkpoint(self, shard, position):
        self._shard(shard)
        _int(position, "position")
        self.ckpt[shard] = max(self.ckpt[shard], position)
        self.seen_at[shard] = self.pass_
        self.highest = max(self.highest, position)
        self._refresh()

    def tick(self, passes=1):
        self.pass_ += _int(passes, "passes")
        self._refresh()

    def _refresh(self):
        active = [self.ckpt[s] for s in self.ckpt if self.pass_ - self.seen_at[s] < QUIET]
        candidate = min(active) if active else self.highest
        self.committed = max(self.committed, min(candidate, self.highest))

    def _owed(self, w):
        return w["last"] is None or (w["net"], w["changes"]) != (w["last"][1], w["last"][2])

    def publish(self):
        out = []
        for (table, start), w in sorted(self.windows.items()):
            if self.committed >= w["end"] and self._owed(w):
                self.serial += 1
                sid = f"S{self.serial}"
                out.append({"snapshot_id": sid, "table": table, "window_start": start, "window_end": w["end"],
                            "net": w["net"], "changes": w["changes"], "supersedes": w["last"][0] if w["last"] else None})
                w["last"] = (sid, w["net"], w["changes"])
        return out

    def compact(self, as_of=None):
        progress = self.committed if as_of is None else _int(as_of, "as_of")
        gone = []
        for key, w in sorted(self.windows.items()):
            if self._owed(w):
                continue
            if progress > w["end"] + self.retention or self.pass_ - w["touched"] > self.stale:
                gone.append(key)
        for key in gone:
            del self.windows[key]
        return [{"table": t, "window_start": s} for t, s in gone]

    def status(self):
        return {"pass": self.pass_, "checkpoint": self.committed,
                "windows": [{"table": t, "window_start": s, "window_end": w["end"], "net": w["net"],
                             "changes": w["changes"], "published": w["last"][0] if w["last"] else None}
                            for (t, s), w in sorted(self.windows.items())]}

