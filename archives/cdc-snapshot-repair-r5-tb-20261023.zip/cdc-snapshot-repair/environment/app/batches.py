from dataclasses import dataclass
from .ledger import HistoryNode


@dataclass
class Batch:
    batch_id: str
    table: str
    start: int
    stop: int
    net: int
    changes: int
    created_pass: int
    history: HistoryNode

    def record(self):
        return {
            "batch_id": self.batch_id,
            "table": self.table,
            "start": self.start,
            "stop": self.stop,
            "net": self.net,
            "changes": self.changes,
        }

    def contents(self):
        return {
            "start": self.start,
            "stop": self.stop,
            "net": self.net,
            "changes": self.changes,
        }


class Batches:
    def __init__(self, gap):
        self.gap = gap
        self.items = {}
        self.accepted = set()
        self.next_id = 1

    def ordered(self):
        return sorted(
            self.items.values(),
            key=lambda batch: (batch.table, batch.start, batch.batch_id),
        )

    def add(self, identity, table, start, stop, delta, current_pass, ledger):
        joined = []
        remaining = [batch for batch in self.items.values() if batch.table == table]
        left, right = start, stop
        while True:
            touching = [
                batch for batch in remaining
                if batch.start <= right + self.gap and left <= batch.stop + self.gap
            ]
            if not touching:
                break
            joined.extend(touching)
            left = min(left, *(batch.start for batch in touching))
            right = max(right, *(batch.stop for batch in touching))
            touching_ids = {batch.batch_id for batch in touching}
            remaining = [batch for batch in remaining if batch.batch_id not in touching_ids]

        if not joined:
            batch_id = f"B{self.next_id:08d}"
            self.next_id += 1
            self.items[batch_id] = Batch(
                batch_id, table, start, stop, delta, 1, current_pass,
                HistoryNode()
            )
            self.accepted.add(identity)
            return

        owner = min(joined, key=lambda batch: int(batch.batch_id[1:]))
        net = delta + sum(batch.net for batch in joined)
        changes = 1 + sum(batch.changes for batch in joined)
        created_pass = min(batch.created_pass for batch in joined)
        for batch in joined:
            ledger.invalidate(batch.history)
            if batch.batch_id != owner.batch_id:
                owner.history.parents.append(batch.history)
                del self.items[batch.batch_id]
        owner.start = left
        owner.stop = right
        owner.net = net
        owner.changes = changes
        owner.created_pass = created_pass
        self.accepted.add(identity)
