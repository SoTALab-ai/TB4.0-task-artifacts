class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def pending_for(self, batch):
        node = batch.history
        return [receipt_id for receipt_id in node.corrections
                if node.postings[receipt_id]["state"] == "posted"]

    def publish_one(self, batch, boundary, gap, ledger):
        if batch.stop + gap > boundary:
            return None
        node = batch.history
        pending = self.pending_for(batch)
        if pending:
            withdrawn = ledger.withdraw(node, pending[:self.page_size])
            return {"batch_id": batch.batch_id, "table": batch.table,
                    "withdrawn": withdrawn, "snapshot": None}
        if node.current is not None:
            return None
        receipt = ledger.post(node, batch.contents())
        return {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": [], "snapshot": receipt}

    def publish(self, batches, boundary, gap, ledger):
        pages = []
        for batch in batches.ordered():
            page = self.publish_one(batch, boundary, gap, ledger)
            if page is not None:
                pages.append(page)
        return pages
