from dataclasses import dataclass, field


@dataclass
class HistoryNode:
    postings: dict = field(default_factory=dict)
    corrections: list = field(default_factory=list)
    current: str | None = None
    parents: list = field(default_factory=list)


class ReceiptLedger:
    def __init__(self):
        self.next_id = 1

    def post(self, node, contents):
        receipt = {"receipt_id": f"R{self.next_id:08d}", **contents}
        self.next_id += 1
        node.postings[receipt["receipt_id"]] = {
            "receipt": receipt, "state": "posted"
        }
        node.current = receipt["receipt_id"]
        return dict(receipt)

    def invalidate(self, node):
        if node.current is not None:
            entry = node.postings[node.current]
            if entry["state"] == "posted" and node.current not in node.corrections:
                node.corrections.append(node.current)
            node.current = None

    def withdraw(self, node, receipt_ids):
        withdrawn = []
        for receipt_id in receipt_ids:
            entry = node.postings[receipt_id]
            if entry["state"] != "posted":
                raise ValueError("receipt is not posted")
            entry["state"] = "withdrawn"
            node.corrections.remove(receipt_id)
            withdrawn.append(dict(entry["receipt"]))
        return withdrawn

    def archive(self, node):
        for parent in node.parents:
            self.archive(parent)
        for entry in node.postings.values():
            if entry["state"] == "posted":
                entry["state"] = "archived"
        node.corrections.clear()
        node.current = None
