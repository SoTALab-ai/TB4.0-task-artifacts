from copy import deepcopy


class OutboundJournal:
    def __init__(self):
        self.journal = []
        self.latest = {}
        self.closures = []
        self._posted = {}
        self._work = {}
        self._next_instance = 1

    def transfer(self, owner, merged, current_pass):
        scope = self._posted.setdefault(owner, [])
        for batch_id in merged:
            scope.extend(self._posted.pop(batch_id))
            del self._work[batch_id]
            self.latest.pop(batch_id, None)
        self._work[owner] = current_pass

    def posted(self, batch_id):
        return deepcopy(self._posted[batch_id])

    def last_work(self, batch_id):
        return self._work[batch_id]

    def complete(self, batch_id, current):
        posted = self._posted[batch_id]
        return len(posted) == 1 and posted[0]["value"] == current

    def deliver(self, batch, withdrawn_ids, snapshot):
        scope = self._posted[batch.batch_id]
        selected = set(withdrawn_ids)
        assert len(selected) == len(withdrawn_ids)
        withdrawn = [deepcopy(instance["value"]) for instance in scope
                     if instance["instance_id"] in selected]
        assert len(withdrawn) == len(selected)
        scope[:] = [instance for instance in scope if instance["instance_id"] not in selected]
        if snapshot is not None:
            scope.append({"instance_id": self._next_instance, "value": deepcopy(snapshot)})
            self._next_instance += 1
            self.latest[batch.batch_id] = deepcopy(snapshot)
        page = {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": withdrawn, "snapshot": deepcopy(snapshot)}
        self.journal.append(deepcopy(page))
        return page

    def archive(self, batch):
        self.closures.append({"batch": batch.record(),
                              "posted": deepcopy(self._posted[batch.batch_id])})
        del self._posted[batch.batch_id]
        del self._work[batch.batch_id]
        self.latest.pop(batch.batch_id, None)
