from dataclasses import dataclass


@dataclass(frozen=True)
class BatchView:
    batch_id: str
    table: str
    start: int
    stop: int
    net: int
    changes: int
    created_pass: int

    def record(self):
        return {key: getattr(self, key) for key in
                ("batch_id", "table", "start", "stop", "net", "changes")}

    def contents(self):
        return {"net": self.net, "changes": self.changes}


class Batches:
    def __init__(self, gap):
        self.gap = gap
        self._rows = {}
        self.accepted = set()
        self.next_id = 1

    def select(self, batch_id):
        return BatchView(**self._rows[batch_id])

    def ordered(self):
        return sorted((self.select(key) for key in self._rows),
                      key=lambda view: (view.table, view.start, view.batch_id))

    def add(self, identity, table, start, stop, delta, current_pass):
        joined = []
        remaining = [row for row in self._rows.values() if row["table"] == table]
        left, right = start, stop
        while True:
            touching = [row for row in remaining
                        if row["start"] <= right + self.gap
                        and left <= row["stop"] + self.gap]
            if not touching:
                break
            joined.extend(touching)
            left = min(left, *(row["start"] for row in touching))
            right = max(right, *(row["stop"] for row in touching))
            ids = {row["batch_id"] for row in touching}
            remaining = [row for row in remaining if row["batch_id"] not in ids]
        if joined:
            owner = min((row["batch_id"] for row in joined), key=lambda key: int(key[1:]))
            created = min(row["created_pass"] for row in joined)
        else:
            owner = f"B{self.next_id:08d}"
            self.next_id += 1
            created = current_pass
        merged = sorted((row["batch_id"] for row in joined if row["batch_id"] != owner),
                        key=lambda key: int(key[1:]))
        self._rows[owner] = dict(batch_id=owner, table=table, start=left, stop=right,
            net=delta + sum(row["net"] for row in joined),
            changes=1 + sum(row["changes"] for row in joined), created_pass=created)
        for batch_id in merged:
            del self._rows[batch_id]
        self.accepted.add(identity)
        return owner, merged

    def remove(self, batch_id):
        del self._rows[batch_id]
