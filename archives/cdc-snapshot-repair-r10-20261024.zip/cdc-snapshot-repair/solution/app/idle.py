class IdleSweep:
    def __init__(self, stale_passes):
        self.stale_passes = stale_passes

    def compact(self, batches, current_pass, ledger):
        removed = []
        for batch in batches.ordered():
            if not ledger.complete(batch.batch_id, batch.contents()):
                continue
            if current_pass - ledger.last_work(batch.batch_id) > self.stale_passes:
                ledger.archive(batch)
                batches.remove(batch.batch_id)
                removed.append(batch.batch_id)
        return removed
