from .idle import IdleSweep


class OrdinarySweep:
    def __init__(self, gap, retention):
        self.gap = gap
        self.retention = retention

    def compact(self, batches, boundary, ledger):
        removed = []
        for batch in batches.ordered():
            if not ledger.complete(batch.batch_id, batch.contents()):
                continue
            if boundary > batch.stop + self.gap + self.retention:
                ledger.archive(batch)
                batches.remove(batch.batch_id)
                removed.append(batch.batch_id)
        return removed


class Retention:
    def __init__(self, gap, retention, stale_passes):
        self.ordinary = OrdinarySweep(gap, retention)
        self.idle = IdleSweep(stale_passes)

    def compact(self, batches, boundary, current_pass, ledger):
        removed = self.ordinary.compact(batches, boundary, ledger)
        removed.extend(self.idle.compact(batches, current_pass, ledger))
        return sorted(removed, key=lambda batch_id: int(batch_id[1:]))
