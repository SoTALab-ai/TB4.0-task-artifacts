import sys
sys.path.insert(0,'/solution/.tb4-native-qa/engine')
from failure_synthesis.native_qa_runtime import run_native_qa_bundle
run_native_qa_bundle('/solution/.tb4-native-qa','25101d3056054b662c9d30ac37b1c06cd98946ec9b33512e40c347efe6bf8a3f')
