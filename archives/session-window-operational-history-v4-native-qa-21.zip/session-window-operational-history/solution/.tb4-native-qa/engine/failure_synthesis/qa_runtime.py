"""Pure frozen QA execution shared by local and native Oracle backends.

No authoring prompts, model/API client, repository scan or platform submission.
"""
import hashlib
import json
import os
from pathlib import Path
import tempfile

from .acceptance import aggregate_scores
from .execution import run_scorer, safe_relative
from .quality import bind_case_review, compare_case, summarize_cases
from .validation import canonical_sha256, file_bytes


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, name = tempfile.mkstemp(prefix="." + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as stream:
            json.dump(value, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
        os.replace(name, path)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _digest(data):
    return hashlib.sha256(data).hexdigest()

def _files(response, roles, *, submission=False):
    files = response.get("files")
    if not isinstance(files, list):
        raise ValueError("response.files must be a list")
    paths = set()
    for item in files:
        if not isinstance(item, dict):
            raise ValueError("files must contain objects")
        path = safe_relative(item.get("path"))
        if path in paths or any(path.startswith(p + "/") or p.startswith(path + "/") for p in paths):
            raise ValueError("duplicate or colliding file paths")
        paths.add(path)
        if "symlink" in item or "symlink_target" in item:
            raise ValueError("declared symlinks are not accepted")
        if submission:
            if "content" not in item or not isinstance(item["content"], str):
                raise ValueError("submission files require text content")
            continue
        role = item.get("role")
        if not isinstance(role, str) or role not in roles:
            raise ValueError("unsupported file role: " + str(role))
        content, source = "content" in item, "source_asset_path" in item
        if content == source:
            raise ValueError("each file needs exactly one of content and source_asset_path")
        if content and not isinstance(item["content"], str):
            raise ValueError("file content must be text")
        if content:
            file_bytes(item)
        if source:
            safe_relative(item["source_asset_path"])
            if role != "public_material":
                raise ValueError("only public materials may copy frozen source assets")
        if role == "instruction" and path != "instruction.md":
            raise ValueError("instruction must be at instruction.md")
        if role == "public_material" and not path.startswith("environment/"):
            raise ValueError("public material must be under environment/")
        if role in {"verifier", "verifier_asset"} and not path.startswith("private/"):
            raise ValueError("scoring assets must be private")
    return files


def verify_candidate(directory, manifest):
    directory = Path(directory)
    if directory.is_symlink():
        raise ValueError("candidate cannot be a symlink")
    expected = {entry["path"]: entry["sha256"] for entry in manifest["files"]}
    actual = {}
    for path in directory.rglob("*"):
        if path.is_symlink():
            raise ValueError("frozen candidate contains a symlink")
        if path.is_file():
            actual[str(path.relative_to(directory))] = _digest(path.read_bytes())
    if expected != actual:
        raise ValueError("frozen candidate file set or contents changed")


def score_submission(candidate, manifest, submission, verifier, *, backend="auto", image="python:3.12-slim", timeout=30, runner=None):
    verify_candidate(candidate, manifest)
    receipt = (runner or run_scorer)(candidate, submission, verifier["command"], backend=backend, image=image, timeout=timeout)
    receipt["candidate_sha256"] = canonical_sha256(manifest)
    receipt["baseline_sha256"] = manifest["baseline_sha256"]
    if receipt["execution_status"] == "executed":
        raw = receipt.get("result")
        try:
            if not isinstance(raw, dict) or raw.get("schema_version") != "tb4.score-result/v1":
                raise ValueError("expected tb4.score-result/v1")
            scores = raw.get("scores")
            result = {"scores": scores, **aggregate_scores(scores, verifier["inheritance"])}
            for key in ("reward", "passed"):
                if key in raw and raw[key] != result[key]:
                    raise ValueError("scorer reported a result inconsistent with original aggregation")
            receipt["score_result"] = result
        except (ValueError, KeyError, TypeError) as exc:
            receipt.update(execution_status="protocol_error", reason=str(exc))
    return receipt


def _write_submission(response, directory):
    files = _files(response, set(), submission=True)
    if directory.is_symlink():
        raise ValueError("submission directory cannot be a symlink")
    if directory.exists():
        # Resumption checks exactly the same frozen files instead of rewriting.
        expected = {f["path"]: _digest(f["content"].encode()) for f in files}
        actual = {str(p.relative_to(directory)): _digest(p.read_bytes()) for p in directory.rglob("*") if p.is_file()}
        if any(p.is_symlink() for p in directory.rglob("*")) or actual != expected:
            raise ValueError("frozen submission changed")
        return
    directory.mkdir(parents=True)
    for item in files:
        path = directory / item["path"]
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(item["content"], encoding="utf-8")


def execute_case_batch(out, baseline, verifier, manifest, cases, case_review, *, candidate_root=None,
                       receipt_out=None, backend="auto", image="python:3.12-slim", timeout=30, scorer=None):
    """Reuse the exact frozen-case scorer path, without quality or model APIs."""
    out = Path(out)
    candidate_root, receipt_out = candidate_root or out / "candidate", receipt_out or out
    trusted_cases = bind_case_review(cases, case_review, baseline, read_json(out / "qa/case-freeze.json"))
    reviews = {check["id"]: check for check in case_review["checks"]}
    qa_path = Path(receipt_out) / "qa/results.json"
    records = []
    for original, case in zip(cases["cases"], trusted_cases):
        review = reviews[case["id"]]
        directory = out / "qa/cases" / case["id"] / "submission"
        _write_submission({"files": case["files"]}, directory)
        receipt = (scorer or score_submission)(candidate_root, manifest, directory, verifier, backend=backend, image=image, timeout=timeout) if review["status"] == "valid" else {"execution_status": "not_executed", "reason": "case validity is not established"}
        comparison = compare_case(case, receipt.get("score_result"), receipt["execution_status"], verifier["inheritance"])
        records.append({"case_id": case["id"], "kind": case["kind"], "case_sha256": canonical_sha256(original),
                        "execution": receipt, **comparison})
        write_json(qa_path, {"records": records, "summary": summarize_cases(records)})
    return records


def finish_case_batch(records, trusted_cases, reviews):
    """Original paired-control rule; no new score or acceptance criterion."""
    by_id = {record["case_id"]: record for record in records}
    case_by_id = {case["id"]: case for case in trusted_cases}
    for case in trusted_cases:
        control_id = case.get("control_id")
        if control_id:
            control = by_id[control_id]
            control_case = case_by_id[control_id]
            legal_mother = control_case["kind"] in {"legal", "equivalent"} or (
                control_case["kind"] == "boundary" and reviews[control_id].get("legal_control") is True)
            if not legal_mother or control["classification"] != "matched":
                record = by_id[case["id"]]
                record.update(classification="pair_control_unvalidated", valid_for_statistics=False, target_detection=None)
    return summarize_cases(records)

