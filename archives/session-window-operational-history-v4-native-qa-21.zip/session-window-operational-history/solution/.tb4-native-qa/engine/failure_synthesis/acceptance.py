"""Freeze original acceptance rules and validate their inheritance.

This module reads and snapshots source bytes; it never imports or executes a
verifier.  ``instance_values`` may change when material is replaced.  Every
other grading rule remains byte-equivalent under canonical JSON comparison.

Aggregation is explicit: ``sum`` sums raw scores, ``weighted_mean`` averages
raw scores with the original weights, and ``all`` applies each item's original
threshold.  There is no implicit normalization or conversion to full marks.
"""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
from typing import Any


BASELINE_SCHEMA = "tb4.acceptance-baseline/v1"
INHERITANCE_SCHEMA = "tb4.acceptance-inheritance/v1"
RECEIPT_SCHEMA = "tb4.acceptance-freeze/v1"
_SHA256 = re.compile(r"^[0-9a-f]{64}$")
_COMMON_FIELDS = {
    "score_items", "aggregation", "required_interfaces", "source_contract",
    "rubric", "ungraded_requirements",
}
_ITEM_FIELDS = {
    "id", "description", "source_refs", "criterion", "min_score", "max_score",
    "weight", "pass_threshold", "tolerance", "allowed_equivalences",
}


def _json_check(value: Any, label: str, errors: list[str]) -> None:
    if isinstance(value, dict):
        for key, child in value.items():
            if not isinstance(key, str):
                errors.append(f"{label}: JSON object keys must be strings")
            _json_check(child, f"{label}.{key}", errors)
    elif isinstance(value, list):
        for index, child in enumerate(value):
            _json_check(child, f"{label}[{index}]", errors)
    elif value is None or isinstance(value, (str, bool, int)):
        return
    elif isinstance(value, float) and math.isfinite(value):
        return
    else:
        errors.append(f"{label}: expected finite JSON data")


def _canonical(value: Any) -> bytes:
    errors: list[str] = []
    _json_check(value, "value", errors)
    if errors:
        raise ValueError("; ".join(errors))
    return json.dumps(value, sort_keys=True, ensure_ascii=False,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def baseline_hash(baseline: dict) -> str:
    """Return the canonical JSON SHA-256 used by the other pipeline stages."""
    return hashlib.sha256(_canonical(baseline)).hexdigest()


def _same(left: Any, right: Any) -> bool:
    return _canonical(left) == _canonical(right)


def _text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _number(value: Any) -> bool:
    if not isinstance(value, (int, float)) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _relative_path(value: Any) -> str:
    if not _text(value) or "\\" in value or "\x00" in value:
        raise ValueError("asset path must be a nonempty POSIX relative path")
    path = PurePosixPath(value)
    if (path.is_absolute() or any(part in {"", ".", ".."} for part in value.split("/"))
            or re.match(r"^[A-Za-z]:", value)):
        raise ValueError(f"unsafe asset path: {value!r}")
    return path.as_posix()


def _file_under(root: Path, relative: str) -> Path:
    relative = _relative_path(relative)
    root = root.resolve(strict=True)
    path = root
    for part in PurePosixPath(relative).parts:
        path = path / part
        if path.is_symlink():
            raise ValueError(f"symlink asset paths are not supported: {relative}")
    resolved = path.resolve(strict=True)
    if not resolved.is_relative_to(root) or not resolved.is_file():
        raise ValueError(f"asset is not a regular file inside source root: {relative}")
    return resolved


def _strings(value: Any, label: str, errors: list[str]) -> None:
    if not isinstance(value, list) or any(not _text(item) for item in value):
        errors.append(f"{label}: expected a list of nonempty strings")


def _score_items(items: Any, errors: list[str], assets: set[str] | None = None,
                 inherited: bool = False) -> None:
    if not isinstance(items, list) or not items:
        errors.append("score_items: expected a nonempty list")
        return
    seen: set[str] = set()
    for index, item in enumerate(items):
        label = f"score_items[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{label}: expected an object")
            continue
        allowed = _ITEM_FIELDS | {"instance_values"}
        required = set(_ITEM_FIELDS)
        if inherited:
            allowed.add("source_item_id")
            required.add("source_item_id")
        for field in sorted(required - item.keys()):
            errors.append(f"{label}.{field}: required")
        for field in sorted(item.keys() - allowed):
            errors.append(f"{label}.{field}: unsupported field")
        identifier = item.get("id")
        if not _text(identifier):
            errors.append(f"{label}.id: expected a nonempty string")
        elif identifier in seen:
            errors.append(f"{label}.id: duplicate {identifier!r}")
        else:
            seen.add(identifier)
        if inherited and item.get("source_item_id") != identifier:
            errors.append(f"{label}.source_item_id: v1 must equal id")
        if not _text(item.get("description")):
            errors.append(f"{label}.description: expected a nonempty string")
        for field in ("criterion", "tolerance"):
            if not isinstance(item.get(field), dict):
                errors.append(f"{label}.{field}: expected an object")
        if item.get("criterion") == {}:
            errors.append(f"{label}.criterion: original rule must not be empty")
        if "instance_values" in item and not isinstance(item["instance_values"], dict):
            errors.append(f"{label}.instance_values: expected an object")
        for field in ("min_score", "max_score", "weight", "pass_threshold"):
            if not _number(item.get(field)):
                errors.append(f"{label}.{field}: expected a finite number, not bool")
        low, high, threshold, weight = (item.get(field) for field in
                                      ("min_score", "max_score", "pass_threshold", "weight"))
        if _number(low) and _number(high):
            if low > high:
                errors.append(f"{label}: min_score exceeds max_score")
            elif _number(threshold) and not low <= threshold <= high:
                errors.append(f"{label}.pass_threshold: outside score range")
        if _number(weight) and weight < 0:
            errors.append(f"{label}.weight: must not be negative")
        _strings(item.get("allowed_equivalences"), f"{label}.allowed_equivalences", errors)
        refs = item.get("source_refs")
        if not isinstance(refs, list) or not refs:
            errors.append(f"{label}.source_refs: expected a nonempty list")
            continue
        for ref_index, ref in enumerate(refs):
            ref_label = f"{label}.source_refs[{ref_index}]"
            if not isinstance(ref, dict) or set(ref) != {"path", "lines"}:
                errors.append(f"{ref_label}: expected path and lines")
                continue
            try:
                path = _relative_path(ref["path"])
                if assets is not None and path not in assets:
                    errors.append(f"{ref_label}.path: not declared in source.assets")
            except ValueError as exc:
                errors.append(f"{ref_label}.path: {exc}")
            lines = ref["lines"]
            if (not isinstance(lines, list) or len(lines) != 2
                    or any(not isinstance(n, int) or isinstance(n, bool) for n in lines)
                    or lines[0] < 1 or lines[1] < lines[0]):
                errors.append(f"{ref_label}.lines: expected [first, last] positive inclusive lines")


def _aggregation(aggregation: Any, items: Any, errors: list[str]) -> None:
    if not isinstance(aggregation, dict):
        errors.append("aggregation: expected an object")
        return
    if set(aggregation) != {"kind", "pass_threshold", "reward_kind"}:
        errors.append("aggregation: require exactly kind, pass_threshold, reward_kind")
    if not isinstance(aggregation.get("kind"), str) or aggregation.get("kind") not in {"all", "weighted_mean", "sum"}:
        errors.append("aggregation.kind: expected all, weighted_mean or sum")
    if not isinstance(aggregation.get("reward_kind"), str) or aggregation.get("reward_kind") not in {"binary", "aggregate"}:
        errors.append("aggregation.reward_kind: expected binary or aggregate")
    if not _number(aggregation.get("pass_threshold")):
        errors.append("aggregation.pass_threshold: expected a finite number, not bool")
    if aggregation.get("kind") == "all" and aggregation.get("pass_threshold") != 1:
        errors.append("aggregation.pass_threshold: all requires 1 (original per-item thresholds apply)")
    if aggregation.get("kind") == "weighted_mean" and isinstance(items, list):
        weights = [item.get("weight") for item in items if isinstance(item, dict)]
        if weights and all(_number(weight) for weight in weights) and sum(weights) <= 0:
            errors.append("aggregation: weighted_mean requires positive total weight")


def _common(document: dict, errors: list[str], assets: set[str] | None,
            inherited: bool = False) -> None:
    for field in sorted(_COMMON_FIELDS - document.keys()):
        errors.append(f"{field}: required")
    _score_items(document.get("score_items"), errors, assets, inherited)
    _aggregation(document.get("aggregation"), document.get("score_items"), errors)
    interfaces = document.get("required_interfaces")
    if not isinstance(interfaces, list) or any(not isinstance(item, dict) for item in interfaces):
        errors.append("required_interfaces: expected a list of objects")
    if not isinstance(document.get("source_contract"), dict):
        errors.append("source_contract: expected an object")
    rubric = document.get("rubric")
    if rubric is not None and not isinstance(rubric, dict):
        errors.append("rubric: expected null or an object")
    _strings(document.get("ungraded_requirements"), "ungraded_requirements", errors)


def validate_baseline(baseline: Any) -> list[str]:
    """Validate a baseline structurally without reading external source files."""
    errors: list[str] = []
    if not isinstance(baseline, dict):
        return ["baseline: expected an object"]
    _json_check(baseline, "baseline", errors)
    if errors:
        return errors
    if baseline.get("schema_version") != BASELINE_SCHEMA:
        errors.append(f"schema_version: expected {BASELINE_SCHEMA}")
    for field in sorted(baseline.keys() - (_COMMON_FIELDS | {"schema_version", "source"})):
        errors.append(f"{field}: unsupported baseline field")
    source = baseline.get("source")
    paths: set[str] = set()
    if not isinstance(source, dict):
        errors.append("source: expected an object")
    else:
        if set(source) != {"task_id", "revision", "assets"}:
            errors.append("source: require exactly task_id, revision, assets")
        for field in ("task_id", "revision"):
            if not _text(source.get(field)):
                errors.append(f"source.{field}: expected a nonempty string")
        assets = source.get("assets")
        if not isinstance(assets, list) or not assets:
            errors.append("source.assets: expected a nonempty list")
        else:
            for index, asset in enumerate(assets):
                label = f"source.assets[{index}]"
                if not isinstance(asset, dict) or set(asset) != {"path", "role", "sha256"}:
                    errors.append(f"{label}: require exactly path, role, sha256")
                    continue
                try:
                    path = _relative_path(asset["path"])
                    if path in paths:
                        errors.append(f"{label}.path: duplicate asset {path!r}")
                    paths.add(path)
                except ValueError as exc:
                    errors.append(f"{label}.path: {exc}")
                if not _text(asset["role"]):
                    errors.append(f"{label}.role: expected a nonempty string")
                if not isinstance(asset["sha256"], str) or not _SHA256.fullmatch(asset["sha256"]):
                    errors.append(f"{label}.sha256: expected lowercase SHA-256")
    _common(baseline, errors, paths)
    return errors


def _check_source_lines(baseline: dict, data: dict[str, bytes]) -> None:
    for item in baseline["score_items"]:
        for ref in item["source_refs"]:
            try:
                count = len(data[ref["path"]].decode("utf-8").splitlines())
            except UnicodeDecodeError as exc:
                raise ValueError(f"line-referenced asset must be UTF-8: {ref['path']}") from exc
            if ref["lines"][1] > count:
                raise ValueError(f"source reference exceeds file lines: {ref['path']} {ref['lines']}")


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n",
                    encoding="utf-8")


def freeze_baseline(baseline: dict, source_root: Path, out: Path) -> dict:
    """Snapshot a validated baseline and hash-verified source assets atomically.

    ``out`` must be absent or empty.  Existing frozen records are never
    overwritten; create a separate version instead.
    """
    errors = validate_baseline(baseline)
    if errors:
        raise ValueError("invalid baseline: " + "; ".join(errors))
    baseline = deepcopy(baseline)
    source_root, out = Path(source_root), Path(out)
    if out.is_symlink():
        raise ValueError("freeze output must not be a symlink")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise ValueError("freeze output must be absent or empty; existing baselines are immutable")
    data: dict[str, bytes] = {}
    snapshots = []
    for asset in baseline["source"]["assets"]:
        content = _file_under(source_root, asset["path"]).read_bytes()
        digest = hashlib.sha256(content).hexdigest()
        if digest != asset["sha256"]:
            raise ValueError(f"source asset SHA-256 mismatch: {asset['path']}")
        data[asset["path"]] = content
        snapshots.append({**asset, "snapshot_path": "source-assets/" + asset["path"]})
    _check_source_lines(baseline, data)
    receipt = {"schema_version": RECEIPT_SCHEMA, "baseline_sha256": baseline_hash(baseline),
               "assets": snapshots}
    out.parent.mkdir(parents=True, exist_ok=True)
    staging = Path(tempfile.mkdtemp(prefix=".acceptance-freeze-", dir=out.parent))
    try:
        for snapshot in snapshots:
            target = staging / snapshot["snapshot_path"]
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data[snapshot["path"]])
        _write_json(staging / "baseline.json", baseline)
        _write_json(staging / "freeze-receipt.json", receipt)
        verify_frozen_baseline(staging)
        if out.exists():
            out.rmdir()  # Fails if another writer filled the initially empty output.
        os.replace(staging, out)
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return receipt


def _read_json(path: Path) -> Any:
    def pairs(entries):
        result = {}
        for key, value in entries:
            if key in result:
                raise ValueError(f"duplicate JSON key in {path.name}: {key}")
            result[key] = value
        return result
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=pairs,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(f"invalid JSON constant: {value}")))


def verify_frozen_baseline(out: Path) -> dict:
    """Verify the frozen baseline, receipt and every snapshot; return baseline."""
    out = Path(out)
    if out.is_symlink():
        raise ValueError("frozen output must not be a symlink")
    baseline = _read_json(_file_under(out, "baseline.json"))
    receipt = _read_json(_file_under(out, "freeze-receipt.json"))
    errors = validate_baseline(baseline)
    if errors:
        raise ValueError("invalid frozen baseline: " + "; ".join(errors))
    expected = {"schema_version": RECEIPT_SCHEMA, "baseline_sha256": baseline_hash(baseline),
                "assets": [{**asset, "snapshot_path": "source-assets/" + asset["path"]}
                           for asset in baseline["source"]["assets"]]}
    if not _same(receipt, expected):
        raise ValueError("freeze receipt does not match baseline or asset declarations")
    data: dict[str, bytes] = {}
    for asset in receipt["assets"]:
        content = _file_under(out, asset["snapshot_path"]).read_bytes()
        if hashlib.sha256(content).hexdigest() != asset["sha256"]:
            raise ValueError(f"frozen source asset SHA-256 mismatch: {asset['path']}")
        data[asset["path"]] = content
    _check_source_lines(baseline, data)
    return baseline


def validate_inheritance(contract: Any, baseline: dict) -> list[str]:
    """Reject grading expansion, threshold/tolerance changes and silent overrides."""
    errors = validate_baseline(baseline)
    if errors:
        return ["baseline: " + error for error in errors]
    if not isinstance(contract, dict):
        return ["contract: expected an object"]
    _json_check(contract, "contract", errors)
    if errors:
        return errors
    if contract.get("schema_version") != INHERITANCE_SCHEMA:
        errors.append(f"schema_version: expected {INHERITANCE_SCHEMA}")
    if contract.get("baseline_sha256") != baseline_hash(baseline):
        errors.append("baseline_sha256: does not match original frozen acceptance baseline")
    for field in sorted(contract.keys() - (_COMMON_FIELDS | {"schema_version", "baseline_sha256", "source"})):
        errors.append(f"{field}: unsupported inheritance field; acceptance exceptions are not supported")
    if "source" in contract and not _same(contract["source"], baseline["source"]):
        errors.append("source: original provenance must not change")
    assets = {asset["path"] for asset in baseline["source"]["assets"]}
    _common(contract, errors, assets, inherited=True)
    for field in sorted(_COMMON_FIELDS - {"score_items"}):
        if field in contract and not _same(contract[field], baseline[field]):
            errors.append(f"{field}: must preserve original acceptance rules; no automatic tightening or expansion")
    originals = {item["id"]: item for item in baseline["score_items"]}
    items = contract.get("score_items")
    if isinstance(items, list) and all(isinstance(item, dict) for item in items):
        ids = {item.get("id") for item in items if isinstance(item.get("id"), str)}
        if ids != set(originals) or len(items) != len(originals):
            errors.append("score_items: must correspond one-to-one to original items; no additions or omissions")
        for item in items:
            original = originals.get(item.get("id")) if isinstance(item.get("id"), str) else None
            if original is None:
                continue
            for field in sorted(_ITEM_FIELDS):
                if field in item and not _same(item[field], original[field]):
                    errors.append(f"score_items.{item['id']}.{field}: original rule must remain unchanged")
    return errors


def aggregate_scores(scores: dict[str, float], contract: dict) -> dict:
    """Apply the contract's explicit original aggregation to complete raw scores.

    Call ``validate_inheritance`` against the frozen baseline before using this
    function.  ``all`` returns aggregate 0/1 for the original item thresholds;
    aggregate modes keep partial credit even when the overall threshold fails.
    """
    if not isinstance(contract, dict):
        raise ValueError("contract must be an object")
    errors: list[str] = []
    _json_check(contract, "contract", errors)
    if contract.get("schema_version") != INHERITANCE_SCHEMA:
        errors.append(f"schema_version: expected {INHERITANCE_SCHEMA}")
    if not isinstance(contract.get("baseline_sha256"), str) or not _SHA256.fullmatch(contract["baseline_sha256"]):
        errors.append("baseline_sha256: expected lowercase SHA-256")
    if not errors:
        _score_items(contract.get("score_items"), errors, inherited=True)
        _aggregation(contract.get("aggregation"), contract.get("score_items"), errors)
    if errors:
        raise ValueError("invalid scoring contract: " + "; ".join(errors))
    if not isinstance(scores, dict):
        raise ValueError("scores must be an object keyed by score item id")
    items = contract["score_items"]
    if set(scores) != {item["id"] for item in items}:
        raise ValueError("scores must contain exactly all original items; unknown or missing items")
    for item in items:
        value = scores[item["id"]]
        if not _number(value) or not item["min_score"] <= value <= item["max_score"]:
            raise ValueError(f"score {item['id']!r} must be finite and within original score range")
    rule = contract["aggregation"]
    try:
        if rule["kind"] == "all":
            aggregate = float(all(scores[item["id"]] >= item["pass_threshold"] for item in items))
        elif rule["kind"] == "sum":
            aggregate = math.fsum(scores[item["id"]] for item in items)
        else:
            # Scale before multiplication so finite original weights cannot
            # overflow an otherwise representable weighted mean.
            scale = max(item["weight"] for item in items)
            total = math.fsum(item["weight"] / scale for item in items)
            aggregate = math.fsum(scores[item["id"]] * (item["weight"] / scale / total)
                                  for item in items)
    except (OverflowError, ValueError) as exc:
        raise ValueError("original aggregation cannot be represented as a finite number") from exc
    if not math.isfinite(aggregate):
        raise ValueError("original aggregation must produce a finite number")
    passed = aggregate >= rule["pass_threshold"]
    reward = float(passed) if rule["reward_kind"] == "binary" else aggregate
    return {"reward": reward, "passed": passed, "aggregate": aggregate}
