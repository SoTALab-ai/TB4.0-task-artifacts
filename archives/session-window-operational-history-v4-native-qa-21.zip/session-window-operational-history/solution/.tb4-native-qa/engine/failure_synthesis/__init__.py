"""Failure-driven TB4 authoring with explicit reasoning skeletons."""
