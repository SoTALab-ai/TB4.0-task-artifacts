"""Private native QA entry; imports only the pure scoring/runtime closure."""
import hashlib
import json
from pathlib import Path
import stat

from .execution import native_container_facts, native_container_boundary, safe_relative
from .qa_runtime import read_json, write_json, finish_case_batch
from .quality import bind_case_review
from .validation import canonical_sha256

PURPOSE = "native_qa_only"
LOG = "/logs/artifacts/tb4-native-qa"


def _tree(root):
    root = Path(root)
    _need(root.is_dir() and not root.is_symlink(), "QA bundle root must be regular")
    rows = []
    for path in sorted(root.rglob("*")):
        _need(not path.is_symlink() and (path.is_dir() or path.is_file()), "QA bundle contains links/special files")
        if path.is_file():
            _need(path.stat().st_size <= 64 * 1024 * 1024, "QA member exceeds byte bound")
            rows.append({"path": safe_relative(path.relative_to(root).as_posix()), "sha256": _sha(path),
                         "bytes": path.stat().st_size, "mode": stat.S_IMODE(path.stat().st_mode)})
    _need(len(rows) <= 8192 and sum(r["bytes"] for r in rows) <= 256 * 1024 * 1024, "QA bundle exceeds byte/count bounds")
    return rows

def _need(value, message):
    if not value:
        raise ValueError(message)


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _new(path, data):
    path = Path(path)
    _need(not any(p.is_symlink() for p in [path, *path.parents]), "QA output contains a symlink")
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)


def _json(path, value):
    _new(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode())


def run_native_qa_bundle(bundle, expected_hash, *, log_root=LOG):
    """Oracle-only entry: observe facts before fail-closed boundary checking."""
    from .qa_runtime import execute_case_batch
    bundle, log = Path(bundle), Path(log_root)
    facts = native_container_facts()
    _json(log / "boundary.json", facts)
    rows = read_json(bundle / "manifest.json")
    _need(canonical_sha256(rows) == expected_hash, "QA bundle manifest changed")
    actual = [r for r in _tree(bundle) if r["path"] not in {"manifest.json", "run.py"}]
    _need(actual == rows, "QA bundle original bytes changed")
    inputs = read_json(bundle / "inputs.json")
    _need(inputs["purpose"] == PURPOSE and inputs["network_mode"] == "no-network", "QA purpose/network changed")
    receipt = {"schema_version": "tb4.native-qa-receipt/v1", "purpose": PURPOSE,
               "binding": inputs["binding"], "bundle_sha256": expected_hash,
               "input_sha256": canonical_sha256(inputs), "boundary_facts": facts,
               "business_score": None, "model_trial_certified": False}
    if not native_container_boundary(facts):
        receipt.update(status="not_executed", reason="Linux/root/actual container marker required")
        _json(log / "receipt.json", receipt)
        return receipt
    # The unprivileged scorer workers must not read future controls or private
    # expectations. Packaging audiences alone do not isolate processes here.
    bundle.chmod(0o700)
    for path in bundle.rglob("*"):
        path.chmod(0o700 if path.is_dir() else 0o600)
    work = bundle / "work"
    records = execute_case_batch(work, inputs["baseline"], inputs["verifier"], inputs["manifest"],
                                 inputs["cases"], inputs["case_review"], candidate_root=bundle / "candidate",
                                 receipt_out=work, backend="native_container", timeout=inputs["timeout"])
    trusted = bind_case_review(inputs["cases"], inputs["case_review"], inputs["baseline"], inputs["case_freeze"])
    summary = finish_case_batch(records, trusted, {r["id"]: r for r in inputs["case_review"]["checks"]})
    write_json(work / "qa/results.json", {"schema_version": "tb4.qa-report/v1", "records": records,
                                         "summary": summary, "formal_acceptance_is_independent": True})
    result = (work / "qa/results.json").read_bytes()
    _new(log / "qa-results.json", result)
    receipt.update(status="completed", case_ids=[r["case_id"] for r in records],
                   qa_results_sha256=hashlib.sha256(result).hexdigest())
    _json(log / "receipt.json", receipt)
    return receipt

