"""Frozen, independently reviewed adversarial cases for inherited scoring.

This module writes data and compares already supplied scores. It never runs a
generated verifier, submission, or review. Audit results are diagnostic only;
they do not alter the inherited formal scoring contract.
"""

from __future__ import annotations

import copy
import hashlib
import json
import math
import operator
import re
import tempfile
from collections import Counter
from pathlib import Path
from typing import Any

from .validation import canonical_sha256


CASE_SCHEMA = "tb4.adversarial-cases/v1"
CASE_REVIEW_SCHEMA = "tb4.case-review/v1"
REVIEW_SCHEMA = "tb4.independent-review/v1"
CASE_KINDS = {"legal", "violation", "equivalent", "boundary"}
REVIEW_STATUSES = {"valid", "invalid", "uncertain"}
COMPARISONS = {
    "eq": operator.eq, "lt": operator.lt, "le": operator.le,
    "ge": operator.ge, "gt": operator.gt,
}
EXECUTED = "executed"
EXECUTION_STATUSES = {
    EXECUTED, "not_executed", "timeout", "execution_error", "protocol_error",
}
PRIVATE_AUTHOR_ROLES = {"verifier", "reference_solution", "control", "private_author"}


def _object(value: Any, label: str, errors: list[str]) -> dict:
    if not isinstance(value, dict):
        errors.append(f"{label}: expected an object")
        return {}
    return value


def _text(value: Any) -> bool:
    return isinstance(value, str) and bool(value.strip())


def _finite(value: Any) -> bool:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _hash(value: Any) -> bool:
    return isinstance(value, str) and re.fullmatch(r"[a-f0-9]{64}", value) is not None


def _enum(value: Any, choices: Any) -> bool:
    return isinstance(value, str) and value in choices


def _path(value: Any) -> bool:
    return (
        _text(value) and not value.startswith("/") and "\\" not in value
        and ":" not in value
        and not any(ord(c) < 32 or ord(c) == 127 for c in value)
        and all(part not in {"", ".", ".."} for part in value.split("/"))
    )


def _refs(value: Any, label: str, errors: list[str], *, nonempty: bool = False,
          known_paths: set[str] | None = None) -> None:
    if not isinstance(value, list):
        errors.append(f"{label}: expected a list of source references")
        return
    if nonempty and not value:
        errors.append(f"{label}: evidence references are required for a valid review")
    for index, ref in enumerate(value):
        item_label = f"{label}[{index}]"
        ref = _object(ref, item_label, errors)
        path = ref.get("path")
        if not _path(path):
            errors.append(f"{item_label}.path: expected a canonical relative POSIX path")
        elif known_paths is not None and path not in known_paths:
            errors.append(f"{item_label}.path: unknown source path {path!r}")
        lines = ref.get("lines")
        if (
            not isinstance(lines, list) or len(lines) != 2
            or any(isinstance(n, bool) or not isinstance(n, int) for n in lines)
            or lines[0] < 1 or lines[1] < lines[0]
        ):
            errors.append(f"{item_label}.lines: expected [positive_start, end >= start]")


def _score_items(contract: dict) -> dict[str, dict]:
    items = contract.get("score_items", [])
    if not isinstance(items, list):
        return {}
    return {item["id"]: item for item in items
            if isinstance(item, dict) and _text(item.get("id"))}


def _manifest_sha256(manifest: dict) -> str:
    # The optional transport field is not part of the frozen manifest itself.
    return canonical_sha256({k: v for k, v in manifest.items()
                             if k != "candidate_sha256"})


def _case_sha256(case: dict) -> str:
    return canonical_sha256({k: v for k, v in case.items()
                             if k != "_trusted_review"})


def validate_cases(response: Any, contract: Any, candidate_manifest: Any) -> list[str]:
    """Validate case data and expectations without trusting self-attestation.

    Empty case lists are allowed and mean the adversarial audit is untested.
    Comparators are explicit score predicates, never an implicit requirement
    that a violation must fail the entire task or that a legal answer be full
    score on every item.
    """
    errors: list[str] = []
    response = _object(response, "response", errors)
    contract = _object(contract, "contract", errors)
    manifest = _object(candidate_manifest, "candidate_manifest", errors)
    if response.get("schema_version") != CASE_SCHEMA:
        errors.append(f"response.schema_version: expected {CASE_SCHEMA}")
    baseline_hash = contract.get("baseline_sha256")
    if not _hash(baseline_hash) or response.get("baseline_sha256") != baseline_hash:
        errors.append("response.baseline_sha256: stale or incorrect baseline binding")
    try:
        candidate_hash = _manifest_sha256(manifest)
    except (TypeError, ValueError):
        candidate_hash = None
        errors.append("candidate_manifest: cannot compute canonical hash")
    if manifest.get("schema_version") != "tb4.workflow-candidate-manifest/v1":
        errors.append("candidate_manifest.schema_version: expected tb4.workflow-candidate-manifest/v1")
    if manifest.get("baseline_sha256") != baseline_hash:
        errors.append("candidate_manifest.baseline_sha256: must match the contract")
    if "candidate_sha256" in manifest and manifest["candidate_sha256"] != candidate_hash:
        errors.append("candidate_manifest.candidate_sha256: incorrect transport hash")
    if response.get("candidate_sha256") != candidate_hash or candidate_hash is None:
        errors.append("response.candidate_sha256: stale or incorrect candidate binding")
    score_items = _score_items(contract)
    known_paths = {ref.get("path") for item in score_items.values()
                   for ref in item.get("source_refs", []) if isinstance(ref, dict)}
    manifest_files = manifest.get("files", [])
    if not isinstance(manifest_files, list):
        errors.append("candidate_manifest.files: expected a list")
        manifest_files = []
    known_paths.update(item.get("path") for item in manifest_files if isinstance(item, dict))
    private_author_paths = {
        item["path"] for item in manifest_files
        if isinstance(item, dict) and _path(item.get("path"))
        and (_enum(item.get("role"), PRIVATE_AUTHOR_ROLES)
             or item["path"].startswith("private/"))
    }
    cases = response.get("cases")
    if not isinstance(cases, list):
        errors.append("response.cases: expected a list (may be empty)")
        return errors
    ids: set[str] = set()
    parsed: list[dict] = []
    for index, raw_case in enumerate(cases):
        label = f"cases[{index}]"
        case = _object(raw_case, label, errors)
        parsed.append(case)
        ident = case.get("id")
        if not isinstance(ident, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,79}", ident):
            errors.append(f"{label}.id: expected a safe case identifier")
        elif ident in ids:
            errors.append(f"{label}.id: duplicate case id {ident!r}")
        else:
            ids.add(ident)
        if "_trusted_review" in case:
            errors.append(f"{label}: authors cannot supply _trusted_review")
        if "command" in case:
            errors.append(f"{label}: a case cannot declare an execution command")
        if not _enum(case.get("kind"), CASE_KINDS):
            errors.append(f"{label}.kind: unsupported case kind")
        if not _text(case.get("reason")):
            errors.append(f"{label}.reason: expected a nonempty reason")
        _refs(case.get("source_refs"), f"{label}.source_refs", errors, known_paths=known_paths)
        targets = case.get("target_score_ids")
        if not isinstance(targets, list) or any(not _text(t) for t in targets):
            errors.append(f"{label}.target_score_ids: expected a list of score ids")
            targets = []
        elif len(set(targets)) != len(targets):
            errors.append(f"{label}.target_score_ids: duplicate ids")
        for score_id in targets:
            if score_id not in score_items:
                errors.append(f"{label}.target_score_ids: unknown score {score_id!r}")
        expectation = _object(case.get("expectation"), f"{label}.expectation", errors)
        expected_scores = _object(expectation.get("scores"), f"{label}.expectation.scores", errors)
        if expectation.get("passed") is not None and not isinstance(expectation.get("passed"), bool):
            errors.append(f"{label}.expectation.passed: expected a boolean or null")
        for score_id, predicate in expected_scores.items():
            if score_id not in score_items:
                errors.append(f"{label}.expectation.scores: unknown score {score_id!r}")
            predicate = _object(predicate, f"{label}.expectation.scores.{score_id}", errors)
            if not _enum(predicate.get("op"), COMPARISONS):
                errors.append(f"{label}.expectation.scores.{score_id}.op: unsupported comparator")
            if not _finite(predicate.get("value")):
                errors.append(f"{label}.expectation.scores.{score_id}.value: expected a finite number")
        for score_id in targets:
            if score_id not in expected_scores:
                errors.append(f"{label}.expectation.scores: missing target predicate {score_id!r}")
        validity = _object(case.get("validity"), f"{label}.validity", errors)
        if not _enum(validity.get("status"), {"validated", "unverified"}):
            errors.append(f"{label}.validity.status: expected validated or unverified")
        if not _text(validity.get("basis")):
            errors.append(f"{label}.validity.basis: expected a nonempty statement (not a trusted review)")
        _refs(validity.get("evidence_refs"), f"{label}.validity.evidence_refs", errors)
        files = case.get("files")
        if not isinstance(files, list):
            errors.append(f"{label}.files: expected a list of submission data files")
            files = []
        paths: set[str] = set()
        for file_index, raw_file in enumerate(files):
            file_label = f"{label}.files[{file_index}]"
            file = _object(raw_file, file_label, errors)
            path = file.get("path")
            if not _path(path):
                errors.append(f"{file_label}.path: expected a canonical relative POSIX path")
            else:
                if path in paths:
                    errors.append(f"{file_label}.path: duplicate submission path")
                paths.add(path)
                if any(path == asset or path.startswith(asset + "/")
                       or asset.startswith(path + "/") for asset in private_author_paths):
                    errors.append(f"{file_label}.path: submission collides with a private author asset")
            if _enum(file.get("role"), PRIVATE_AUTHOR_ROLES):
                errors.append(f"{file_label}.role: a submission cannot declare a private author asset")
            if not isinstance(file.get("content"), str):
                errors.append(f"{file_label}.content: expected text content")
            if any(k in file for k in ("symlink", "symlink_target", "link_target", "command")):
                errors.append(f"{file_label}: executable or symlink directives are not accepted")
        for path in paths:
            if any(other.startswith(path + "/") for other in paths if other != path):
                errors.append(f"{label}.files: file/directory collision at {path!r}")
    for case in parsed:
        control = case.get("control_id")
        if control is not None and (not isinstance(control, str) or control not in ids or control == case.get("id")):
            errors.append(f"case {case.get('id')!r}.control_id: expected another known case id or null")
    try:
        canonical_sha256(response)
    except (TypeError, ValueError):
        errors.append("response: must be finite JSON data")
    return errors


def _read_bound_file(root: Path, relative: str) -> bytes:
    if not _path(relative):
        raise ValueError(f"unsafe manifest path: {relative!r}")
    current = root
    for part in relative.split("/"):
        current = current / part
        if current.is_symlink():
            raise ValueError(f"symlink in candidate path: {relative!r}")
    if not current.is_file():
        raise ValueError(f"missing candidate file: {relative!r}")
    return current.read_bytes()


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def freeze_cases(response: dict, contract: dict, candidate_root: str | Path,
                 out: str | Path, *, candidate_manifest: dict | None = None) -> dict:
    """Freeze predictions and data before execution, returning their hashes.

    ``out`` is an audit directory outside the formal candidate. Its case files
    are always written to ``qa/cases/<id>/submission``. An existing freeze is
    never overwritten, and author-declared validity does not certify a case.
    """
    candidate_root, out = Path(candidate_root), Path(out)
    if candidate_root.is_symlink() or out.is_symlink():
        raise ValueError("candidate_root and out must not be symlinks")
    root_resolved, out_resolved = candidate_root.resolve(), out.resolve()
    if out_resolved == root_resolved or root_resolved in out_resolved.parents:
        raise ValueError("case audit output must be outside the formal candidate")
    if candidate_manifest is None:
        candidate_manifest = json.loads(_read_bound_file(candidate_root, "candidate-manifest.json"))
    errors = validate_cases(response, contract, candidate_manifest)
    if errors:
        raise ValueError("invalid case response: " + "; ".join(errors))
    for file in candidate_manifest.get("files", []):
        if not isinstance(file, dict):
            raise ValueError("invalid candidate manifest file record")
        data = _read_bound_file(candidate_root, file.get("path"))
        if hashlib.sha256(data).hexdigest() != file.get("sha256") or len(data) != file.get("bytes"):
            raise ValueError(f"candidate file differs from its manifest: {file.get('path')!r}")
    out.mkdir(parents=True, exist_ok=True)
    qa = out / "qa"
    if qa.is_symlink():
        raise ValueError("qa output must not be a symlink")
    qa.mkdir(exist_ok=True)
    destinations = [qa / "cases", qa / "case-response.json", qa / "case-receipt.json"]
    if any(p.exists() or p.is_symlink() for p in destinations):
        raise ValueError("a frozen case response already exists at this output")
    receipt = {
        "schema_version": "tb4.case-freeze-receipt/v1",
        "baseline_sha256": response["baseline_sha256"],
        "candidate_sha256": response["candidate_sha256"],
        "case_response_sha256": canonical_sha256(response),
        "state": "cases_frozen_unreviewed",
        "cases": {},
    }
    with tempfile.TemporaryDirectory(prefix="case-freeze-", dir=qa) as temporary:
        staging = Path(temporary)
        (staging / "cases").mkdir()
        for case in response["cases"]:
            submission = staging / "cases" / case["id"] / "submission"
            submission.mkdir(parents=True)
            file_hashes = []
            for file in case["files"]:
                target = submission / file["path"]
                target.parent.mkdir(parents=True, exist_ok=True)
                data = file["content"].encode("utf-8")
                target.write_bytes(data)
                file_hashes.append({"path": file["path"], "sha256": hashlib.sha256(data).hexdigest(), "bytes": len(data)})
            receipt["cases"][case["id"]] = {
                "case_sha256": _case_sha256(case),
                "submission_path": f"qa/cases/{case['id']}/submission",
                "files": file_hashes,
                "review_status": "unreviewed",
            }
        _write_json(staging / "case-response.json", response)
        _write_json(staging / "case-receipt.json", receipt)
        for destination in destinations:
            (staging / destination.name).rename(destination)
    return receipt


def _review_errors(review: Any, expected_bindings: dict, schema: str,
                   required_checks: set[str], *, allow_empty: bool) -> tuple[list[str], dict[str, dict]]:
    errors: list[str] = []
    review = _object(review, "review", errors)
    if review.get("schema_version") != schema:
        errors.append(f"review.schema_version: expected {schema}")
    bindings = _object(review.get("bindings"), "review.bindings", errors)
    if set(bindings) != set(expected_bindings):
        errors.append("review.bindings: must contain exactly the expected input hashes")
    for key, expected in expected_bindings.items():
        if not _hash(expected) or bindings.get(key) != expected:
            errors.append(f"review.bindings.{key}: stale or incorrect input hash")
    checks = review.get("checks")
    if not isinstance(checks, list):
        errors.append("review.checks: expected a list of independent review checks")
        checks = []
    if not allow_empty and not checks:
        errors.append("review.checks: a total verdict alone is insufficient")
    entries: dict[str, dict] = {}
    for index, raw_check in enumerate(checks):
        label = f"review.checks[{index}]"
        check = _object(raw_check, label, errors)
        ident = check.get("id")
        if not _text(ident):
            errors.append(f"{label}.id: expected a nonempty check id")
        elif ident in entries:
            errors.append(f"{label}.id: duplicate check id")
        else:
            entries[ident] = check
        if not _enum(check.get("status"), REVIEW_STATUSES):
            errors.append(f"{label}.status: expected valid, invalid, or uncertain")
        if not _text(check.get("reason")):
            errors.append(f"{label}.reason: expected an independent review explanation")
        _refs(check.get("evidence_refs"), f"{label}.evidence_refs", errors,
              nonempty=check.get("status") == "valid")
    for ident in required_checks - set(entries):
        errors.append(f"review.checks: missing required independent check {ident!r}")
    return errors, entries


def validate_review(review: Any, expected_bindings: dict,
                    required_checks: tuple[str, ...] | list[str] = ()) -> list[str]:
    """Validate independent quality review evidence and input binding.

    An invalid/uncertain decision is a well-formed review, not a passing gate.
    The caller must inspect individual statuses when deciding a release state.
    """
    errors, _ = _review_errors(review, expected_bindings, REVIEW_SCHEMA,
                               set(required_checks), allow_empty=False)
    return errors


def validate_case_review(review: Any, cases: dict | list[dict], baseline: Any,
                         hashes: dict) -> list[str]:
    """Validate a separate review bound to frozen cases and the old standard."""
    errors: list[str] = []
    response = cases if isinstance(cases, dict) else None
    case_list = response.get("cases", []) if response is not None else cases
    if not isinstance(case_list, list) or any(not isinstance(c, dict) for c in case_list):
        return ["cases: expected a case response or list of case objects"]
    try:
        baseline_hash = baseline if isinstance(baseline, str) else canonical_sha256(baseline)
        response_hash = canonical_sha256(response) if response is not None else hashes.get("case_response_sha256")
        case_hashes = {c["id"]: _case_sha256(c) for c in case_list}
    except (KeyError, TypeError, ValueError):
        return ["cases/baseline: cannot compute immutable JSON bindings"]
    if not _hash(baseline_hash):
        errors.append("baseline: expected baseline JSON or a trusted SHA256")
    if hashes.get("baseline_sha256") != baseline_hash:
        errors.append("hashes.baseline_sha256: stale baseline receipt")
    if hashes.get("case_response_sha256") != response_hash or not _hash(response_hash):
        errors.append("hashes.case_response_sha256: cases differ from the frozen response")
    candidate_hash = hashes.get("candidate_sha256")
    if response is not None and (response.get("candidate_sha256") != candidate_hash or response.get("baseline_sha256") != baseline_hash):
        errors.append("cases: baseline/candidate bindings differ from the freeze receipt")
    receipt_cases = hashes.get("cases", hashes.get("case_sha256s", {}))
    if not isinstance(receipt_cases, dict) or set(receipt_cases) != set(case_hashes):
        errors.append("hashes.cases: must match all frozen case ids")
        receipt_cases = {}
    for ident, digest in case_hashes.items():
        record = receipt_cases.get(ident, {})
        stored = record.get("case_sha256") if isinstance(record, dict) else record
        if stored != digest:
            errors.append(f"hashes.cases.{ident}: stale or incorrect case hash")
    expected = {"baseline_sha256": baseline_hash, "candidate_sha256": candidate_hash,
                "case_response_sha256": response_hash}
    review_errors, entries = _review_errors(review, expected, CASE_REVIEW_SCHEMA,
                                             set(case_hashes), allow_empty=True)
    errors.extend(review_errors)
    if set(entries) != set(case_hashes):
        errors.append("review.checks: must review exactly the frozen case ids")
    for ident, entry in entries.items():
        if entry.get("case_sha256") != case_hashes.get(ident) or not _hash(entry.get("case_sha256")):
            errors.append(f"review.checks.{ident}.case_sha256: stale or incorrect case binding")
    return errors


def bind_case_review(cases: dict | list[dict], review: dict, baseline: Any,
                     hashes: dict) -> list[dict]:
    """Attach trusted statuses only after validating a separate frozen review."""
    errors = validate_case_review(review, cases, baseline, hashes)
    if errors:
        raise ValueError("invalid independent case review: " + "; ".join(errors))
    case_list = cases["cases"] if isinstance(cases, dict) else cases
    entries = {entry["id"]: entry for entry in review["checks"]}
    bound = copy.deepcopy(case_list)
    for case in bound:
        entry = entries[case["id"]]
        case["_trusted_review"] = {
            "status": entry["status"], "case_sha256": entry["case_sha256"],
            "case_response_sha256": hashes["case_response_sha256"],
            "baseline_sha256": hashes["baseline_sha256"],
            "candidate_sha256": hashes["candidate_sha256"],
        }
    return bound


def compare_case(case: dict, result: Any, execution_status: str,
                 contract: dict) -> dict:
    """Compare score predicates, retaining runtime errors as separate outcomes.

    Root orchestration must obtain ``_trusted_review`` through bind_case_review.
    Violation detection depends on its target score predicates. A target match
    with an unrelated item/global mismatch is not successful detection.
    """
    record = {
        "case_id": case.get("id"), "kind": case.get("kind"),
        "execution_status": execution_status, "executed": execution_status == EXECUTED,
        "valid_for_statistics": False, "classification": None,
        "target_detection": None, "score_matches": {}, "errors": [],
        "quality_only": True,
    }
    def finish(classification: str) -> dict:
        record["classification"] = classification
        return record

    trusted = case.get("_trusted_review", {})
    try:
        review_hash_matches = trusted.get("case_sha256") == _case_sha256(case)
    except (AttributeError, TypeError, ValueError):
        review_hash_matches = False
    if (
        not isinstance(trusted, dict) or not review_hash_matches
        or not _hash(trusted.get("case_response_sha256"))
        or trusted.get("baseline_sha256") != contract.get("baseline_sha256")
    ):
        return finish("unverified_case")
    if trusted.get("status") == "invalid":
        return finish("invalid_case")
    if trusted.get("status") != "valid":
        return finish("unverified_case")
    if not _enum(execution_status, EXECUTION_STATUSES):
        record["errors"].append("unknown execution status")
        return finish("protocol_error")
    if execution_status != EXECUTED:
        return finish(execution_status)
    if not isinstance(result, dict) or not isinstance(result.get("scores"), dict):
        record["errors"].append("result.scores must be an object")
        return finish("protocol_error")
    if not isinstance(result.get("passed"), bool):
        record["errors"].append("result.passed must be the independently aggregated boolean")
        return finish("protocol_error")
    items = _score_items(contract)
    scores = result["scores"]
    unknown = set(scores) - set(items)
    if unknown:
        record["errors"].append("unknown score ids: " + ", ".join(sorted(map(str, unknown))))
        return finish("unknown_score")
    missing = set(items) - set(scores)
    if missing:
        record["errors"].append("missing score ids: " + ", ".join(sorted(missing)))
        return finish("protocol_error")
    for ident, value in scores.items():
        item = items[ident]
        if not _finite(value):
            record["errors"].append(f"score {ident!r} is not finite")
        elif not _finite(item.get("min_score")) or not _finite(item.get("max_score")) or not item["min_score"] <= value <= item["max_score"]:
            record["errors"].append(f"score {ident!r} is outside its inherited range")
    if record["errors"]:
        return finish("protocol_error")
    expectation = case.get("expectation", {})
    expected_scores = expectation.get("scores", {})
    targets = case.get("target_score_ids", [])
    if (
        not isinstance(expected_scores, dict) or not isinstance(targets, list)
        or any(not _text(target) or target not in expected_scores or target not in items for target in targets)
    ):
        record["errors"].append("invalid target expectations")
        return finish("protocol_error")
    for ident, predicate in expected_scores.items():
        if ident not in items:
            record["errors"].append(f"unknown expected score {ident!r}")
            return finish("unknown_score")
        if not isinstance(predicate, dict) or not _enum(predicate.get("op"), COMPARISONS) or not _finite(predicate.get("value")):
            record["errors"].append(f"invalid predicate for score {ident!r}")
            return finish("protocol_error")
        record["score_matches"][ident] = COMPARISONS[predicate["op"]](scores[ident], predicate["value"])
    expected_passed = expectation.get("passed")
    if expected_passed is not None and not isinstance(expected_passed, bool):
        record["errors"].append("expectation.passed must be boolean or null")
        return finish("protocol_error")
    if not expected_scores and expected_passed is None:
        # A well-formed, reviewed case may still carry no testable prediction.
        # Keep it available as authoring evidence without counting a vacuous
        # comparison as a successful audit or introducing a generation gate.
        return finish("no_expectation_evidence")
    record["valid_for_statistics"] = True
    failed = {ident for ident, matched in record["score_matches"].items() if not matched}
    target_failures = failed & set(targets)
    invariant_failures = failed - set(targets)
    pass_matches = expected_passed is None or result["passed"] == expected_passed
    record["passed_matches"] = pass_matches
    record["actual_scores"] = dict(scores)
    record["actual_passed"] = result["passed"]
    if case.get("kind") == "violation":
        if not targets or not case.get("source_refs"):
            return finish("no_target_evidence")
        if invariant_failures:
            return finish("unexpected_score_change")
        if target_failures:
            # Exact expected scores can reveal excess penalty as well as a
            # missed penalty; the former must not count as a false negative.
            overpenalty = any(
                expected_scores[ident]["op"] == "eq"
                and scores[ident] < expected_scores[ident]["value"]
                for ident in target_failures
            )
            if overpenalty:
                return finish("unexpected_score_change")
            record["target_detection"] = False
            return finish("false_negative")
        if not pass_matches:
            return finish("aggregate_mismatch")
        record["target_detection"] = True
        return finish("matched")
    if not pass_matches:
        return finish("false_positive" if expected_passed is True else "aggregate_mismatch")
    if failed:
        undercredit = any(
            scores[ident] < expected_scores[ident]["value"]
            and expected_scores[ident]["op"] in {"eq", "ge", "gt"}
            for ident in failed
        )
        return finish("false_positive" if undercredit else "unexpected_score_change")
    return finish("matched")


def summarize_cases(records: list[dict]) -> dict:
    """Count only independently valid, executed, well-formed comparisons."""
    counts: Counter = Counter()
    excluded: Counter = Counter()
    detection: Counter = Counter()
    for record in records:
        classification = record.get("classification", "protocol_error")
        if record.get("valid_for_statistics") is True and record.get("executed") is True:
            counts[classification] += 1
            if record.get("target_detection") is True:
                detection["detected"] += 1
            elif record.get("target_detection") is False:
                detection["missed"] += 1
        else:
            excluded[classification] += 1
    return {
        "schema_version": "tb4.adversarial-summary/v1",
        "total_records": len(records), "valid_executed_cases": sum(counts.values()),
        "counts": dict(sorted(counts.items())),
        "excluded_counts": dict(sorted(excluded.items())),
        "target_detection_counts": {"detected": detection["detected"], "missed": detection["missed"]},
        "tested": bool(counts), "quality_only": True,
        "formal_scoring_changed": False,
    }
