"""Static validation for failure-derived task authoring contracts.

These checks validate declared structure and bindings. They do not establish
that generated Python is safe or that a historical failure caused a new one.
"""

from __future__ import annotations

import hashlib
import base64
import binascii
import json
import math
import re
from collections import deque
from typing import Any


CHECK_EXPECTATIONS = {
    "gold": "pass",
    "targeted_mutation": "fail",
    "trigger_removed": "pass",
    "equivalent": "pass",
    "integration_mutation": "fail",
    "integration_equivalent": "pass",
}
BASE_CHECK_KINDS = ("gold", "targeted_mutation", "trigger_removed", "equivalent")
PRIVATE_ROLES = {"reference_solution", "verifier", "control"}
FILE_ROLES = PRIVATE_ROLES | {"instruction", "public_material"}


def file_bytes(item: dict) -> bytes:
    """Decode a public binary asset or an ordinary UTF-8 bundle file."""
    content = item.get("content")
    if not isinstance(content, str):
        raise ValueError("file content must be a string")
    encoding = item.get("encoding", "utf-8")
    if encoding == "utf-8":
        return content.encode("utf-8")
    if encoding != "base64" or item.get("role") != "public_material":
        raise ValueError("only public material assets may use base64 encoding")
    media_type = item.get("media_type")
    if not isinstance(media_type, str) or not re.fullmatch(r"[a-z0-9.+-]+/[a-z0-9.+-]+", media_type):
        raise ValueError("binary public assets require an explicit media_type")
    if len(content) > 14 * 1024 * 1024:
        raise ValueError("binary public asset exceeds 10 MiB limit")
    try:
        decoded = base64.b64decode(content, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise ValueError("invalid binary asset base64") from exc
    if not decoded or len(decoded) > 10 * 1024 * 1024:
        raise ValueError("binary public asset is empty or exceeds 10 MiB limit")
    return decoded


def canonical_sha256(obj: Any) -> str:
    """Hash the canonical JSON representation used by all pipeline stages."""
    encoded = json.dumps(
        obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _text(value: Any, label: str, errors: list[str]) -> bool:
    if not isinstance(value, str) or not value.strip():
        errors.append(f"{label}: expected a nonempty string")
        return False
    return True


def _object(value: Any, label: str, errors: list[str]) -> dict:
    if not isinstance(value, dict):
        errors.append(f"{label}: expected an object")
        return {}
    return value


def _strings(value: Any, label: str, errors: list[str], *, nonempty: bool = True, unique: bool = True) -> list[str]:
    if not isinstance(value, list):
        errors.append(f"{label}: expected a list")
        return []
    if nonempty and not value:
        errors.append(f"{label}: must not be empty")
    good = []
    for index, item in enumerate(value):
        if _text(item, f"{label}[{index}]", errors):
            good.append(item)
    if unique and len(set(good)) != len(good):
        errors.append(f"{label}: duplicate values are not allowed")
    return good


def _records(value: Any, label: str, errors: list[str], *, key: str = "id") -> dict[str, dict]:
    if not isinstance(value, list) or not value:
        errors.append(f"{label}: expected a nonempty list of objects")
        return {}
    result = {}
    for index, item in enumerate(value):
        item_label = f"{label}[{index}]"
        if not isinstance(item, dict):
            errors.append(f"{item_label}: expected an object")
            continue
        ident = item.get(key)
        if not _text(ident, f"{item_label}.{key}", errors):
            continue
        if ident in result:
            errors.append(f"{item_label}.{key}: duplicate {ident!r}")
            continue
        result[ident] = item
    return result


def _references(values: list[str], allowed: set[str], label: str, errors: list[str]) -> None:
    for ident in values:
        if ident not in allowed:
            errors.append(f"{label}: unknown reference {ident!r}")


def _safe_path(path: Any, label: str, errors: list[str]) -> bool:
    """Accept only canonical, relative POSIX bundle paths."""
    if not _text(path, label, errors):
        return False
    if (
        path.startswith("/") or "\\" in path or ":" in path
        or any(ord(char) < 32 or ord(char) == 127 for char in path)
        or any(part in {"", ".", ".."} for part in path.split("/"))
    ):
        errors.append(f"{label}: must be a relative POSIX path without traversal or ambiguous components")
        return False
    return True


def validate_skeleton(skeleton: Any, card: Any) -> list[str]:
    """Return all structural, source-binding, and mechanism-coverage errors."""
    errors: list[str] = []
    skeleton = _object(skeleton, "skeleton", errors)
    card = _object(card, "card", errors)
    if skeleton.get("schema_version") != "tb4.skeleton/v1":
        errors.append("skeleton.schema_version: expected tb4.skeleton/v1")
    source = _object(skeleton.get("source"), "skeleton.source", errors)
    for key in ("card_id", "error_key", "mechanism_id"):
        _text(card.get(key), f"card.{key}", errors)
        if not _text(source.get(key), f"skeleton.source.{key}", errors) or source.get(key) != card.get(key):
            errors.append(f"skeleton.source.{key}: must match the source card")
    try:
        expected_hash = canonical_sha256(card)
    except (TypeError, ValueError) as exc:
        errors.append(f"card: cannot compute canonical hash: {exc}")
        expected_hash = None
    if source.get("card_sha256") != expected_hash or expected_hash is None:
        errors.append("skeleton.source.card_sha256: stale or incorrect source card hash")
    if card.get("eligible_for_skeleton") is not True:
        errors.append("card.eligible_for_skeleton: source must be explicitly eligible for new design")
    if skeleton.get("design_status") != "designed_from_reviewed_failure":
        errors.append("skeleton.design_status: expected designed_from_reviewed_failure")
    mechanism = _object(skeleton.get("mechanism"), "skeleton.mechanism", errors)
    for key in ("bottleneck_step", "trigger_description"):
        _text(mechanism.get(key), f"skeleton.mechanism.{key}", errors)
    _strings(mechanism.get("required_invariants"), "skeleton.mechanism.required_invariants", errors)
    policy = _object(skeleton.get("variation_policy"), "skeleton.variation_policy", errors)
    for key in ("preserve", "may_change", "forbidden_shortcuts"):
        _strings(policy.get(key), f"skeleton.variation_policy.{key}", errors)
    contract = _object(skeleton.get("question_contract"), "skeleton.question_contract", errors)
    _text(contract.get("goal"), "skeleton.question_contract.goal", errors)
    _strings(contract.get("deliverables"), "skeleton.question_contract.deliverables", errors)
    if contract.get("input_visibility") != "self-contained":
        errors.append("skeleton.question_contract.input_visibility: expected self-contained")
    _strings(skeleton.get("ambiguity_limits"), "skeleton.ambiguity_limits", errors)
    _strings(skeleton.get("limits"), "skeleton.limits", errors)

    evidence = _records(skeleton.get("evidence_requirements"), "evidence_requirements", errors)
    operations = _records(skeleton.get("operations"), "operations", errors)
    materials = _records(skeleton.get("material_constraints"), "material_constraints", errors)
    traps = _records(skeleton.get("traps"), "traps", errors)
    checks = _records(skeleton.get("verification_plan"), "verification_plan", errors)
    groups = (evidence, operations, materials, traps, checks)
    seen: set[str] = set()
    for group in groups:
        for ident in group:
            if ident in seen:
                errors.append(f"id {ident!r}: ids must be unique across skeleton sections")
            seen.add(ident)
    for ident, item in evidence.items():
        _text(item.get("description"), f"evidence {ident}.description", errors)
        if item.get("visibility") != "public":
            errors.append(f"evidence {ident}.visibility: solving evidence must be public")

    inputs: dict[str, list[str]] = {}
    dependencies: dict[str, set[str]] = {}
    descendants = {ident: set() for ident in operations}
    indegree = {}
    order = {ident: position for position, ident in enumerate(operations)}
    bottlenecks = set()
    for ident, item in operations.items():
        for key in ("description", "output"):
            _text(item.get(key), f"operation {ident}.{key}", errors)
        if not isinstance(item.get("bottleneck"), bool):
            errors.append(f"operation {ident}.bottleneck: expected a boolean")
        elif item["bottleneck"]:
            bottlenecks.add(ident)
        refs = _strings(item.get("inputs"), f"operation {ident}.inputs", errors)
        inputs[ident] = refs
        _references(refs, set(evidence) | set(operations), f"operation {ident}.inputs", errors)
        dependencies[ident] = {ref for ref in refs if ref in operations}
        indegree[ident] = len(dependencies[ident])
        for dependency in dependencies[ident]:
            descendants[dependency].add(ident)
            if order[dependency] >= order[ident]:
                errors.append(f"operation {ident}.inputs: {dependency!r} must be an earlier operation")
    if not bottlenecks:
        errors.append("operations: at least one bottleneck operation is required")
    queue = deque(ident for ident, degree in indegree.items() if degree == 0)
    topological = []
    while queue:
        ident = queue.popleft()
        topological.append(ident)
        for child in descendants[ident]:
            indegree[child] -= 1
            if indegree[child] == 0:
                queue.append(child)
    if len(topological) != len(operations):
        errors.append("operations: dependency DAG contains a cycle")
    reachable_evidence: dict[str, set[str]] = {}
    for ident in topological:
        reachable_evidence[ident] = {ref for ref in inputs[ident] if ref in evidence}
        for dependency in dependencies[ident]:
            reachable_evidence[ident].update(reachable_evidence.get(dependency, set()))
    used_evidence = {ref for refs in inputs.values() for ref in refs if ref in evidence}
    for ident in evidence:
        if ident not in used_evidence:
            errors.append(f"evidence {ident}: no operation uses this solving evidence")

    material_ops: dict[str, set[str]] = {}
    for ident, item in materials.items():
        _text(item.get("description"), f"material constraint {ident}.description", errors)
        evidence_refs = _strings(item.get("evidence_ids"), f"material constraint {ident}.evidence_ids", errors)
        op_refs = _strings(item.get("operation_ids"), f"material constraint {ident}.operation_ids", errors)
        _references(evidence_refs, set(evidence), f"material constraint {ident}.evidence_ids", errors)
        _references(op_refs, set(operations), f"material constraint {ident}.operation_ids", errors)
        material_ops[ident] = set(op_refs)
        if len(topological) == len(operations):
            material_used_evidence = set().union(*(reachable_evidence.get(op, set()) for op in op_refs))
            unused_refs = set(evidence_refs) - material_used_evidence
            if unused_refs:
                errors.append(f"material constraint {ident}: evidence references do not feed its operations: {sorted(unused_refs)!r}")
            for op in op_refs:
                if op in reachable_evidence and not set(evidence_refs) & reachable_evidence[op]:
                    errors.append(f"material constraint {ident}: evidence does not feed operation {op!r}")
    for ident in operations:
        if not any(ident in refs for refs in material_ops.values()):
            errors.append(f"operation {ident}: missing material constraint coverage")

    trap_targets: dict[str, str] = {}
    unconditionally_required = set()
    for ident, item in traps.items():
        target = item.get("targets_operation")
        if not _text(target, f"trap {ident}.targets_operation", errors) or target not in operations:
            errors.append(f"trap {ident}.targets_operation: unknown operation {target!r}")
        else:
            trap_targets[ident] = target
        for key in ("condition", "shortcut", "wrong_outcome"):
            _text(item.get(key), f"trap {ident}.{key}", errors)
        refs = _strings(item.get("material_constraint_ids"), f"trap {ident}.material_constraint_ids", errors)
        _references(refs, set(materials), f"trap {ident}.material_constraint_ids", errors)
        if isinstance(target, str) and target in operations and not any(target in material_ops.get(ref, set()) for ref in refs):
            errors.append(f"trap {ident}: material constraints do not cover its target operation")
        pairing = item.get("trigger_removed_applicability")
        if pairing is not None:
            pairing = _object(pairing, f"trap {ident}.trigger_removed_applicability", errors)
            if ("failure_portfolio_sha256" not in skeleton
                    or pairing.get("status") != "not_applicable_unconditional"
                    or pairing.get("independent_review_required") is not True):
                errors.append(f"trap {ident}: inapplicability requires a task-wide unconditional obligation and independent review")
            _text(pairing.get("reason"), f"trap {ident}.trigger_removed_applicability.reason", errors)
            evidence_refs = _strings(pairing.get("public_rule_evidence_ids"), f"trap {ident}.trigger_removed_applicability.public_rule_evidence_ids", errors)
            _references(evidence_refs, set(evidence), f"trap {ident}.trigger_removed_applicability.public_rule_evidence_ids", errors)
            if ("failure_portfolio_sha256" in skeleton
                    and pairing.get("status") == "not_applicable_unconditional"
                    and pairing.get("independent_review_required") is True
                    and pairing.get("reason") and evidence_refs and set(evidence_refs) <= set(evidence)):
                unconditionally_required.add(ident)

    check_ops: dict[str, set[str]] = {}
    check_traps: dict[str, set[str]] = {}
    for ident, item in checks.items():
        kind = item.get("kind")
        if not isinstance(kind, str) or kind not in CHECK_EXPECTATIONS:
            errors.append(f"check {ident}.kind: unsupported check kind {kind!r}")
        elif item.get("expectation") != CHECK_EXPECTATIONS[kind]:
            errors.append(f"check {ident}.expectation: {kind} requires {CHECK_EXPECTATIONS[kind]!r}")
        op_refs = _strings(item.get("targets_operations"), f"check {ident}.targets_operations", errors)
        trap_refs = _strings(item.get("trap_ids"), f"check {ident}.trap_ids", errors, nonempty=False)
        _references(op_refs, set(operations), f"check {ident}.targets_operations", errors)
        _references(trap_refs, set(traps), f"check {ident}.trap_ids", errors)
        check_ops[ident] = set(op_refs)
        check_traps[ident] = set(trap_refs)
        for trap in trap_refs:
            if trap in trap_targets and trap_targets[trap] not in op_refs:
                errors.append(f"check {ident}: trap {trap!r} targets an unrelated operation")
        if isinstance(kind, str) and kind in {"targeted_mutation", "trigger_removed"}:
            for op in op_refs:
                if not any(trap_targets.get(trap) == op for trap in trap_refs):
                    errors.append(f"check {ident}: {kind} has no trap for target operation {op!r}")
    for ident in operations:
        if not any(ident in refs for refs in check_ops.values()):
            errors.append(f"operation {ident}: missing verification coverage")
    for op in bottlenecks:
        if not any(target == op for target in trap_targets.values()):
            errors.append(f"bottleneck {op}: missing trap")
        for kind in BASE_CHECK_KINDS:
            if kind == "trigger_removed" and all(trap in unconditionally_required for trap, target in trap_targets.items() if target == op):
                continue
            if not any(item.get("kind") == kind and op in check_ops[ident] for ident, item in checks.items()):
                errors.append(f"bottleneck {op}: missing {kind} control")
    for trap, target in trap_targets.items():
        for kind in ("targeted_mutation", "trigger_removed"):
            if kind == "trigger_removed" and trap in unconditionally_required:
                continue
            if not any(
                item.get("kind") == kind and trap in check_traps[ident] and target in check_ops[ident]
                for ident, item in checks.items()
            ):
                errors.append(f"trap {trap}: missing paired {kind} control")
    from .engineering import validate_engineering_skeleton
    validate_engineering_skeleton(skeleton, errors)
    return errors


def validate_author_response(response: Any, skeleton: Any) -> list[str]:
    """Validate bundle boundaries and exact skeleton-to-author bindings."""
    errors: list[str] = []
    response = _object(response, "response", errors)
    skeleton = _object(skeleton, "skeleton", errors)
    if response.get("schema_version") != "tb4.author-response/v1":
        errors.append("response.schema_version: expected tb4.author-response/v1")
    try:
        expected_hash = canonical_sha256(skeleton)
    except (TypeError, ValueError) as exc:
        errors.append(f"skeleton: cannot compute canonical hash: {exc}")
        expected_hash = None
    if response.get("source_skeleton_sha256") != expected_hash or expected_hash is None:
        errors.append("response.source_skeleton_sha256: stale or incorrect skeleton hash")
    task_id = response.get("task_id")
    if not isinstance(task_id, str) or not re.fullmatch(r"[a-z0-9][a-z0-9-]{0,79}", task_id):
        errors.append("response.task_id: expected a lowercase task id with letters, digits and hyphens")
    _text(response.get("title"), "response.title", errors)
    if response.get("instruction_path") != "instruction.md":
        errors.append("response.instruction_path: expected instruction.md")
    files = _records(response.get("files"), "files", errors, key="path")
    for path, item in files.items():
        _safe_path(path, f"file {path!r}.path", errors)
        role = item.get("role")
        if not isinstance(role, str) or role not in FILE_ROLES:
            errors.append(f"file {path!r}.role: unsupported role {role!r}")
        if not isinstance(item.get("content"), str):
            errors.append(f"file {path!r}.content: expected text content")
        else:
            try:
                file_bytes(item)
            except ValueError as exc:
                errors.append(f"file {path!r}: {exc}")
        if any(key in item for key in ("symlink", "symlink_target", "link_target")):
            errors.append(f"file {path!r}: symlinks are not permitted")
        if role == "instruction" and path != "instruction.md":
            errors.append(f"file {path!r}: instructions must be at instruction.md")
        if role == "public_material" and not path.startswith("environment/"):
            errors.append(f"file {path!r}: public material must be under environment/")
        if isinstance(role, str) and role in PRIVATE_ROLES and not path.startswith("private/"):
            errors.append(f"file {path!r}: private authoring files must be under private/")
    if files.get("instruction.md", {}).get("role") != "instruction":
        errors.append("files: instruction.md with role instruction is required")
    for role in ("public_material", "reference_solution", "verifier", "control"):
        if not any(item.get("role") == role for item in files.values()):
            errors.append(f"files: missing {role} file")
    paths = sorted(files)
    for index, path in enumerate(paths):
        if any(other.startswith(path + "/") for other in paths[index + 1:]):
            errors.append(f"files: file/directory path collision at {path!r}")

    evidence = _records(skeleton.get("evidence_requirements"), "skeleton.evidence_requirements", errors)
    operations = _records(skeleton.get("operations"), "skeleton.operations", errors)
    materials = _records(skeleton.get("material_constraints"), "skeleton.material_constraints", errors)
    traps = _records(skeleton.get("traps"), "skeleton.traps", errors)
    checks = _records(skeleton.get("verification_plan"), "skeleton.verification_plan", errors)
    evidence_bindings = _records(response.get("evidence_bindings"), "evidence_bindings", errors, key="evidence_id")
    _references(list(evidence_bindings), set(evidence), "evidence_bindings", errors)
    for ident in evidence:
        if ident not in evidence_bindings:
            errors.append(f"evidence {ident}: missing material binding")
    for ident, item in evidence_bindings.items():
        bound_paths = _strings(item.get("paths"), f"evidence binding {ident}.paths", errors)
        for path in bound_paths:
            _safe_path(path, f"evidence binding {ident}.path", errors)
            if path not in files:
                errors.append(f"evidence binding {ident}: unknown file {path!r}")
            elif files[path].get("role") != "public_material":
                errors.append(f"evidence binding {ident}: private or non-material file {path!r} cannot be public solving evidence")
    bindings = _records(response.get("check_bindings"), "check_bindings", errors, key="check_id")
    execution = _records(response.get("execution_plan"), "execution_plan", errors, key="check_id")
    for label, entries in (("check_bindings", bindings), ("execution_plan", execution)):
        _references(list(entries), set(checks), label, errors)
        for ident in checks:
            if ident not in entries:
                errors.append(f"check {ident}: missing {label} entry")
    for ident, item in bindings.items():
        op_refs = _strings(item.get("operation_ids"), f"check binding {ident}.operation_ids", errors)
        trap_refs = _strings(item.get("trap_ids"), f"check binding {ident}.trap_ids", errors, nonempty=False)
        material_refs = _strings(item.get("material_constraint_ids"), f"check binding {ident}.material_constraint_ids", errors)
        _references(op_refs, set(operations), f"check binding {ident}.operation_ids", errors)
        _references(trap_refs, set(traps), f"check binding {ident}.trap_ids", errors)
        _references(material_refs, set(materials), f"check binding {ident}.material_constraint_ids", errors)
        if ident in checks:
            plan = checks[ident]
            planned_ops = _strings(plan.get("targets_operations"), f"skeleton check {ident}.targets_operations", errors)
            planned_traps = _strings(plan.get("trap_ids"), f"skeleton check {ident}.trap_ids", errors, nonempty=False)
            if set(op_refs) != set(planned_ops):
                errors.append(f"check binding {ident}: operation targets must equal the skeleton plan")
            if set(trap_refs) != set(planned_traps):
                errors.append(f"check binding {ident}: trap targets must equal the skeleton plan")
        for op in op_refs:
            if not any(op in _strings(materials.get(material, {}).get("operation_ids"), f"material {material}.operation_ids", errors) for material in material_refs):
                errors.append(f"check binding {ident}: material constraints do not cover operation {op!r}")
        for trap in trap_refs:
            trap_materials = _strings(traps.get(trap, {}).get("material_constraint_ids"), f"trap {trap}.material_constraint_ids", errors)
            missing = set(trap_materials) - set(material_refs)
            if missing:
                errors.append(f"check binding {ident}: missing trap material constraints {sorted(missing)!r}")

    for ident, item in execution.items():
        command = _strings(item.get("command"), f"execution {ident}.command", errors, unique=False)
        if len(command) < 2:
            errors.append(f"execution {ident}.command: expected Python interpreter and bundle-local script")
        else:
            if not re.fullmatch(r"python(?:3(?:\.\d+)?)?", command[0]):
                errors.append(f"execution {ident}.command: only a Python interpreter is accepted")
            script = command[1]
            if _safe_path(script, f"execution {ident}.script", errors):
                script_role = files.get(script, {}).get("role")
                if not script.endswith(".py") or not isinstance(script_role, str) or script_role not in PRIVATE_ROLES:
                    errors.append(f"execution {ident}.script: expected a declared private Python script")
            for arg in command[2:]:
                if (
                    arg.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_./=+\-]+", arg)
                    or not _safe_path(arg, f"execution {ident}.argument", errors)
                ):
                    errors.append(f"execution {ident}.argument: only simple relative arguments are accepted: {arg!r}")
        exit_code = item.get("expected_exit_code")
        if isinstance(exit_code, bool) or not isinstance(exit_code, int):
            errors.append(f"execution {ident}.expected_exit_code: expected an integer")
        elif ident in checks:
            expected = 1 if checks[ident].get("expectation") == "fail" else 0
            if exit_code != expected:
                errors.append(f"execution {ident}.expected_exit_code: check kind requires {expected}")
        timeout = item.get("timeout_seconds")
        try:
            finite_timeout = isinstance(timeout, (int, float)) and math.isfinite(timeout)
        except OverflowError:
            finite_timeout = False
        if isinstance(timeout, bool) or not finite_timeout or timeout <= 0:
            errors.append(f"execution {ident}.timeout_seconds: expected a finite positive number")
    _strings(response.get("author_notes"), "response.author_notes", errors, nonempty=False)
    from .engineering import validate_engineering_author
    validate_engineering_author(response, skeleton, files, errors)
    from .trajectory_variants import validate_variant_author
    errors.extend(validate_variant_author(response, skeleton))
    return errors


def validate_check_result(result: Any, plan: Any, returncode: Any) -> list[str]:
    """Require target coverage and restrict failures to the declared mutation.

    ``plan.known_operation_ids`` optionally carries the complete skeleton id
    registry; the runner should provide it to reject unknown additional ids.
    """
    errors: list[str] = []
    result = _object(result, "result", errors)
    plan = _object(plan, "plan", errors)
    if result.get("schema_version") != "tb4.check-result/v1":
        errors.append("result.schema_version: expected tb4.check-result/v1")
    if result.get("check_id") != plan.get("id") or not isinstance(plan.get("id"), str):
        errors.append("result.check_id: must match the planned check id")
    checked = _strings(result.get("checked_operation_ids"), "result.checked_operation_ids", errors)
    failed = _strings(result.get("failed_operation_ids"), "result.failed_operation_ids", errors, nonempty=False)
    targets = _strings(plan.get("targets_operations"), "plan.targets_operations", errors)
    if "known_operation_ids" in plan:
        known = _strings(plan["known_operation_ids"], "plan.known_operation_ids", errors)
        _references(checked, set(known), "result.checked_operation_ids", errors)
        _references(targets, set(known), "plan.targets_operations", errors)
    else:
        for ident in checked:
            if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.:-]*", ident):
                errors.append(f"result.checked_operation_ids: invalid operation identifier {ident!r}")
    _references(failed, set(targets), "result.failed_operation_ids", errors)
    if not set(targets).issubset(checked):
        errors.append("result.checked_operation_ids: must cover all planned operation targets")
    _strings(result.get("details"), "result.details", errors)
    kind = plan.get("kind")
    expected_verdict = CHECK_EXPECTATIONS.get(kind) if isinstance(kind, str) else None
    if expected_verdict is None:
        errors.append(f"plan.kind: unsupported check kind {kind!r}")
    else:
        if plan.get("expectation") != expected_verdict:
            errors.append("plan.expectation: inconsistent with check kind")
        if result.get("verdict") != expected_verdict:
            errors.append(f"result.verdict: {kind} requires {expected_verdict!r}")
        expected_rc = 1 if expected_verdict == "fail" else 0
        if isinstance(returncode, bool) or not isinstance(returncode, int) or returncode != expected_rc:
            errors.append(f"returncode: {kind} requires {expected_rc}; exceptions/timeouts do not count")
        expected_failed = set(targets) if expected_verdict == "fail" else set()
        if set(failed) != expected_failed:
            errors.append("result.failed_operation_ids: must equal planned mutation targets, or be empty for passing controls")
    from .engineering import validate_engineering_result
    validate_engineering_result(result, plan, errors)
    return errors
