"""Run generated scoring code behind an explicit OS/container boundary.

The scorer observes a read-only candidate and submission. Credentials and the
author's source directory are never exposed. This is separate from task reward.
"""

from __future__ import annotations

from datetime import datetime, timezone
import json
import os
import socket
from pathlib import Path
import platform
import re
import shutil
import signal
import subprocess
import sys
import tempfile
import time
import uuid


def safe_relative(path):
    if not isinstance(path, str) or not path or path.startswith("/") or "\\" in path or ":" in path:
        raise ValueError("expected canonical relative POSIX path")
    if any(part in {"", ".", ".."} for part in path.split("/")) or any(ord(c) < 32 for c in path):
        raise ValueError("path traversal or ambiguous path")
    return path


def validate_command(command, files):
    if not isinstance(command, list) or len(command) < 2:
        raise ValueError("scorer command requires a Python interpreter and declared script")
    if not isinstance(command[0], str) or not re.fullmatch(r"python(?:3(?:\.\d+)?)?", command[0]):
        raise ValueError("scorer command must use Python, without shell or inline code")
    script = safe_relative(command[1])
    if script not in files or not script.startswith("private/") or not script.endswith(".py"):
        raise ValueError("scorer script must be a declared private Python asset")
    for arg in command[2:]:
        safe_relative(arg)
        if arg.startswith("-") or not re.fullmatch(r"[A-Za-z0-9_./=+\-]+", arg):
            raise ValueError("scorer arguments must be simple relative values")


def _copy_files(source, destination):
    source = Path(source).resolve()
    for path in source.rglob("*"):
        if path.is_symlink():
            raise ValueError("execution inputs cannot contain symlinks")
        if path.is_file():
            target = destination / path.relative_to(source)
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)


def _mac_profile(code, submission, scratch):
    readable = [Path(sys.executable).resolve().parent.parent, Path(sys.base_prefix).resolve(),
                Path("/System/Library"), Path("/usr/lib"), code, submission, scratch]
    rules = ["(version 1)", "(deny default)", "(allow process-exec)", "(allow process-fork)",
             "(allow signal (target self))", "(allow sysctl-read)", "(allow file-read-metadata)"]
    rules += ["(allow file-read* (subpath " + json.dumps(str(p)) + "))" for p in readable]
    # CPython's executable-path initialization reads the filesystem root
    # directory on macOS. Metadata alone is insufficient and the process
    # aborts before it can report a Python error. A literal root rule grants
    # only that directory; it does not grant contents of /Users or /private.
    rules += ["(allow file-read* (literal \"/\"))",
              "(allow file-read* (literal \"/dev/null\") (literal \"/dev/urandom\") (literal \"/dev/random\"))",
              "(allow file-write* (subpath " + json.dumps(str(scratch)) + "))",
              "(allow file-write* (literal \"/dev/null\"))"]
    return "\n".join(rules)


def _unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate key in scorer JSON receipt")
        result[key] = value
    return result


def native_container_facts():
    """Report observed facts only; markers alone do not certify isolation."""
    return {"sys_platform": sys.platform, "euid": os.geteuid() if hasattr(os, "geteuid") else None,
            "hostname": socket.gethostname(), "observed_at": datetime.now(timezone.utc).isoformat(),
            "python": sys.version.split()[0],
            "container_markers": {name: Path(name).is_file() and not Path(name).is_symlink()
                                  for name in ("/.dockerenv", "/run/.containerenv")}}


def native_container_boundary(facts=None):
    facts = native_container_facts() if facts is None else facts
    return (facts.get("sys_platform") == "linux" and facts.get("euid") == 0
            and any(facts.get("container_markers", {}).values()))


def run_scorer(candidate, submission, command, *, backend="auto", image="python:3.12-slim", timeout=30):
    """Return execution evidence, never interpret a timeout as a wrong answer."""
    candidate, submission = Path(candidate), Path(submission)
    validate_command(command, {str(p.relative_to(candidate)) for p in candidate.rglob("*") if p.is_file()})
    if type(timeout) not in {int, float} or not 0 < timeout <= 300:
        raise ValueError("scorer timeout must be between 0 and 300 seconds")
    if backend == "auto":
        backend = "macos" if platform.system() == "Darwin" and shutil.which("sandbox-exec") else "docker"
    if backend == "native_container" and not native_container_boundary():
        return {"execution_status": "not_executed", "backend": backend,
                "boundary_facts": native_container_facts(),
                "reason": "native QA requires Linux, root and an actual container marker"}
    if backend not in {"macos", "docker", "native_container"}:
        raise ValueError("supported execution boundaries are macos Seatbelt and Docker")
    executable = sys.executable if backend == "native_container" else shutil.which("sandbox-exec" if backend == "macos" else "docker")
    if not executable or (backend == "macos" and platform.system() != "Darwin"):
        return {"execution_status": "not_executed", "backend": backend,
                "reason": "requested isolation runtime is unavailable"}
    env = {"PATH": "/usr/bin:/bin:/usr/sbin:/sbin", "PYTHONDONTWRITEBYTECODE": "1",
           "PYTHONIOENCODING": "utf-8", "LANG": "C.UTF-8"}
    with tempfile.TemporaryDirectory(prefix="tb4-standard-score-") as temporary:
        root = Path(temporary).resolve()
        code, artifacts, scratch = root / "code", root / "submission", root / "scratch"
        for path in (code, artifacts, scratch):
            path.mkdir()
        _copy_files(candidate, code)
        _copy_files(submission, artifacts)
        # A declared submission link makes the scoring adapter the same for
        # Docker and Seatbelt. Its target contains only this copied submission.
        if (code / "submission").exists():
            raise ValueError("candidate must not contain a prefilled submission")
        container_name = None
        if backend == "native_container":
            # The outer native Oracle container is the isolation boundary.
            # The reviewed trusted scorer may drop privileges itself.
            (code / "submission").mkdir()
            _copy_files(artifacts, code / "submission")
            env["TMPDIR"] = str(scratch)
            argv = [str(Path(sys.executable).resolve()), "-E", "-s", "-B", *command[1:]]
        elif backend == "macos":
            (code / "submission").symlink_to(artifacts, target_is_directory=True)
            env["TMPDIR"] = str(scratch)
            argv = [executable, "-p", _mac_profile(code, artifacts, scratch),
                    str(Path(sys.executable).resolve()), "-E", "-s", "-B", *command[1:]]
        else:
            container_name = "tb4-score-" + uuid.uuid4().hex
            (code / "submission").mkdir()
            argv = [executable, "run", "--rm", "--name", container_name, "--network", "none", "--read-only",
                    "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
                    "--user", "65534:65534", "--pids-limit", "64", "--memory", "512m",
                    "--cpus", "1", "--mount", f"type=bind,src={code},dst=/work,readonly",
                    "--mount", f"type=bind,src={artifacts},dst=/work/submission,readonly",
                    "--tmpfs", "/tmp:rw,noexec,nosuid,size=64m", "--workdir", "/work",
                    image, "python3", "-E", "-s", "-B", *command[1:]]
            # tempfile defaults are owner-only; the unprivileged scorer needs
            # traversal and read access to these temporary, non-secret files.
            for base in (root, code, artifacts):
                base.chmod(0o755)
                for path in base.rglob("*"):
                    path.chmod(0o755 if path.is_dir() else 0o644)
        started = time.monotonic()
        try:
            process = subprocess.Popen(argv, cwd=code, env=env, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, text=True, start_new_session=True)
            try:
                stdout, stderr = process.communicate(timeout=timeout)
                status = "executed" if process.returncode == 0 else "execution_error"
            except subprocess.TimeoutExpired:
                os.killpg(process.pid, signal.SIGKILL)
                stdout, stderr = process.communicate()
                status = "timeout"
            result = {"execution_status": status, "backend": backend, "returncode": process.returncode,
                      "seconds": round(time.monotonic() - started, 4), "stdout": stdout[-24000:],
                      "stderr": stderr[-4000:], "result": None}
            if status == "executed":
                try:
                    result["result"] = json.loads(stdout.strip().splitlines()[-1], object_pairs_hook=_unique_object)
                except (ValueError, IndexError):
                    result.update(execution_status="protocol_error", reason="missing final JSON score receipt")
            return result
        except OSError as exc:
            return {"execution_status": "execution_error", "backend": backend,
                    "reason": str(exc), "seconds": round(time.monotonic() - started, 4)}
        finally:
            if container_name:
                try:
                    subprocess.run([executable, "rm", "-f", container_name], env=env,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=10)
                except (OSError, subprocess.TimeoutExpired):
                    pass
