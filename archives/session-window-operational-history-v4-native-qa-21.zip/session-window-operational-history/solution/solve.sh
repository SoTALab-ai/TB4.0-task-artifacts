#!/bin/bash
set -euo pipefail
exec python3 -I -S -B /solution/.tb4-native-qa/run.py
