#!/usr/bin/env python3
"""Harbor submission mapping and original all/binary score adapter."""
from __future__ import annotations
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import shutil
import subprocess
import sys
import tempfile
import time

HERE = Path(__file__).resolve().parent
LOG = Path("/logs/verifier")


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("duplicate JSON key in scorer receipt")
        result[key] = value
    return result


def write(name, data):
    (LOG / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")


def _artifact_source(source, boundary=None, *, directory=False):
    boundary = source.parent if boundary is None else Path(boundary)
    if not source.is_relative_to(boundary):
        raise ValueError("declared artifact is outside the fixed output boundary")
    paths = [source]
    while paths[-1] != boundary:
        paths.append(paths[-1].parent)
    if any(path.is_symlink() for path in paths):
        raise ValueError("declared artifact or its parent is a symlink")
    if source.exists():
        if directory:
            if not source.is_dir():
                raise ValueError("declared directory artifact is not a directory")
            for member in source.rglob("*"):
                if member.is_symlink() or not (member.is_file() or member.is_dir()):
                    raise ValueError("directory artifact contains a symlink or nonregular member")
        elif not source.is_file():
            raise ValueError("declared artifact is not a file")
    return source.exists()


def _artifact_submission_targets(artifacts, mappings):
    """Validate an explicit private mapping without changing source artifacts."""
    if (not isinstance(artifacts, list) or not artifacts or
            any(not isinstance(value, str) for value in artifacts) or len(set(artifacts)) != len(artifacts)):
        raise ValueError("artifact submission mappings require unique declared artifact paths")
    if (not isinstance(mappings, dict) or not mappings or
            any(not isinstance(key, str) or key not in artifacts for key in mappings)):
        raise ValueError("artifact submission mappings require exact declared artifact keys")
    targets = {}
    for original in artifacts:
        canonical = original[:-1] if original.endswith("/") else original
        if (not canonical.startswith("/") or canonical == "/" or "\\" in canonical or any(ord(char) < 32 for char in canonical) or
                PurePosixPath(canonical).as_posix() != canonical or
                any(part in {"", ".", ".."} for part in canonical[1:].split("/"))):
            raise ValueError("artifact submission mapping source must be a canonical declared absolute path")
        target = mappings.get(original, PurePosixPath(original).name)
        if target == ".":
            if not original.endswith("/"):
                raise ValueError("only a declared directory artifact may map to the submission root")
        elif (not isinstance(target, str) or not target or "\\" in target or ":" in target or
                any(ord(char) < 32 for char in target) or
                PurePosixPath(target).is_absolute() or PurePosixPath(target).as_posix() != target or
                any(part in {"", ".", ".."} for part in target.split("/"))):
            raise ValueError("artifact submission target must be a canonical safe relative path")
        path = PurePosixPath(target)
        if any(path.is_relative_to(PurePosixPath(other)) or PurePosixPath(other).is_relative_to(path)
               for other in targets.values()):
            raise ValueError("artifact submission targets collide or overlap")
        targets[original] = target
    return targets

def main():
    LOG.mkdir(parents=True, exist_ok=True)
    reward = LOG / "reward.txt"
    reward.unlink(missing_ok=True)
    config = json.loads((HERE / "adapter-config.json").read_text())
    targets = _artifact_submission_targets(config["artifact_paths"], config["artifact_submission_mappings"])
    candidate = HERE / "scoring"
    expected = config["candidate_files"]
    actual = {}
    for path in candidate.rglob("*"):
        if path.is_symlink():
            raise ValueError("frozen scoring bundle contains symlink")
        if path.is_file():
            actual[path.relative_to(candidate).as_posix()] = digest(path)
    if actual != expected:
        raise ValueError("generated candidate byte hashes differ before scoring")
    started = time.monotonic()
    execution = {"adapter": "app-output-to-submission/v1", "status": "not_executed",
                 "source_candidate_manifest_sha256": config["source_candidate_manifest_sha256"],
                 "command": config["command"], "timeout_seconds": config["timeout_seconds"],
                 "score_aggregation": "original_all_binary", "candidate_hashes_verified": True}
    with tempfile.TemporaryDirectory(prefix="harbor-source-score-") as temporary:
        root = Path(temporary)
        code = root / "code"
        shutil.copytree(candidate, code)
        submission = code / "submission"
        submission.mkdir()
        copied = []
        # Only task-declared artifacts are presented. Missing SQL stays missing
        # so the unchanged scorer handles the business failure predicate.
        for original in config["artifact_paths"]:
            source = Path(original)
            target = targets[original]
            destination = submission if target == "." else submission / target
            directory = original.endswith("/")
            if _artifact_source(source, config["artifact_root"], directory=directory):
                destination.parent.mkdir(parents=True, exist_ok=True)
                if directory:
                    shutil.copytree(source, destination, dirs_exist_ok=(target == "."))
                    members = [{"path": path.relative_to(destination).as_posix(), "sha256": digest(path),
                                "bytes": path.stat().st_size}
                               for path in sorted(destination.rglob("*")) if path.is_file()]
                    copied.append({"source": original, "submission": target, "kind": "directory", "files": members})
                else:
                    with source.open("rb") as handle:
                        destination.write_bytes(handle.read())
                    copied.append({"source": original, "submission": target,
                                   "sha256": digest(destination), "bytes": destination.stat().st_size})
        execution["submission_artifacts"] = copied
        # Current interpreter supplies the same supported direct-Python command;
        # generated script path/arguments are unchanged.
        command = [sys.executable, "-E", "-s", "-B", *config["command"][1:]]
        env = {"PATH": "/usr/local/bin:/usr/bin:/bin", "PYTHONDONTWRITEBYTECODE": "1",
               "PYTHONIOENCODING": "utf-8", "LANG": "C.UTF-8", "TMPDIR": str(root)}
        try:
            completed = subprocess.run(command, cwd=code, env=env,
                                       capture_output=True, text=True,
                                       timeout=config["timeout_seconds"], check=False)
        except subprocess.TimeoutExpired as error:
            execution.update(status="timeout", seconds=round(time.monotonic()-started, 4))
            write("execution.json", execution)
            raise RuntimeError("private scorer timed out; no model reward was assigned") from error
        (LOG / "scorer-stdout.txt").write_text(completed.stdout)
        (LOG / "scorer-stderr.txt").write_text(completed.stderr)
        execution.update(returncode=completed.returncode, seconds=round(time.monotonic()-started, 4))
        if completed.returncode:
            execution["status"] = "execution_error"
            write("execution.json", execution)
            raise RuntimeError("private scorer crashed; no model reward was assigned")
        try:
            result = json.loads(completed.stdout.strip().splitlines()[-1], object_pairs_hook=unique_object)
            if result.get("schema_version") != "tb4.score-result/v1":
                raise ValueError("unsupported scorer result schema")
            scores = result["scores"]
            if not isinstance(scores, dict) or set(scores) != set(config["score_items"]):
                raise ValueError("scorer must emit exactly all original score IDs")
            for ident, limits in config["score_items"].items():
                value = scores[ident]
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value):
                    raise ValueError("score must be a finite number")
                if not limits["min_score"] <= value <= limits["max_score"]:
                    raise ValueError("score exceeds inherited range")
            passed = all(scores[ident] >= limits["pass_threshold"]
                         for ident, limits in config["score_items"].items())
            value = 1 if passed else 0
            if "passed" in result and result["passed"] is not passed:
                raise ValueError("reported passed disagrees with original all aggregation")
            if "reward" in result and (isinstance(result["reward"], bool) or result["reward"] != value):
                raise ValueError("reported reward disagrees with original binary aggregation")
        except (ValueError, KeyError, TypeError, IndexError) as error:
            execution["status"] = "protocol_error"
            write("execution.json", execution)
            raise RuntimeError("invalid private score protocol; no model reward was assigned") from error
        execution.update(status="executed", passed=passed, reward=value)
        write("score-result.json", result)
        write("execution.json", execution)
        reward.write_text(str(value) + "\n")
        print(json.dumps({"reward": value, "passed": passed, "scores": scores}, sort_keys=True))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        LOG.mkdir(parents=True, exist_ok=True)
        (LOG / "reward.txt").unlink(missing_ok=True)
        write("adapter-error.json", {"type": type(error).__name__, "reason": str(error),
                                     "model_reward_assigned": False})
        print("Harbor verifier infrastructure/protocol failure: " + str(error), file=sys.stderr)
        raise SystemExit(2)
