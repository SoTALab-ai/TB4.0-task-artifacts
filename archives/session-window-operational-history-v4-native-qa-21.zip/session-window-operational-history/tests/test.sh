#!/bin/bash
set -euo pipefail
mkdir -p /logs/verifier
python3 -E -s -B /tests/run_workflow_scorer.py
