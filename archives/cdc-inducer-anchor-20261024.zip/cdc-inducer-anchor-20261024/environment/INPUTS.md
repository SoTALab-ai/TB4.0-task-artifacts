# Capture SDK transaction records

Each ingest call carries `source`, `epoch`, `client`, `actor`, `local_time`, and `value`. These SDK records describe transaction activity to be reconciled for finance accounts. The four name fields are nonempty strings; the two numeric fields are signed integers. Repeated identical calls are separate occurrences. A negative value is valid.

`timebases.csv` has `source,epoch,offset`. A producer epoch names one recorded clock basis; each pair has exactly one row. An event's recorded event time is `local_time + offset`. A producer may restart with a different epoch and clock offset. The processor's service clock is independent of both SDK and event time.

`identities.csv` has `client,actor,from_time,to_time,key_hex`. A client-local actor is bound to a finance account identity at the normalized event time: `from_time` is inclusive and `to_time` exclusive; an empty end is unbounded. Different clients have separate actor namespaces. Several client actors can refer to the same account. `key_hex` encodes a byte-string identity; output uses canonical lowercase hex. File order and arrival order are not revision order. Both catalogs are authoritative; the starter does not change their meaning.

A valid occurrence has exactly one time basis and identity interval. Unknown or ambiguous matches raise `ValueError` before any session or source state changes.

A JSONL trace starts with `{ "config": { "gap": ..., "retention": ..., "max_lifetime": ... }, "sources": [...] }`. The remaining lines are arrival-ordered calls:

- `ingest`: the six raw fields above.
- `confirm`: `source` and `event_time`, already in normalized event time.
- `register_source`: `source`.
- `advance_time`: optional `ticks`, default 1.
- `sessions`: optional `key_hex`.
- `evaluate`: optional `session_id` and `watermark`.
- `collect`: optional `watermark`.

`python3 replay.py materials/<trace>.jsonl` logs each actual return and the processor clock/watermark. The logs have no expected-output column; they are operational examples, not an exhaustive specification of legal calls.
