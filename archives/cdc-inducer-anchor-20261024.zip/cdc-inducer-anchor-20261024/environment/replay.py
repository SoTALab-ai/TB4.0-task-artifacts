#!/usr/bin/env python3
"""Execute raw SDK calls and print actual interface returns."""
import json
import sys
from pathlib import Path
from app import SessionProcessor


def replay(path):
    path = Path(path)
    with path.open(encoding="utf-8") as stream:
        header = json.loads(next(stream))
        processor = SessionProcessor(path.parent, **header.get("config", {}))
        for source in header.get("sources", []):
            processor.register_source(source)
        allowed = {"ingest", "confirm", "register_source", "advance_time", "sessions", "evaluate", "collect"}
        for line_number, raw in enumerate(stream, 2):
            if not raw.strip():
                continue
            call = json.loads(raw)
            op = call.pop("op")
            if op not in allowed:
                raise ValueError("Unknown operation: " + op)
            value = processor.ingest(call) if op == "ingest" else getattr(processor, op)(**call)
            print(json.dumps({"line": line_number, "op": op, "return": value,
                              "clock": processor.clock, "watermark": processor.watermark}, ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    if len(sys.argv) != 2:
        raise SystemExit("usage: python3 replay.py materials/trace.jsonl")
    replay(sys.argv[1])
