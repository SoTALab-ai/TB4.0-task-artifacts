"""In-process reconciliation of multi-client capture transaction activity."""
from __future__ import annotations

from .normalization import Normalizer, identity_bytes, integer
from .sessions import SessionIndex
from .watermark import WatermarkTracker
from .emitter import Emitter
from .gc import GarbageCollector


class SessionProcessor:
    def __init__(self, materials_dir, gap=6, retention=12, max_lifetime=80):
        for name, value in (("gap", gap), ("retention", retention), ("max_lifetime", max_lifetime)):
            integer(value, name)
            if value < 0 or (name == "gap" and value == 0):
                raise ValueError(f"{name} must be positive" if name == "gap" else f"{name} must be nonnegative")
        self.normalizer = Normalizer(materials_dir)
        self.index = SessionIndex(gap)
        self.progress = WatermarkTracker()
        self.emitter = Emitter(gap)
        self.gc = GarbageCollector(gap, retention, max_lifetime)

    def register_source(self, source) -> None:
        self.progress.register(source)

    def ingest(self, row) -> None:
        source, key, event_time, value = self.normalizer.resolve(row)
        self.index.insert(key, event_time, value, self.clock)
        self.progress.confirm(source, event_time)

    def confirm(self, source, event_time) -> None:
        self.progress.confirm(source, event_time)

    def advance_time(self, ticks=1) -> None:
        self.progress.advance(ticks)

    @property
    def watermark(self) -> int:
        return self.progress.watermark

    @property
    def clock(self) -> int:
        return self.progress.clock

    def sessions(self, key_hex=None) -> list[dict]:
        key = identity_bytes(key_hex) if key_hex is not None else None
        return self.index.snapshots(key)

    def _cut(self, watermark) -> int:
        return self.watermark if watermark is None else integer(watermark, "watermark")

    def evaluate(self, session_id=None, watermark=None) -> list[dict]:
        cut = self._cut(watermark)
        emissions = []
        for session in self.index.select(session_id):
            emission = self.emitter.evaluate(session, cut)
            if emission is not None:
                emissions.append(emission)
        return emissions

    def collect(self, watermark=None) -> list[str]:
        cut = self._cut(watermark)
        removed = [session.id for session in self.index.select()
                   if self.gc.eligible(session, cut, self.clock)]
        for identifier in removed:
            del self.index.entries[identifier]
        return removed
