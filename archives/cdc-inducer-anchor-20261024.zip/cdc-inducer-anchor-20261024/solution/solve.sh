#!/bin/sh
set -eu
rm -rf /app/app
cp -R /solution/app /app/app
