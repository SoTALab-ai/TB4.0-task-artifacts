"""Load SDK timestamp and client identity tables."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path


def integer(value, name: str) -> int:
    if not isinstance(value, int) or isinstance(value, bool):
        raise ValueError(f"{name} must be an integer")
    return value


def text(value, name: str) -> str:
    if not isinstance(value, str) or not value:
        raise ValueError(f"{name} must be a nonempty string")
    return value


def identity_bytes(key_hex) -> bytes:
    if not isinstance(key_hex, str):
        raise ValueError("key_hex must be a string")
    try:
        return bytes.fromhex(key_hex)
    except ValueError as error:
        raise ValueError("key_hex must encode a byte identity") from error


@dataclass(frozen=True)
class Timebase:
    source: str
    epoch: str
    offset: int


@dataclass(frozen=True)
class Identity:
    client: str
    actor: str
    start: int
    stop: int | None
    key: bytes

    def contains(self, event_time: int) -> bool:
        return self.start <= event_time and (self.stop is None or event_time < self.stop)


class Normalizer:
    def __init__(self, materials_dir):
        directory = Path(materials_dir)
        with (directory / "timebases.csv").open(newline="", encoding="utf-8") as stream:
            self.timebases = tuple(Timebase(row["source"], row["epoch"], int(row["offset"]))
                                   for row in csv.DictReader(stream))
        identities = []
        with (directory / "identities.csv").open(newline="", encoding="utf-8") as stream:
            for row in csv.DictReader(stream):
                start = int(row["from_time"])
                stop = int(row["to_time"]) if row["to_time"].strip() else None
                if stop is not None and stop <= start:
                    raise ValueError("invalid identity interval")
                identities.append(Identity(row["client"], row["actor"], start, stop,
                                           identity_bytes(row["key_hex"])))
        self.identities = tuple(identities)

    def _timebase(self, source: str, epoch: str) -> Timebase:
        rows = [row for row in self.timebases if row.source == source and row.epoch == epoch]
        if len(rows) != 1:
            raise ValueError(f"timestamp lookup has {len(rows)} matches for {(source, epoch)}")
        return rows[0]

    def _identity(self, client: str, actor: str, event_time: int) -> Identity:
        rows = [row for row in self.identities
                if row.client == client and row.actor == actor and row.contains(event_time)]
        if len(rows) != 1:
            raise ValueError(f"identity lookup has {len(rows)} matches for {(client, actor)} at {event_time}")
        return rows[0]

    def resolve(self, row: dict) -> tuple[str, bytes, int, int]:
        if not isinstance(row, dict):
            raise ValueError("input must be a dictionary")
        try:
            source = text(row["source"], "source")
            epoch = text(row["epoch"], "epoch")
            client = text(row["client"], "client")
            actor = text(row["actor"], "actor")
            local_time = integer(row["local_time"], "local_time")
            value = integer(row["value"], "value")
        except KeyError as error:
            raise ValueError(f"missing input field: {error.args[0]}") from error
        timebase = self._timebase(source, epoch)
        event_time = local_time + timebase.offset
        identity = self._identity(client, actor, event_time)
        return source, identity.key, event_time, value
