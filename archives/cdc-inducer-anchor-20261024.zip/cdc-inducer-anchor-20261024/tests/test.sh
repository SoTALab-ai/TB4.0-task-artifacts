#!/bin/sh
set -eu
if [ "$(id -u)" != 0 ]; then
  printf '%s\n' 'Verifier isolation requires root; refusing a same-UID fallback.' >&2
  exit 1
fi
mkdir -p /logs/verifier
chmod 700 /logs/verifier
TASK_TESTS=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
chmod 700 "$TASK_TESTS"
printf '0.0\n' > /logs/verifier/reward.txt
if python3 -I -B "$TASK_TESTS/check.py" --candidate /app --report /logs/verifier/diagnostics.json --isolate; then
  printf '1.0\n' > /logs/verifier/reward.txt
else
  printf '0.0\n' > /logs/verifier/reward.txt
fi
