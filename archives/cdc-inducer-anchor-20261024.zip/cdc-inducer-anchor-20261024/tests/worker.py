"""Return raw candidate observations; all judgment lives in the parent."""
import contextlib
import importlib
import json
import os
import sys

candidate, catalog = sys.argv[1:3]
request = json.load(sys.stdin)
sys.path.insert(0, candidate)
rows = []
# Keep file descriptor 1 on stderr through interpreter exit. This captures
# os.write/C-level and atexit logs as well as ordinary Python prints; only the
# saved descriptor carries the raw observation protocol back to the parent.
protocol_stdout = os.dup(sys.stdout.fileno())
sys.stdout.flush()
os.dup2(sys.stderr.fileno(), sys.stdout.fileno())
with contextlib.redirect_stdout(sys.stderr):
    processor = importlib.import_module("app").SessionProcessor(catalog, **request["config"])
    for source in request.get("sources", []):
        processor.register_source(source)
    for operation in request["operations"]:
        call = dict(operation)
        op = call.pop("op")
        try:
            if op == "_evaluate_key_hex":
                choices = processor.sessions(key_hex=call.pop("key_hex"))
                if len(choices) != 1:
                    raise ValueError("private selection fixture requires one observed session")
                call["session_id"] = choices[0]["id"]
                op = "evaluate"
            returned = processor.ingest(call) if op == "ingest" else getattr(processor, op)(**call)
            error = None
        except Exception as exc:
            returned = None
            error = {"type": type(exc).__name__, "message": str(exc)}
        rows.append({"op": op, "return": returned, "error": error,
                     "clock": processor.clock, "watermark": processor.watermark,
                     "sessions": processor.sessions()})
payload = (json.dumps({"observations": rows}, sort_keys=True) + "\n").encode()
try:
    while payload:
        payload = payload[os.write(protocol_stdout, payload):]
finally:
    os.close(protocol_stdout)
