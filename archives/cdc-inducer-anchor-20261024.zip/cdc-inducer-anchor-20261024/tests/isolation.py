"""Private verifier process boundary; never import candidate code here."""
from __future__ import annotations

import os
from pathlib import Path
import resource
import shutil
import signal
import stat
import subprocess
import tempfile


NOBODY = 65534
OUTPUT_LIMIT = 16 * 1024 * 1024


def drop_privileges():
    """Called in the child before Python can import any submitted package."""
    os.setgroups([])
    os.setgid(NOBODY)
    os.setuid(NOBODY)
    os.umask(0o077)
    # CPU/memory stay at the declared container and existing per-call wall
    # budgets. Do not impose a smaller hidden performance requirement here.
    for kind, maximum in ((resource.RLIMIT_CORE, 0),
                          (resource.RLIMIT_FSIZE, OUTPUT_LIMIT)):
        _, hard = resource.getrlimit(kind)
        cap = maximum if hard == resource.RLIM_INFINITY else min(maximum, hard)
        resource.setrlimit(kind, (cap, cap))


def _copy_tree(source, target, boundary, ancestors=()):
    """Dereference internal links; never follow a submitted path outside app/."""
    source = source.resolve(strict=True)
    if not source.is_relative_to(boundary):
        raise ValueError("submission link escapes the delivered app package")
    mode = source.stat().st_mode
    if stat.S_ISDIR(mode):
        if source in ancestors:
            raise ValueError("submission contains a cyclic directory link")
        target.mkdir()
        for entry in sorted(source.iterdir()):
            if entry.name == "__pycache__" or entry.suffix == ".pyc":
                continue
            _copy_tree(entry, target / entry.name, boundary, ancestors + (source,))
        target.chmod(0o555)
    elif stat.S_ISREG(mode):
        shutil.copyfile(source, target)
        target.chmod(0o555 if mode & 0o111 else 0o444)
    else:
        raise ValueError("submission contains an unsupported special file")


def _copy_public_tree(source, target):
    """Only trusted verifier-image materials may enter the CLI workspace."""
    if source.is_symlink() or not source.is_dir():
        raise ValueError("trusted material directory is missing or linked")
    target.mkdir()
    for entry in sorted(source.iterdir()):
        if entry.is_symlink() or not entry.is_file():
            raise ValueError("trusted material directory contains a nonregular file")
        shutil.copyfile(entry, target / entry.name)
        (target / entry.name).chmod(0o444)
    target.chmod(0o555)


class CandidateRuntime:
    def __init__(self, candidate, assets, isolate=False, trusted_public=None):
        self.original = Path(candidate).resolve()
        self.assets = Path(assets).resolve()
        self.isolate = isolate
        self.directory = None
        self.protected_file_changes = []
        self.candidate = self.original
        self.worker = self.assets / "worker.py"
        if not isolate:
            return
        if os.name != "posix" or not hasattr(os, "geteuid") or os.geteuid() != 0:
            raise ValueError("--isolate requires a root-owned Linux verifier; refusing a same-UID fallback")
        if not sys_platform_linux():
            raise ValueError("--isolate is supported by the Linux verifier image only")
        self.directory = tempfile.TemporaryDirectory(prefix="session-candidate-")
        public = Path(self.directory.name)
        public.chmod(0o755)
        self.candidate = public / "workspace"
        self.candidate.mkdir(mode=0o755)
        app = self.original / "app"
        if app.is_symlink() or not app.is_dir():
            raise ValueError("the delivered app artifact must be a directory")
        boundary = app.resolve(strict=True)
        _copy_tree(app, self.candidate / "app", boundary)

        frozen = self.assets / "frozen" / "__init__.py"
        submitted_init = app / "__init__.py"
        if not submitted_init.is_file() or submitted_init.read_bytes() != frozen.read_bytes():
            self.protected_file_changes.append("app/__init__.py")
        destination = self.candidate / "app" / "__init__.py"
        # The package tree is already read-only. Only its trusted owner writes
        # this restored entry point; it is not an additional business score item.
        destination.parent.chmod(0o755)
        if destination.exists():
            if destination.is_dir():
                raise ValueError("submitted app/__init__.py is not a regular file")
            destination.chmod(0o644)
        destination.write_bytes(frozen.read_bytes())
        destination.chmod(0o444)
        destination.parent.chmod(0o555)

        trusted = Path(trusted_public or "/app").resolve()
        for name in ("replay.py", "ARCHITECTURE.md", "INPUTS.md"):
            source = trusted / name
            if source.is_symlink() or not source.is_file():
                raise ValueError("trusted verifier-image public file is missing: " + name)
            shutil.copyfile(source, self.candidate / name)
            (self.candidate / name).chmod(0o444)
        _copy_public_tree(trusted / "materials", self.candidate / "materials")
        self.candidate.chmod(0o555)
        self.worker = public / "worker.py"
        shutil.copyfile(self.assets / "worker.py", self.worker)
        self.worker.chmod(0o444)

    def public_directory(self, directory):
        if self.isolate:
            directory.chmod(0o755)
            for path in directory.iterdir():
                if path.is_symlink() or not path.is_file():
                    raise ValueError("candidate input fixtures must be ordinary files")
                path.chmod(0o444)

    def run(self, command, *, input=None, timeout=25):
        """Bound output and reap a candidate process group on every exit path."""
        environment = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8",
                       "LC_ALL": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1",
                       "HOME": "/nonexistent"}
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            process = subprocess.Popen(command, stdin=subprocess.PIPE,
                                       stdout=stdout, stderr=stderr, text=True,
                                       cwd=str(self.candidate), env=environment,
                                       start_new_session=True,
                                       preexec_fn=drop_privileges if self.isolate else None)
            try:
                process.communicate(input=input, timeout=timeout)
            finally:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                process.wait()
            stdout.seek(0)
            stderr.seek(0)
            out = stdout.read(OUTPUT_LIMIT + 1)
            err = stderr.read(OUTPUT_LIMIT + 1)
            if len(out) > OUTPUT_LIMIT or len(err) > OUTPUT_LIMIT:
                raise ValueError("candidate output exceeded the verifier transport limit")
            return subprocess.CompletedProcess(command, process.returncode,
                                               out.decode("utf-8", errors="replace"),
                                               err.decode("utf-8", errors="replace"))

    def close(self):
        if self.directory is not None:
            self.directory.cleanup()


def sys_platform_linux():
    import sys
    return sys.platform.startswith("linux")
