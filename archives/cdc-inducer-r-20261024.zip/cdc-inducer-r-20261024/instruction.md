# Repair the finance reconciliation service

Database capture agents send transaction envelopes to a finance reconciliation
service. Finance consumes receipts and later corrections. Operators report absent
updates during capture maintenance, financial records that disagree after delayed
uploads, and reconciliation work disappearing during storage maintenance. They
also report operational records lingering after a completed shift.

Repair `app.SnapshotService` in `/app/app` so that accepted transactions produce
the correct financial history, capture maintenance allows reconciliation to become
ready under the service agreement, and completed histories leave operational
storage when required. Preserve the public interface and output formats.

The complete business contract is in `/app/docs/OPERATIONS.md`. The source and
input inventory, including replay commands, is in `/app/docs/FILES.md`. The
provided logs are operational inputs; they contain no expected outputs.

You may change or add Python modules under `/app/app`, except the protected
`/app/app/__init__.py`. Keep the documentation, materials, and `/app/replay.py`
unchanged. Calls are sequential, and only the Python standard library is
available.

You have 28800 seconds to complete this task.

The service also accepts raw producer capture envelopes through `capture(row)`. Its catalogs and interface are specified in OPERATIONS.md; capture-envelopes.jsonl is an additional operational replay.
