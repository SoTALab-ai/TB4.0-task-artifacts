class CaptureObservations:
    def __init__(self, shards):
        self.records = {shard: {"position": 0, "advanced_pass": 0} for shard in shards}

    def register(self, shard, current_pass=0):
        self.records.setdefault(shard, {"position": 0, "advanced_pass": current_pass})

    def report(self, shard, position, current_pass):
        record = self.records[shard]
        if position > record["position"]:
            record["position"] = position
            record["advanced_pass"] = current_pass

    def certified(self, shard):
        return self.records[shard]["position"]

    def progress_pass(self, shard):
        return self.records[shard]["advanced_pass"]
