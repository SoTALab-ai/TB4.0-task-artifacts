from .observations import CaptureObservations


class Progress:
    """Use cursor advances as participation evidence for the shared boundary.

    This implementation falls back to all registered cursors when that evidence
    ages out, retaining the historical minimum as its conservative baseline.
    """

    QUIET_AFTER = 10

    def __init__(self, shards):
        self.observations = CaptureObservations(shards)
        self.position = 0

    @property
    def positions(self):
        return {shard: self.observations.certified(shard)
                for shard in self.observations.records}

    def register(self, shard, current_pass):
        existed = shard in self.observations.records
        self.observations.register(shard, current_pass)
        if not existed:
            self.settle(current_pass)

    def settle(self, current_pass):
        positions = self.positions
        participating = [position for shard, position in positions.items()
                         if current_pass - self.observations.progress_pass(shard)
                         <= self.QUIET_AFTER]
        candidate = min(participating or positions.values())
        self.position = max(self.position, candidate)
