"""Resolve capture envelopes using the installed producer and routing catalogs."""
import csv
from pathlib import Path


class CaptureInput:
    def __init__(self, materials_dir):
        root = Path(materials_dir)
        with (root / "capture-clocks.csv").open(newline="", encoding="utf-8") as stream:
            self.clocks = list(csv.DictReader(stream))
        with (root / "capture-routing.csv").open(newline="", encoding="utf-8") as stream:
            self.routes = list(csv.DictReader(stream))

    def resolve(self, row):
        if not isinstance(row, dict):
            raise ValueError("capture row")
        try:
            for key in ("shard", "change_id", "epoch", "client", "actor"):
                if not isinstance(row[key], str) or not row[key]:
                    raise ValueError(key)
            for key in ("local_start", "local_stop", "delta"):
                if type(row[key]) is not int:
                    raise ValueError(key)
            clock = [item for item in self.clocks if item["shard"] == row["shard"]]
            if not clock:
                raise ValueError("capture clock")
            offset = int(clock[0]["offset"])
            start, stop = row["local_start"] + offset, row["local_stop"] + offset
            routes = [item for item in self.routes
                      if item["client"] == row["client"] and item["actor"] == row["actor"]
                      and int(item["from_position"]) <= row["local_start"]
                      and (not item["to_position"] or row["local_start"] < int(item["to_position"]))]
            if len(routes) != 1:
                raise ValueError("capture route")
            return row["shard"], row["change_id"], routes[0]["source_table"], start, stop, row["delta"]
        except (KeyError, TypeError) as exc:
            raise ValueError("capture fields") from exc
