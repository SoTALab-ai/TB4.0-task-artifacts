class Publication:
    def __init__(self, page_size):
        self.page_size = page_size

    def publish_one(self, batch, boundary, gap, journal):
        node = batch.history
        previous = node.last_sent
        withdrawn_before = previous is not None and any(
            receipt["receipt_id"] == previous["receipt_id"]
            for page in node.transmissions for receipt in page["withdrawn"]
        )
        if previous is not None and not withdrawn_before:
            if all(previous[key] == value
                   for key, value in batch.contents().items()):
                return None
            return {"batch_id": batch.batch_id, "table": batch.table,
                    "withdrawn": [dict(previous)][:self.page_size], "snapshot": None}
        if batch.stop + gap > boundary:
            return None
        receipt = journal.allocate(batch.contents())
        return {"batch_id": batch.batch_id, "table": batch.table,
                "withdrawn": [], "snapshot": receipt}

    def publish(self, batches, boundary, gap, journal):
        for batch in batches.ordered():
            page = self.publish_one(batch, boundary, gap, journal)
            if page is not None:
                journal.stage(batch.history, page)
        return journal.drain()
