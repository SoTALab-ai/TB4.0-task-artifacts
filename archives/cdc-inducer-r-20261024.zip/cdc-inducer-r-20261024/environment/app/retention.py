class Retention:
    def __init__(self, gap, retention, stale_passes):
        self.gap = gap
        self.retention = retention
        self.stale_passes = stale_passes

    def ordinary_candidates(self, batches, boundary, current_pass):
        """Apply the current expiry-and-quiet policy across the retained index.

        A batch beyond the position horizon also receives a quiet interval
        measured from its retained creation pass before ordinary retirement.
        """
        for batch in batches.items.values():
            quiet = current_pass - batch.created_pass
            if (boundary > batch.stop + self.gap + self.retention
                    and quiet > self.retention):
                yield batch

    def idle_candidates(self, batches, current_pass):
        """Apply the separate age budget to long-resident storage units.

        Joins retain the oldest creation pass, so their combined history is
        treated as one unit with that same age for this path.
        """
        for batch in batches.items.values():
            if current_pass - batch.created_pass > self.stale_passes:
                yield batch

    def _retire(self, batch, batches, ledger):
        ledger.archive(batch)
        del batches.items[batch.batch_id]

    def compact(self, batches, boundary, current_pass, ledger):
        ordinary = self.ordinary_candidates(batches, boundary, current_pass)
        candidates = {batch.batch_id: batch for batch in ordinary}
        candidates.update((batch.batch_id, batch)
                          for batch in self.idle_candidates(batches, current_pass))
        removed = sorted(candidates, key=lambda batch_id: int(batch_id[1:]))
        for batch_id in removed:
            self._retire(candidates[batch_id], batches, ledger)
        return removed
