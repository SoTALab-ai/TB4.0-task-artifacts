class CaptureObservations:
    def __init__(self, shards):
        self.records = {shard: {"position": 0, "pass": 0} for shard in shards}

    def register(self, shard, current_pass=0):
        self.records.setdefault(shard, {"position": 0, "pass": current_pass})

    def report(self, shard, position, current_pass):
        self.records[shard]["position"] = max(self.records[shard]["position"], position)
        self.records[shard]["pass"] = current_pass

    def transaction(self, shard, current_pass):
        self.records[shard]["pass"] = current_pass

    def certified(self, shard):
        return self.records[shard]["position"]

    def progress_pass(self, shard):
        return self.records[shard]["pass"]
