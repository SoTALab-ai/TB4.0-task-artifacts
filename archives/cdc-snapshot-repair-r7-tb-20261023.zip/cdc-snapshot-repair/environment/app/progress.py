from .observations import CaptureObservations


class Progress:
    REPORT_WINDOW = 2
    SILENCE_SETTLE = 30

    def __init__(self, shards):
        self.observations = CaptureObservations(shards)
        self.position = 0

    @property
    def positions(self):
        return {shard: self.observations.certified(shard)
                for shard in self.observations.records}

    def register(self, shard, current_pass):
        existed = shard in self.observations.records
        self.observations.register(shard, current_pass)
        if not existed:
            self.settle(current_pass)

    def settle(self, current_pass):
        positions = self.positions
        participating = [position for shard, position in positions.items()
                         if current_pass - self.observations.progress_pass(shard)
                         <= self.REPORT_WINDOW]
        if participating:
            candidate = min(participating)
        else:
            last_activity = max(self.observations.progress_pass(s)
                                for s in positions)
            if current_pass - last_activity < self.SILENCE_SETTLE:
                return
            candidate = max(positions.values())
        self.position = max(self.position, candidate)
